package com.vakit.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vakit.app.BuildConfig
import com.vakit.app.domain.ColorTheme
import com.vakit.app.domain.LocationInfo
import com.vakit.app.domain.Prayer
import com.vakit.app.domain.ThemeMode
import com.vakit.app.notification.NotificationHelper
import com.vakit.app.ui.theme.colorThemePreview
import com.vakit.app.vakitApp
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val UPDATE_FORMAT: DateTimeFormatter =
    DateTimeFormatter.ofPattern("d MMM yyyy HH:mm", Locale("tr", "TR"))

@Composable
fun SettingsScreen(
    vm: HomeViewModel,
    location: LocationInfo,
    onBack: () -> Unit,
    onChangeLocation: () -> Unit
) {
    val context = LocalContext.current
    val app = context.vakitApp
    val settings by vm.settings.collectAsStateWithLifecycle()
    val download by vm.download.collectAsStateWithLifecycle()
    val lastUpdate by app.settingsRepository.lastUpdate.collectAsStateWithLifecycle(initialValue = null)

    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val notificationsOk = remember(tick) { NotificationHelper.canPost(context) }
    val exactOk = remember(tick) { app.alarmScheduler.canScheduleExact() }
    val testPlanned = remember(tick) { app.alarmScheduler.isTestScheduled() }
    var message by remember { mutableStateOf("") }

    val lastUpdateText = lastUpdate?.let { millis ->
        Instant.ofEpochMilli(millis).atZone(ZoneId.of(location.timezoneId)).format(UPDATE_FORMAT)
    } ?: "Henüz güncellenmedi"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Geri") }
            Text("Ayarlar", style = MaterialTheme.typography.titleLarge)
        }

        SectionCard("Konum") {
            Text(location.label, style = MaterialTheme.typography.titleMedium)
            OutlinedButton(onClick = onChangeLocation) { Text("Konumu değiştir") }
        }

        SectionCard("Bildirimler") {
            if (!notificationsOk) {
                Text(
                    "Bildirimler kapalı. Vakit bildirimlerini alabilmek için izin vermelisin.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error
                )
                Button(onClick = { openNotificationSettings(context) }) { Text("Bildirim ayarlarını aç") }
            }
            if (!exactOk) {
                Text(
                    "Hassas alarm erişimi kapalı: bildirimler birkaç dakika gecikebilir.",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedButton(onClick = { openExactAlarmSettings(context) }) { Text("Hassas alarmı aç") }
            }

            Text("Vakit bildirimleri", style = MaterialTheme.typography.titleSmall)
            Prayer.entries.forEach { prayer ->
                SwitchRow(
                    title = prayer.label,
                    subtitle = null,
                    checked = settings.isEnabled(prayer),
                    onChange = { vm.setPrayerNotification(prayer, it) }
                )
            }
            HorizontalDivider()
            SwitchRow("Bildirim sesi", null, settings.sound) { vm.setSound(it) }
            SwitchRow("Titreşim", null, settings.vibration) { vm.setVibration(it) }
            SwitchRow(
                "Sabit vakit bildirimi",
                "Günün vakitlerini yan yana gösterir ve şu anki vakti işaretler.",
                settings.statusNotification
            ) { vm.setStatusNotification(it) }
            HorizontalDivider()

            Text("Test", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        val ok = NotificationHelper.showTest(context, settings.sound, settings.vibration)
                        message = if (ok) "Test bildirimi gönderildi."
                        else "Bildirim gönderilemedi: izin veya kanal kapalı."
                    }
                ) { Text("Test bildirimi") }
                OutlinedButton(
                    onClick = {
                        app.alarmScheduler.scheduleTestAlarm()
                        message = "Test alarmı 2 dakika sonrasına kuruldu. Uygulamayı kapatıp bekle."
                        tick++
                    }
                ) { Text("2 dk sonra test") }
            }
            if (testPlanned) {
                TextButton(
                    onClick = {
                        app.alarmScheduler.cancelTestAlarm()
                        message = "Test alarmı iptal edildi."
                        tick++
                    }
                ) { Text("Test alarmını iptal et") }
            }
            if (message.isNotEmpty()) {
                Text(message, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
            }
        }

        SectionCard("Görünüm") {
            Text("Tema", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    ThemeMode.SYSTEM to "Sistem",
                    ThemeMode.LIGHT to "Açık",
                    ThemeMode.DARK to "Koyu"
                ).forEach { (mode, label) ->
                    FilterChip(
                        selected = settings.themeMode == mode,
                        onClick = { vm.setThemeMode(mode) },
                        label = { Text(label) }
                    )
                }
            }
            Spacer(Modifier.height(2.dp))
            Text("Renk", style = MaterialTheme.typography.titleSmall)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                ColorTheme.entries.forEach { theme ->
                    val selected = settings.colorTheme == theme
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { vm.setColorTheme(theme) }
                            .padding(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(colorThemePreview(theme))
                                .border(
                                    width = if (selected) 3.dp else 1.dp,
                                    color = if (selected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.outline,
                                    shape = CircleShape
                                )
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            theme.label,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        SectionCard("Veri") {
            Text("Son güncelleme: $lastUpdateText", style = MaterialTheme.typography.bodyMedium)
            if (download is DownloadState.Error) {
                Text(
                    (download as DownloadState.Error).message,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Button(
                onClick = vm::retryDownload,
                enabled = download !is DownloadState.Loading
            ) {
                Text(if (download is DownloadState.Loading) "Güncelleniyor…" else "Vakitleri şimdi güncelle")
            }
            Text(
                "Veri kaynağı: ${app.repository.sourceName}",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.alpha(0.7f)
            )
        }

        SectionCard("Uygulama") {
            Text("Vakit · Sürüm ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodyMedium)
            Text(
                "Reklamsız, ücretsiz namaz vakitleri uygulaması. Verilerin cihazından dışarı gönderilmez.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.alpha(0.7f)
            )
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, modifier = Modifier.alpha(0.7f))
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
