package com.vakit.app.data

import com.vakit.app.data.local.PrayerDao
import com.vakit.app.data.local.toDomain
import com.vakit.app.data.local.toEntity
import com.vakit.app.data.remote.PrayerDataException
import com.vakit.app.domain.LocationInfo
import com.vakit.app.domain.PrayerDay
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import java.io.IOException
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId

class PrayerTimesRepository(
    private val dao: PrayerDao,
    private val source: PrayerTimesDataSource,
    private val settings: SettingsRepository
) {
    val sourceName: String get() = source.sourceName

    fun today(location: LocationInfo): LocalDate = LocalDate.now(ZoneId.of(location.timezoneId))

    fun observeDay(location: LocationInfo, date: LocalDate): Flow<PrayerDay?> =
        dao.observeDay(location.key, date.toString()).map { it?.toDomain() }

    fun observeAll(location: LocationInfo): Flow<Map<LocalDate, PrayerDay>> =
        dao.observeAll(location.key).map { list ->
            list.associate { entity ->
                val day = entity.toDomain()
                day.date to day
            }
        }

    suspend fun getRange(location: LocationInfo, from: LocalDate, to: LocalDate): List<PrayerDay> =
        dao.getRange(location.key, from.toString(), to.toString()).map { it.toDomain() }

    /** Kayıtlı veri yeterliyse ağa gitmez; değilse indirir. */
    suspend fun ensureData(
        location: LocationInfo,
        minDays: Int = 20,
        days: Int = DEFAULT_DAYS
    ): Result<Int> {
        val today = today(location)
        val have = dao.countRange(location.key, today.toString(), today.plusDays(minDays - 1L).toString())
        return if (have >= minDays) Result.success(0) else refresh(location, days)
    }

    /** Bugünden itibaren [days] günü kapsayan ayları indirip Room'a yazar. */
    suspend fun refresh(location: LocationInfo, days: Int = DEFAULT_DAYS): Result<Int> =
        withContext(Dispatchers.IO) {
            try {
                val today = today(location)
                val end = today.plusDays(days - 1L)
                val fetched = LinkedHashMap<LocalDate, PrayerDay>()
                var month = YearMonth.from(today)
                val lastMonth = YearMonth.from(end)
                while (!month.isAfter(lastMonth)) {
                    source.fetchMonth(location.latitude, location.longitude, month.year, month.monthValue)
                        .forEach { fetched[it.date] = it }
                    month = month.plusMonths(1)
                }
                if (fetched.keys.none { !it.isBefore(today) }) {
                    throw PrayerDataException("Bugüne ait vakit verisi alınamadı.")
                }
                val now = System.currentTimeMillis()
                dao.upsertAll(fetched.values.map { it.toEntity(location.key, now) })
                dao.deleteOtherLocations(location.key)
                dao.deleteOlderThan(today.minusDays(7).toString())
                settings.setLastUpdate(now)
                Result.success(fetched.size)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    companion object {
        const val DEFAULT_DAYS = 30
    }
}

fun Throwable.userMessage(): String = when (this) {
    is IOException -> "İnternet bağlantısı kurulamadı. Kayıtlı veriler kullanılmaya devam eder."
    is HttpException -> "Sunucu hatası (kod: ${code()})."
    is PrayerDataException -> message ?: "Namaz vakti verisi doğrulanamadı."
    else -> "Beklenmeyen hata: ${message ?: javaClass.simpleName}"
}
