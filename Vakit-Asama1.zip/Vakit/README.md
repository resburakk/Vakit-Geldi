# Vakit (Aşama 1)

Türkçe namaz vakitleri uygulaması. Bu sürüm **Aşama 1**'dir: veri katmanı, bildirim/alarm altyapısı ve bunları cihazda doğrulamak için basit bir geliştirici ekranı içerir. Ana ekran, takvim, ayarlar, il/ilçe seçimi, otomatik konum, WorkManager ve widget sonraki aşamalardadır.

## Aşama 1 kapsamı
- AlAdhan API (method=13) ile aylık takvim indirme, doğrulama ve Room'a kaydetme
- Değiştirilebilir kaynak mimarisi (`PrayerTimesDataSource`)
- DataStore ile konum ve ayarların saklanması
- AlarmManager ile her vakit için ayrı alarm, 5 vakit ayrı açma/kapama, ön hatırlatma altyapısı
- BOOT_COMPLETED, saat dilimi, saat değişimi, güncelleme ve kesin alarm erişimi değişiminde yeniden planlama
- Çift bildirim engeli, test bildirimi ve 2 dakikalık test alarmı

## Derleme
1. Android Studio'da `Vakit` klasörünü aç, Gradle senkronizasyonunu bekle.
2. Debug APK: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

## Veri kaynakları
- Namaz vakitleri: AlAdhan Prayer Times API (https://aladhan.com/prayer-times-api). Diyanet yöntemiyle hesaplanır; Diyanet'in resmî yayınıyla birebir aynı olduğu garanti edilmez.
- İl/ilçe koordinatları (Aşama 2): `tools/ilce_verisi_uret.py` ile GeoNames Türkiye verisinden (https://download.geonames.org/export/dump/, CC BY 4.0) üretilir.

## Bilinen sınırlar
Android'in force-stop davranışı ve üreticiye özgü pil kısıtlamaları nedeniyle hiçbir uygulama bildirimin her koşulda zamanında gelmesini garanti edemez. Hassas alarm erişimi verilmezse alarmlar yaklaşık zamanda çalar.
