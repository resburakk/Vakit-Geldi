package com.vakit.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PrayerDao {
    @Query("SELECT * FROM prayer_days WHERE locationKey = :key AND date = :date LIMIT 1")
    fun observeDay(key: String, date: String): Flow<PrayerDayEntity?>

    @Query("SELECT * FROM prayer_days WHERE locationKey = :key AND date = :date LIMIT 1")
    suspend fun getDay(key: String, date: String): PrayerDayEntity?

    @Query("SELECT * FROM prayer_days WHERE locationKey = :key AND date BETWEEN :from AND :to ORDER BY date")
    suspend fun getRange(key: String, from: String, to: String): List<PrayerDayEntity>

    @Query("SELECT COUNT(*) FROM prayer_days WHERE locationKey = :key AND date BETWEEN :from AND :to")
    suspend fun countRange(key: String, from: String, to: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(days: List<PrayerDayEntity>)

    @Query("DELETE FROM prayer_days WHERE locationKey != :key")
    suspend fun deleteOtherLocations(key: String)

    @Query("DELETE FROM prayer_days WHERE date < :before")
    suspend fun deleteOlderThan(before: String)
}
