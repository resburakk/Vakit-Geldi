package com.vakit.app.domain

import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale

enum class Prayer(val label: String, val enteredText: String) {
    IMSAK("İmsak", "imsak vakti girdi."),
    OGLE("Öğle", "öğle namazı vakti girdi."),
    IKINDI("İkindi", "ikindi namazı vakti girdi."),
    AKSAM("Akşam", "akşam namazı vakti girdi."),
    YATSI("Yatsı", "yatsı namazı vakti girdi.")
}

data class LocationInfo(
    val il: String,
    val ilce: String,
    val latitude: Double,
    val longitude: Double,
    val timezoneId: String = DEFAULT_TIMEZONE
) {
    val label: String get() = "$il / $ilce"
    val key: String get() = String.format(Locale.US, "%.4f,%.4f", latitude, longitude)

    companion object {
        const val DEFAULT_TIMEZONE = "Europe/Istanbul"
    }
}

data class PrayerDay(
    val date: LocalDate,
    val imsak: LocalTime,
    val ogle: LocalTime,
    val ikindi: LocalTime,
    val aksam: LocalTime,
    val yatsi: LocalTime,
    val timezoneId: String
) {
    fun timeOf(prayer: Prayer): LocalTime = when (prayer) {
        Prayer.IMSAK -> imsak
        Prayer.OGLE -> ogle
        Prayer.IKINDI -> ikindi
        Prayer.AKSAM -> aksam
        Prayer.YATSI -> yatsi
    }

    fun zonedTime(prayer: Prayer): ZonedDateTime =
        ZonedDateTime.of(date, timeOf(prayer), ZoneId.of(timezoneId))
}
