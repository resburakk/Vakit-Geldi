package com.vakit.app.data.local

import androidx.room.Entity
import com.vakit.app.domain.PrayerDay
import java.time.LocalDate
import java.time.LocalTime

@Entity(tableName = "prayer_days", primaryKeys = ["locationKey", "date"])
data class PrayerDayEntity(
    val locationKey: String,
    val date: String,
    val imsak: String,
    val ogle: String,
    val ikindi: String,
    val aksam: String,
    val yatsi: String,
    val timezoneId: String,
    val fetchedAt: Long
)

fun PrayerDayEntity.toDomain(): PrayerDay = PrayerDay(
    date = LocalDate.parse(date),
    imsak = LocalTime.parse(imsak),
    ogle = LocalTime.parse(ogle),
    ikindi = LocalTime.parse(ikindi),
    aksam = LocalTime.parse(aksam),
    yatsi = LocalTime.parse(yatsi),
    timezoneId = timezoneId
)

fun PrayerDay.toEntity(locationKey: String, fetchedAt: Long): PrayerDayEntity = PrayerDayEntity(
    locationKey = locationKey,
    date = date.toString(),
    imsak = imsak.toString(),
    ogle = ogle.toString(),
    ikindi = ikindi.toString(),
    aksam = aksam.toString(),
    yatsi = yatsi.toString(),
    timezoneId = timezoneId,
    fetchedAt = fetchedAt
)
