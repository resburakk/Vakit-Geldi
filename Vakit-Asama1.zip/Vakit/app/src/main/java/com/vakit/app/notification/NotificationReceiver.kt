package com.vakit.app.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.vakit.app.domain.Prayer
import com.vakit.app.vakitApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class NotificationReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != AlarmScheduler.ACTION_PRAYER && action != AlarmScheduler.ACTION_TEST) return
        val appContext = context.applicationContext
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
            try {
                if (action == AlarmScheduler.ACTION_TEST) handleTest(appContext)
                else handlePrayer(appContext, intent)
            } catch (e: Exception) {
                // Bildirim hatası uygulamayı çökertmemeli.
            } finally {
                pending.finish()
            }
        }
    }

    private suspend fun handleTest(context: Context) {
        val settings = context.vakitApp.settingsRepository.settings.first()
        NotificationHelper.show(
            context,
            AlarmCodes.TEST_NOTIFICATION_ID,
            "Test alarmı çalıştı",
            "Planlanan test alarmı arka planda başarıyla tetiklendi.",
            settings.sound,
            settings.vibration
        )
    }

    private suspend fun handlePrayer(context: Context, intent: Intent) {
        val kind = intent.getStringExtra(AlarmScheduler.EXTRA_KIND) ?: return
        val prayer = Prayer.entries.getOrNull(intent.getIntExtra(AlarmScheduler.EXTRA_PRAYER, -1)) ?: return
        val date = intent.getStringExtra(AlarmScheduler.EXTRA_DATE) ?: return
        val triggerAt = intent.getLongExtra(AlarmScheduler.EXTRA_TRIGGER_AT, 0L)
        val code = intent.getIntExtra(AlarmScheduler.EXTRA_CODE, 0)
        val location = intent.getStringExtra(AlarmScheduler.EXTRA_LOCATION).orEmpty()
        val minutes = intent.getIntExtra(AlarmScheduler.EXTRA_REMINDER_MINUTES, 0)

        val settings = context.vakitApp.settingsRepository.settings.first()
        val now = System.currentTimeMillis()
        val wanted = settings.isEnabled(prayer) &&
            (kind == AlarmScheduler.KIND_PRAYER ||
                (kind == AlarmScheduler.KIND_REMINDER && settings.reminderMinutes > 0))
        val onTime = now - triggerAt <= MAX_LATE_MS

        if (wanted && onTime && FiredLog.markOnce(context, "$kind:$date:${prayer.name}", now)) {
            val (title, body) = if (kind == AlarmScheduler.KIND_REMINDER) {
                "Vakit Hatırlatması" to "${prayer.label} vaktine $minutes dakika kaldı."
            } else {
                "${prayer.label} Vakti" to "$location için ${prayer.enteredText}"
            }
            NotificationHelper.show(context, code, title, body, settings.sound, settings.vibration)
        }
        // Planlama ufkunu ileri taşı.
        Rescheduler.rescheduleAll(context)
    }

    private companion object {
        /** Cihaz kapalıyken/gecikmeli tetiklenen eski vakit bildirimleri gösterilmez. */
        const val MAX_LATE_MS = 30L * 60 * 1000
    }
}
