package com.vakit.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.vakit.app.domain.ThemeMode

private val LightColors = lightColorScheme(
    primary = Color(0xFF176B5B),
    onPrimary = Color.White,
    secondary = Color(0xFF7FB09E),
    tertiary = Color(0xFFC9A24A),
    background = Color(0xFFF7F8F5),
    surface = Color.White,
    onBackground = Color(0xFF1F2523),
    onSurface = Color(0xFF1F2523)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF5CC2A8),
    onPrimary = Color(0xFF00382E),
    secondary = Color(0xFF8DB9A8),
    tertiary = Color(0xFFE0BE6A),
    background = Color(0xFF101413),
    surface = Color(0xFF181D1B),
    onBackground = Color(0xFFE1E4E1),
    onSurface = Color(0xFFE1E4E1)
)

@Composable
fun VakitTheme(themeMode: ThemeMode = ThemeMode.SYSTEM, content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
