package com.vakit.app.notification

import com.vakit.app.domain.Prayer
import java.time.LocalDate

object AlarmCodes {
    const val TEST_REQUEST_CODE = 1
    const val TEST_NOTIFICATION_ID = 1

    /**
     * Her (gün, vakit, tür) için benzersiz kimlik: yyyyMMdd * 10 + (hatırlatma ? 5 : 0) + vakit sırası.
     * Test alarmı (1) ile çakışmaz; Int sınırları içinde kalır.
     */
    fun prayerCode(date: LocalDate, prayer: Prayer, reminder: Boolean): Int {
        val ymd = date.year * 10000 + date.monthValue * 100 + date.dayOfMonth
        return ymd * 10 + (if (reminder) 5 else 0) + prayer.ordinal
    }
}
