package com.vakit.app

import android.app.Application
import android.content.Context
import com.vakit.app.data.AlAdhanDataSource
import com.vakit.app.data.PrayerTimesRepository
import com.vakit.app.data.SettingsRepository
import com.vakit.app.data.local.VakitDatabase
import com.vakit.app.data.remote.NetworkModule
import com.vakit.app.notification.AlarmScheduler

class VakitApp : Application() {
    val database: VakitDatabase by lazy { VakitDatabase.create(this) }
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(this) }
    val repository: PrayerTimesRepository by lazy {
        PrayerTimesRepository(
            dao = database.prayerDao(),
            source = AlAdhanDataSource(NetworkModule.alAdhanApi),
            settings = settingsRepository
        )
    }
    val alarmScheduler: AlarmScheduler by lazy { AlarmScheduler(this) }
}

val Context.vakitApp: VakitApp get() = applicationContext as VakitApp
