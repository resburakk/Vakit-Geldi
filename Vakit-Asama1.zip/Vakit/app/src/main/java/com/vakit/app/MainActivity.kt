package com.vakit.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.vakit.app.data.userMessage
import com.vakit.app.domain.AppSettings
import com.vakit.app.domain.LocationInfo
import com.vakit.app.domain.Prayer
import com.vakit.app.notification.NotificationHelper
import com.vakit.app.notification.Rescheduler
import com.vakit.app.ui.theme.VakitTheme
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Aşama 1 geliştirici ekranı: veri ve bildirim altyapısını gerçek cihazda doğrulamak içindir.
 * Aşama 2'de ana ekran, takvim ve ayarlar ekranlarıyla değiştirilecek.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = vakitApp
        setContent {
            val settings by app.settingsRepository.settings.collectAsState(initial = AppSettings())
            VakitTheme(settings.themeMode) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Stage1Screen(app)
                }
            }
        }
    }
}

@Composable
private fun Stage1Screen(app: VakitApp) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val location by app.settingsRepository.location.collectAsState(initial = null)
    val settings by app.settingsRepository.settings.collectAsState(initial = AppSettings())

    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }

    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var il by rememberSaveable { mutableStateOf("") }
    var ilce by rememberSaveable { mutableStateOf("") }
    var lat by rememberSaveable { mutableStateOf("") }
    var lon by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(location) {
        location?.let {
            if (il.isEmpty() && ilce.isEmpty()) {
                il = it.il
                ilce = it.ilce
                lat = it.latitude.toString()
                lon = it.longitude.toString()
            }
        }
    }

    val dayFlow = remember(location, tick) {
        location?.let { app.repository.observeDay(it, app.repository.today(it)) } ?: flowOf(null)
    }
    val day by dayFlow.collectAsState(initial = null)

    val notificationsOk = remember(tick) { NotificationHelper.canPost(context) }
    val exactOk = remember(tick) { app.alarmScheduler.canScheduleExact() }
    val scheduledCount = remember(tick) { app.alarmScheduler.scheduledCount() }
    val testPlanned = remember(tick) { app.alarmScheduler.isTestScheduled() }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        message = if (granted) "Bildirim izni verildi." else "Bildirim izni verilmedi."
        tick++
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Vakit — Aşama 1: Altyapı ve bildirim testi", style = MaterialTheme.typography.titleLarge)
        Text(
            "Aşama 2'de ana ekran, takvim ve ayarlar gelecek. Şimdilik veri indirme ve bildirimleri doğrulayabilirsin.",
            style = MaterialTheme.typography.bodyMedium
        )

        Text("Konum (koordinatları kendin gir)", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(il, { il = it }, label = { Text("İl") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(ilce, { ilce = it }, label = { Text("İlçe") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                lat, { lat = it }, label = { Text("Enlem") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                lon, { lon = it }, label = { Text("Boylam") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(1f)
            )
        }
        Button(
            enabled = !busy,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val latitude = lat.replace(',', '.').toDoubleOrNull()
                val longitude = lon.replace(',', '.').toDoubleOrNull()
                if (il.isBlank() || ilce.isBlank() || latitude == null || longitude == null ||
                    latitude !in -90.0..90.0 || longitude !in -180.0..180.0
                ) {
                    message = "Lütfen il, ilçe ve geçerli koordinat girin."
                } else {
                    scope.launch {
                        busy = true
                        val newLocation = LocationInfo(il.trim(), ilce.trim(), latitude, longitude)
                        app.settingsRepository.setLocation(newLocation)
                        val result = app.repository.refresh(newLocation)
                        val planned = Rescheduler.rescheduleAll(context)
                        message = result.fold(
                            onSuccess = { "$it günlük vakit kaydedildi, $planned alarm planlandı." },
                            onFailure = { "İndirme başarısız: ${it.userMessage()} ($planned alarm planlandı.)" }
                        )
                        busy = false
                        tick++
                    }
                }
            }
        ) { Text(if (busy) "İşleniyor…" else "Kaydet ve vakitleri indir") }

        location?.let { loc ->
            Text("Kayıtlı konum: ${loc.label}", style = MaterialTheme.typography.titleMedium)
            val today = day
            if (today == null) {
                Text("Bugün için kayıtlı vakit yok.")
            } else {
                Prayer.entries.forEach { prayer ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(prayer.label)
                        Text(today.timeOf(prayer).toString())
                    }
                }
            }
        }

        Text("Durum", style = MaterialTheme.typography.titleMedium)
        Text("Bildirimler: ${if (notificationsOk) "açık" else "kapalı / izin yok"}")
        Text("Hassas alarm erişimi: ${if (exactOk) "verildi" else "verilmedi (alarmlar yaklaşık zamanda çalar)"}")
        Text("Planlı namaz alarmı: $scheduledCount")
        Text("Test alarmı: ${if (testPlanned) "planlı" else "yok"}")
        Text("Veri kaynağı: ${app.repository.sourceName}", style = MaterialTheme.typography.bodySmall)

        Text("İzinler", style = MaterialTheme.typography.titleMedium)
        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    message = "Bu Android sürümünde ayrı bildirim izni gerekmiyor."
                }
            }
        ) { Text("Bildirim izni iste") }
        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                context.startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                )
            }
        ) { Text("Uygulama bildirim ayarlarını aç") }
        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    context.startActivity(
                        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}"))
                    )
                } else {
                    message = "Bu Android sürümünde ayrı alarm erişimi gerekmiyor."
                }
            }
        ) { Text("Hassas alarm ayarını aç") }

        Text("Bildirim testi", style = MaterialTheme.typography.titleMedium)
        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val ok = NotificationHelper.showTest(context, settings.sound, settings.vibration)
                message = if (ok) "Test bildirimi gönderildi." else "Bildirim gönderilemedi: izin veya kanal kapalı."
            }
        ) { Text("Şimdi test bildirimi gönder") }
        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val at = app.alarmScheduler.scheduleTestAlarm()
                val clock = SimpleDateFormat("HH:mm:ss", Locale("tr")).format(Date(at))
                message = "Test alarmı $clock için planlandı (" +
                    (if (exactOk) "kesin" else "yaklaşık, dakik olmayabilir") +
                    "). Uygulamayı kapatıp bekle."
                tick++
            }
        ) { Text("2 dakika sonrası için test alarmı kur") }
        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                app.alarmScheduler.cancelTestAlarm()
                message = "Test alarmı iptal edildi."
                tick++
            }
        ) { Text("Test alarmını iptal et") }
        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                scope.launch {
                    val n = Rescheduler.rescheduleAll(context)
                    message = "$n alarm yeniden planlandı."
                    tick++
                }
            }
        ) { Text("Namaz alarmlarını yeniden planla") }

        if (message.isNotEmpty()) {
            Text(message, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
