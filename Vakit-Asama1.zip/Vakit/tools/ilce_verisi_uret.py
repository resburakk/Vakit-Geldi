#!/usr/bin/env python3
"""
Vakit - Il / Ilce / koordinat verisi uretici.

Kaynak: GeoNames (https://download.geonames.org/export/dump/TR.zip)
Lisans: CC BY 4.0 (kaynak belirtilmeli - README'ye eklenecek)

Kullanim:
    python3 ilce_verisi_uret.py
    python3 ilce_verisi_uret.py --zip TR.zip      # indirilmis dosya varsa
Cikti:
    iller_ilceler.json   -> app/src/main/assets/ klasorune kopyalanacak
    rapor.txt            -> Il basina ilce sayilari ve uyarilar

Yalnizca Python 3 standart kutuphanesi gerekir.
"""
import argparse
import io
import json
import sys
import urllib.request
import zipfile

URL = "https://download.geonames.org/export/dump/TR.zip"
BEKLENEN_IL = 81

# GeoNames sutun indeksleri (TR.txt, sekme ayrili)
C_ID, C_NAME, C_ASCII, C_ALT, C_LAT, C_LON = 0, 1, 2, 3, 4, 5
C_FCODE, C_ADMIN1, C_POP = 7, 10, 14

SONEKLER = (" Province", " Ili", " İli", " Ili ")


def temizle_ad(ad: str) -> str:
    ad = ad.strip()
    for s in SONEKLER:
        if ad.endswith(s.strip()):
            ad = ad[: -len(s.strip())].strip()
    return ad


def oku_zip(yol: str | None) -> list[list[str]]:
    if yol:
        veri = open(yol, "rb").read()
    else:
        print("Indiriliyor:", URL)
        with urllib.request.urlopen(URL, timeout=120) as r:
            veri = r.read()
    with zipfile.ZipFile(io.BytesIO(veri)) as z:
        with z.open("TR.txt") as f:
            metin = f.read().decode("utf-8")
    return [satir.split("\t") for satir in metin.splitlines() if satir.strip()]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip", help="Indirilmis TR.zip yolu")
    ap.add_argument("--cikti", default="iller_ilceler.json")
    ap.add_argument("--rapor", default="rapor.txt")
    args = ap.parse_args()

    satirlar = oku_zip(args.zip)

    iller: dict[str, dict] = {}
    for s in satirlar:
        if len(s) > C_ADMIN1 and s[C_FCODE] == "ADM1":
            iller[s[C_ADMIN1]] = {"ad": temizle_ad(s[C_NAME]), "ilceler": {}}

    uyarilar: list[str] = []
    for s in satirlar:
        if len(s) <= C_ADMIN1 or s[C_FCODE] != "ADM2":
            continue
        kod = s[C_ADMIN1]
        if kod not in iller:
            uyarilar.append(f"Il kodu bulunamadi: {s[C_NAME]} ({kod})")
            continue
        ad = s[C_NAME].strip()
        try:
            lat, lon = round(float(s[C_LAT]), 5), round(float(s[C_LON]), 5)
        except ValueError:
            uyarilar.append(f"Gecersiz koordinat: {ad}")
            continue
        if not (35.0 <= lat <= 43.0 and 25.0 <= lon <= 45.0):
            uyarilar.append(f"Turkiye disi koordinat: {ad} {lat},{lon}")
            continue
        iller[kod]["ilceler"][ad] = {"ad": ad, "lat": lat, "lon": lon}

    cikti = []
    for kod, il in sorted(iller.items(), key=lambda kv: kv[1]["ad"]):
        ilceler = sorted(il["ilceler"].values(), key=lambda x: x["ad"])
        if not ilceler:
            uyarilar.append(f"Ilcesi olmayan il: {il['ad']}")
            continue
        cikti.append({"il": il["ad"], "ilceler": ilceler})

    with open(args.cikti, "w", encoding="utf-8") as f:
        json.dump(cikti, f, ensure_ascii=False, indent=1)

    toplam = sum(len(i["ilceler"]) for i in cikti)
    if len(cikti) != BEKLENEN_IL:
        uyarilar.append(f"Il sayisi {len(cikti)}, beklenen {BEKLENEN_IL}")

    with open(args.rapor, "w", encoding="utf-8") as f:
        f.write(f"Il sayisi: {len(cikti)}\nToplam ilce: {toplam}\n\n")
        for i in cikti:
            f.write(f"{i['il']}: {len(i['ilceler'])}\n")
        f.write("\nUYARILAR\n")
        f.write("\n".join(uyarilar) if uyarilar else "Yok")
        f.write("\n")

    print(f"{len(cikti)} il, {toplam} ilce yazildi -> {args.cikti}")
    print(f"Rapor -> {args.rapor} ({len(uyarilar)} uyari)")
    return 0 if len(cikti) == BEKLENEN_IL else 1


if __name__ == "__main__":
    sys.exit(main())
