package com.vakit.app.data.location

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.vakit.app.data.remote.NominatimApi
import com.vakit.app.data.remote.OverpassApi
import com.vakit.app.data.remote.OverpassElement
import com.vakit.app.data.remote.PrayerDataException
import com.vakit.app.domain.LocationInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.lang.reflect.Type
import java.text.Collator
import java.util.Locale
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * İl/ilçe listeleri OpenStreetMap (Overpass) üzerinden internetten alınır ve cihazda saklanır
 * (180 gün geçerli; internet yoksa eski kayıt kullanılır). Seçilen ilçenin koordinatı sırayla
 * Google (cihaz Geocoder), OpenStreetMap Nominatim ve son çare olarak OSM ilçe merkezinden alınır.
 * Hiçbir koordinat tahmin edilmez.
 */
class LocationRepository(
    private val context: Context,
    private val overpass: OverpassApi,
    private val nominatim: NominatimApi,
    private val geocoder: GeocoderSource
) {
    private val gson = Gson()
    private val collator: Collator = Collator.getInstance(Locale("tr", "TR"))

    suspend fun provinces(): Result<List<Province>> =
        cached("provinces", object : TypeToken<List<Province>>() {}.type) { fetchProvinces() }

    suspend fun districts(province: Province): Result<List<District>> =
        cached("districts_${province.id}", object : TypeToken<List<District>>() {}.type) {
            fetchDistricts(province)
        }

    suspend fun resolve(province: Province, district: District): Result<ResolvedLocation> {
        return try {
            val query = "${district.name}, ${province.name}, Türkiye"
            val reference = if (district.lat != null && district.lon != null) {
                GeoPoint(district.lat, district.lon)
            } else {
                null
            }
            val google = geocoder.find(query)
            if (acceptable(google, reference) && google != null) {
                return Result.success(build(province, district, google, "Google (cihaz konum servisi)"))
            }
            val osm = nominatimPoint(query)
            if (acceptable(osm, reference) && osm != null) {
                return Result.success(build(province, district, osm, "OpenStreetMap Nominatim"))
            }
            if (reference != null) {
                return Result.success(build(province, district, reference, "OpenStreetMap (ilçe merkezi)"))
            }
            Result.failure(PrayerDataException("Koordinat alınamadı. İnternet bağlantını kontrol edip tekrar dene."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun build(province: Province, district: District, point: GeoPoint, source: String) =
        ResolvedLocation(
            LocationInfo(province.name, district.name, point.lat, point.lon),
            source
        )

    private fun acceptable(point: GeoPoint?, reference: GeoPoint?): Boolean {
        if (point == null) return false
        if (point.lat !in 35.5..42.5 || point.lon !in 25.5..45.0) return false
        return reference == null || distanceKm(point, reference) <= MAX_REFERENCE_KM
    }

    private fun distanceKm(a: GeoPoint, b: GeoPoint): Double {
        val dLat = Math.toRadians(b.lat - a.lat)
        val dLon = Math.toRadians(b.lon - a.lon)
        val h = sin(dLat / 2).pow(2) +
            cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2).pow(2)
        return 2 * EARTH_RADIUS_KM * asin(sqrt(h))
    }

    private suspend fun nominatimPoint(query: String): GeoPoint? = try {
        nominatim.search(query, "jsonv2", 1, "tr", "tr").firstOrNull()?.let { result ->
            val lat = result.lat?.toDoubleOrNull()
            val lon = result.lon?.toDoubleOrNull()
            if (lat != null && lon != null) GeoPoint(lat, lon) else null
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        null
    }

    private suspend fun fetchProvinces(): List<Province> {
        val elements = runOverpass(PROVINCES_QUERY)
        val list = elements.mapNotNull { element ->
            val id = element.id ?: return@mapNotNull null
            val name = nameOf(element) ?: return@mapNotNull null
            Province(id, name)
        }.distinctBy { it.name }
            .sortedWith(Comparator { a, b -> collator.compare(a.name, b.name) })
        if (list.size < MIN_PROVINCES) {
            throw PrayerDataException("İl listesi eksik geldi (${list.size}/81). Biraz sonra tekrar dene.")
        }
        return list
    }

    private suspend fun fetchDistricts(province: Province): List<District> {
        var elements = runOverpass(childrenQuery(province.id))
        if (elements.isEmpty()) elements = runOverpass(areaQuery(province.id))
        val list = elements.mapNotNull { element ->
            val name = nameOf(element) ?: return@mapNotNull null
            District(name, element.center?.lat, element.center?.lon)
        }.distinctBy { it.name }
            .sortedWith(Comparator { a, b -> collator.compare(a.name, b.name) })
        if (list.isEmpty()) throw PrayerDataException("Bu il için ilçe listesi bulunamadı.")
        return list
    }

    private fun nameOf(element: OverpassElement): String? {
        val tags = element.tags ?: return null
        val name = (tags["name:tr"] ?: tags["name"])?.trim()
        return if (name.isNullOrEmpty()) null else name
    }

    private suspend fun runOverpass(query: String): List<OverpassElement> {
        var last: Exception? = null
        for (url in OVERPASS_URLS) {
            try {
                return overpass.query(url, query).elements.orEmpty()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IOException("Sunucuya ulaşılamadı.")
    }

    private suspend fun <T> cached(
        name: String,
        type: Type,
        fetch: suspend () -> List<T>
    ): Result<List<T>> = withContext(Dispatchers.IO) {
        val file = File(context.filesDir, "loc_$name.json")
        val stored: List<T>? = if (file.exists()) {
            try {
                gson.fromJson<List<T>>(file.readText(), type)
            } catch (e: Exception) {
                null
            }
        } else {
            null
        }
        val fresh = System.currentTimeMillis() - file.lastModified() < CACHE_TTL_MS
        if (!stored.isNullOrEmpty() && fresh) return@withContext Result.success(stored)
        try {
            val list = fetch()
            file.writeText(gson.toJson(list))
            Result.success(list)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (!stored.isNullOrEmpty()) Result.success(stored) else Result.failure(e)
        }
    }

    private fun childrenQuery(id: Long): String = """
        [out:json][timeout:60];
        rel($id)->.p;
        rel(r.p)["boundary"="administrative"]["admin_level"="6"];
        out tags center;
    """.trimIndent()

    private fun areaQuery(id: Long): String = """
        [out:json][timeout:60];
        rel($id);
        map_to_area->.p;
        rel(area.p)["boundary"="administrative"]["admin_level"="6"];
        out tags center;
    """.trimIndent()

    private companion object {
        const val PROVINCES_QUERY = """[out:json][timeout:60];
rel["boundary"="administrative"]["admin_level"="4"]["ISO3166-2"~"^TR-"](35.5,25.5,42.5,45.0);
out tags;"""
        val OVERPASS_URLS = listOf(
            "https://overpass-api.de/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter"
        )
        const val MIN_PROVINCES = 70
        const val CACHE_TTL_MS = 180L * 24 * 60 * 60 * 1000
        const val MAX_REFERENCE_KM = 150.0
        const val EARTH_RADIUS_KM = 6371.0
    }
}
