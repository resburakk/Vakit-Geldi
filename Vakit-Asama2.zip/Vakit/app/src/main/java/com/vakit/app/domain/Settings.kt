package com.vakit.app.domain

enum class ThemeMode { SYSTEM, LIGHT, DARK }

val REMINDER_OPTIONS: List<Int> = listOf(0, 5, 10, 15, 30)

data class AppSettings(
    val notify: Map<Prayer, Boolean> = Prayer.entries.associateWith { true },
    val sound: Boolean = true,
    val vibration: Boolean = true,
    val reminderMinutes: Int = 0,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val statusNotification: Boolean = true
) {
    fun isEnabled(prayer: Prayer): Boolean = notify[prayer] ?: true
}
