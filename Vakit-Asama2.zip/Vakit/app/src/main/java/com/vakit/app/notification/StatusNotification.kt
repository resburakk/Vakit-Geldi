package com.vakit.app.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.vakit.app.MainActivity
import com.vakit.app.R
import com.vakit.app.domain.Prayer
import com.vakit.app.domain.PrayerClock
import com.vakit.app.vakitApp
import kotlinx.coroutines.flow.first
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

/**
 * Günün vakitlerini ve şu an girmiş olan vakti gösteren sabit (ongoing) bildirim.
 * Foreground service kullanılmaz; içerik her vakitte ve gece yarısında alarmla, ayrıca
 * uygulama açıldığında yenilenir. Android 14 ve üzerinde kullanıcı bu bildirimi kaydırarak
 * kapatabilir; bir sonraki yenilemede yeniden gösterilir.
 */
object StatusNotification {
    private const val CHANNEL_ID = "vakit_durum"
    const val NOTIFICATION_ID = 2
    private val TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm")

    suspend fun sync(context: Context) {
        val app = context.vakitApp
        val manager = context.getSystemService(NotificationManager::class.java)
        val settings = app.settingsRepository.settings.first()
        val location = app.settingsRepository.location.first()
        if (!settings.statusNotification || location == null) {
            manager.cancel(NOTIFICATION_ID)
            app.alarmScheduler.cancelStatusAlarm()
            return
        }

        val zone = ZoneId.of(location.timezoneId)
        val now = ZonedDateTime.now(zone)
        val date = now.toLocalDate()
        val days = app.repository.getRange(location, date, date.plusDays(1))
        val today = days.firstOrNull { it.date == date }
        val tomorrow = days.firstOrNull { it.date == date.plusDays(1) }
        if (today == null) {
            manager.cancel(NOTIFICATION_ID)
            app.alarmScheduler.cancelStatusAlarm()
            return
        }

        val current = PrayerClock.currentPrayer(today, now)
        val next = PrayerClock.nextPrayer(today, tomorrow, now)

        // Bir sonraki yenileme: sıradaki vakit ya da gece yarısı, hangisi önceyse.
        val midnight = date.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli() + 1_000L
        val nextAt = next?.at?.toInstant()?.toEpochMilli() ?: midnight
        app.alarmScheduler.scheduleStatusAlarm(minOf(nextAt, midnight))

        if (!NotificationHelper.canPost(context)) return

        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Günlük vakitler (sabit bildirim)", NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Günün namaz vakitlerini ve şu anki vakti gösterir"
                setShowBadge(false)
            }
            manager.createNotificationChannel(channel)
        }

        val lines = Prayer.entries.joinToString("\n") { prayer ->
            val marker = if (prayer == current) "● " else "○ "
            val suffix = if (prayer == current) "  (şimdi)" else ""
            marker + prayer.label + " " + today.timeOf(prayer).format(TIME_FORMAT) + suffix
        }
        val summary = next?.let { "Sıradaki: ${it.prayer.label} ${it.at.format(TIME_FORMAT)}" }
            ?: "Yarının vakitleri bekleniyor"
        val title = "${current.label} vakti"

        val openApp = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_vakit)
            .setContentTitle(title)
            .setContentText("${location.label} · $summary")
            .setStyle(NotificationCompat.BigTextStyle().bigText("${location.label}\n$lines"))
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setShowWhen(false)
            .setContentIntent(openApp)
            .build()
        manager.notify(NOTIFICATION_ID, notification)
    }
}
