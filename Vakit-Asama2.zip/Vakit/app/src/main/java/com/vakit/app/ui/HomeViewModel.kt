package com.vakit.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vakit.app.VakitApp
import com.vakit.app.data.userMessage
import com.vakit.app.domain.AppSettings
import com.vakit.app.domain.LocationInfo
import com.vakit.app.domain.PrayerDay
import com.vakit.app.notification.Rescheduler
import com.vakit.app.notification.StatusNotification
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

sealed interface DownloadState {
    data object Idle : DownloadState
    data object Loading : DownloadState
    data class Error(val message: String) : DownloadState
}

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as VakitApp

    @OptIn(ExperimentalCoroutinesApi::class)
    val days: StateFlow<Map<LocalDate, PrayerDay>> = app.settingsRepository.location
        .flatMapLatest { location ->
            if (location == null) flowOf(emptyMap()) else app.repository.observeAll(location)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    val settings: StateFlow<AppSettings> = app.settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    private val _download = MutableStateFlow<DownloadState>(DownloadState.Idle)
    val download: StateFlow<DownloadState> = _download.asStateFlow()

    init {
        viewModelScope.launch {
            app.settingsRepository.location
                .filterNotNull()
                .distinctUntilChanged()
                .collectLatest { location -> prepare(location, force = false) }
        }
    }

    /** Veri yeterli değilse indirir, ardından alarmları ve sabit bildirimi yeniden kurar. */
    private suspend fun prepare(location: LocationInfo, force: Boolean) {
        _download.value = DownloadState.Loading
        val result = if (force) app.repository.refresh(location) else app.repository.ensureData(location)
        _download.value = result.fold(
            onSuccess = { DownloadState.Idle },
            onFailure = { error -> DownloadState.Error(error.userMessage()) }
        )
        Rescheduler.rescheduleAll(app)
    }

    fun onResume() {
        viewModelScope.launch {
            val location = app.settingsRepository.location.first() ?: return@launch
            if (_download.value != DownloadState.Loading) prepare(location, force = false)
        }
    }

    fun retryDownload() {
        viewModelScope.launch {
            val location = app.settingsRepository.location.first() ?: return@launch
            prepare(location, force = true)
        }
    }

    fun setStatusNotification(enabled: Boolean) {
        viewModelScope.launch {
            app.settingsRepository.setStatusNotification(enabled)
            StatusNotification.sync(app)
        }
    }

    fun onNotificationPermissionResult() {
        viewModelScope.launch { StatusNotification.sync(app) }
    }
}
