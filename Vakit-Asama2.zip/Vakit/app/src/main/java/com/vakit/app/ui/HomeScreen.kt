package com.vakit.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vakit.app.data.PrayerTimesRepository
import com.vakit.app.domain.LocationInfo
import com.vakit.app.domain.NextPrayer
import com.vakit.app.domain.Prayer
import com.vakit.app.domain.PrayerClock
import com.vakit.app.notification.NotificationHelper
import com.vakit.app.vakitApp
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val TIME_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val DATE_FORMAT: DateTimeFormatter =
    DateTimeFormatter.ofPattern("d MMMM yyyy, EEEE", Locale("tr", "TR"))

/** Her saniye başında güncel zamanı yayar. Yalnızca ekran görünürken toplanır. */
private fun tickerFlow(zone: ZoneId): Flow<ZonedDateTime> = flow {
    while (true) {
        emit(ZonedDateTime.now(zone))
        delay(1_000L - System.currentTimeMillis() % 1_000L)
    }
}

@Composable
fun HomeScreen(vm: HomeViewModel, location: LocationInfo, onChangeLocation: () -> Unit) {
    val context = LocalContext.current
    val app = context.vakitApp
    val days by vm.days.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val download by vm.download.collectAsStateWithLifecycle()

    val zone = remember(location.timezoneId) { ZoneId.of(location.timezoneId) }
    val now by remember(zone) { tickerFlow(zone) }
        .collectAsStateWithLifecycle(initialValue = ZonedDateTime.now(zone))

    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        tick++
        vm.onResume()
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        tick++
        vm.onNotificationPermissionResult()
    }
    var askedOnce by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        if (!askedOnce && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            askedOnce = true
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val notificationsOk = remember(tick) { NotificationHelper.canPost(context) }
    val exactOk = remember(tick) { app.alarmScheduler.canScheduleExact() }
    val testPlanned = remember(tick) { app.alarmScheduler.isTestScheduled() }
    var message by remember { mutableStateOf("") }

    val date = now.toLocalDate()
    val today = days[date]
    val tomorrow = days[date.plusDays(1)]
    val next = today?.let { PrayerClock.nextPrayer(it, tomorrow, now) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = now.format(DATE_FORMAT),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f)
            )
            OutlinedButton(onClick = onChangeLocation) { Text("Konumu değiştir") }
        }

        HeroCard(
            location = location,
            next = next,
            now = now,
            download = download,
            onRetry = vm::retryDownload
        )

        if (today != null) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "Bugünün vakitleri",
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.padding(start = 14.dp, top = 6.dp, bottom = 4.dp)
                    )
                    Prayer.entries.forEach { prayer ->
                        PrayerRow(
                            prayer = prayer,
                            time = today.timeOf(prayer).format(TIME_FORMAT),
                            passed = !today.zonedTime(prayer).isAfter(now),
                            isNext = next != null && next.prayer == prayer && next.at.toLocalDate() == date
                        )
                    }
                }
            }
        }

        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Bildirimler", style = MaterialTheme.typography.titleMedium)

                if (!notificationsOk) {
                    Text(
                        "Bildirimler kapalı. Vakit bildirimlerini alabilmek için izin vermelisin.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(onClick = { openNotificationSettings(context) }) { Text("Bildirim ayarlarını aç") }
                }
                if (!exactOk) {
                    Text(
                        "Hassas alarm erişimi kapalı: bildirimler birkaç dakika gecikebilir.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedButton(onClick = { openExactAlarmSettings(context) }) { Text("Hassas alarmı aç") }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Sabit vakit bildirimi", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "Günün vakitlerini ve şu anki vakti bildirim çubuğunda gösterir.",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.alpha(0.7f)
                        )
                    }
                    Switch(
                        checked = settings.statusNotification,
                        onCheckedChange = vm::setStatusNotification
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            val ok = NotificationHelper.showTest(context, settings.sound, settings.vibration)
                            message = if (ok) "Test bildirimi gönderildi." else "Bildirim gönderilemedi: izin veya kanal kapalı."
                        }
                    ) { Text("Test bildirimi") }
                    OutlinedButton(
                        onClick = {
                            app.alarmScheduler.scheduleTestAlarm()
                            message = "Test alarmı 2 dakika sonrasına kuruldu. Uygulamayı kapatıp bekle."
                            tick++
                        }
                    ) { Text("2 dk sonra test") }
                }
                if (testPlanned) {
                    TextButton(
                        onClick = {
                            app.alarmScheduler.cancelTestAlarm()
                            message = "Test alarmı iptal edildi."
                            tick++
                        }
                    ) { Text("Test alarmını iptal et") }
                }
                if (message.isNotEmpty()) {
                    Text(message, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        Text(
            text = "Veri kaynağı: ${app.repository.sourceName}",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier
                .alpha(0.65f)
                .padding(horizontal = 4.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun HeroCard(
    location: LocationInfo,
    next: NextPrayer?,
    now: ZonedDateTime,
    download: DownloadState,
    onRetry: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = location.label,
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(14.dp))
            if (next != null) {
                val remainingMs = next.at.toInstant().toEpochMilli() - now.toInstant().toEpochMilli()
                val totalSeconds = maxOf(0L, (remainingMs + 999L) / 1000L)
                Text(
                    text = "${next.prayer.label} vaktine kalan süre",
                    style = MaterialTheme.typography.bodyLarge
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = String.format(
                        Locale.US, "%02d:%02d:%02d",
                        totalSeconds / 3600, totalSeconds % 3600 / 60, totalSeconds % 60
                    ),
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontSize = 52.sp,
                        fontWeight = FontWeight.Bold,
                        fontFeatureSettings = "tnum"
                    ),
                    maxLines = 1
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "${next.prayer.label} · ${next.at.format(TIME_FORMAT)}",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.alpha(0.9f)
                )
            } else if (download is DownloadState.Loading) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary)
                Spacer(Modifier.height(10.dp))
                Text("Vakitler indiriliyor…", style = MaterialTheme.typography.bodyLarge)
            } else {
                Text(
                    text = "Vakitler henüz indirilmedi.",
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center
                )
                if (download is DownloadState.Error) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = download.message,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.onPrimary,
                        contentColor = MaterialTheme.colorScheme.primary
                    )
                ) { Text("Vakitleri indir") }
            }
        }
    }
}

@Composable
private fun PrayerRow(prayer: Prayer, time: String, passed: Boolean, isNext: Boolean) {
    val background = if (isNext) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f) else Color.Transparent
    val contentAlpha = if (passed && !isNext) 0.45f else 1f
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(background)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = prayer.label,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = if (isNext) FontWeight.Bold else FontWeight.Normal
            ),
            modifier = Modifier.alpha(contentAlpha)
        )
        Text(
            text = time,
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.SemiBold,
                fontFeatureSettings = "tnum"
            ),
            modifier = Modifier.alpha(contentAlpha)
        )
    }
}

private fun openNotificationSettings(context: Context) {
    context.startActivity(
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

private fun openExactAlarmSettings(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        context.startActivity(
            Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
