# Vakit (Aşama 2)

Türkçe namaz vakitleri uygulaması.

## Aşama 2 ile gelenler
- İl ve ilçe listeleri internetten alınır (OpenStreetMap Overpass), cihazda saklanır; koordinat elle girilmez.
- Seçilen ilçenin koordinatı sırayla Google (cihazın Geocoder servisi), OpenStreetMap Nominatim ve son çare olarak OSM ilçe merkezinden alınır. Koordinat tahmin edilmez.
- Ana sayfa: konum, sıradaki vakte kalan süre (saat:dakika:saniye), günün vakitleri, konumu değiştirme düğmesi.
- Sabit vakit bildirimi (açılıp kapatılabilir): günün vakitlerini ve şu anki vakti gösterir. Foreground service kullanılmaz.
- Aşama 1'den: vakit alarmları, yeniden başlatma sonrası yeniden planlama, test bildirimi/alarmı.

## Derleme
Android Studio'da `Vakit` klasörünü aç, `Build > Build APK(s)` ile debug APK üret.

## Veri kaynakları
- Namaz vakitleri: AlAdhan Prayer Times API, Diyanet yöntemi (method=13). Diyanet'in resmî yayınıyla birebir aynı olduğu garanti edilmez.
- İl/ilçe listeleri ve sınırlar: © OpenStreetMap katkıcıları (ODbL), Overpass API üzerinden.
- Koordinat arama: Android Geocoder (Google) ve OpenStreetMap Nominatim.

## Bilinen sınırlar
- Android'in force-stop davranışı ve üreticiye özgü pil kısıtlamaları nedeniyle bildirimin her koşulda zamanında gelmesi garanti edilemez.
- Android 14 ve üzerinde kullanıcı sabit bildirimi kaydırarak kapatabilir; uygulama açılınca veya bir sonraki vakitte yeniden gösterilir.
