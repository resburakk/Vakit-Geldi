package com.vakit.app

import com.vakit.app.util.searchKey
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SearchKeyTest {
    @Test
    fun turkishCharactersAreNormalized() {
        assertEquals("istanbul", "İstanbul".searchKey())
        assertEquals("sanliurfa", "ŞANLIURFA".searchKey())
        assertEquals("kadikoy", "Kadıköy".searchKey())
    }

    @Test
    fun plainAsciiQueryMatchesTurkishName() {
        assertTrue("Çanakkale".searchKey().contains("canak"))
        assertTrue("Üsküdar".searchKey().contains("uskudar"))
    }
}
