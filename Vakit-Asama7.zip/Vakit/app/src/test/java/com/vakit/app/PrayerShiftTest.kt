package com.vakit.app

import com.vakit.app.domain.Prayer
import com.vakit.app.domain.PrayerDay
import java.time.LocalDate
import java.time.LocalTime
import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Test

class PrayerShiftTest {
    private val day = PrayerDay(
        date = LocalDate.of(2026, 10, 30),
        imsak = LocalTime.of(5, 20), gunes = LocalTime.of(6, 55), ogle = LocalTime.of(12, 40),
        ikindi = LocalTime.of(15, 30), aksam = LocalTime.of(18, 10), yatsi = LocalTime.of(19, 35),
        timezoneId = "Europe/Istanbul"
    )

    @Test
    fun zeroOffsetsReturnSameInstance() {
        assertSame(day, day.shifted(Prayer.entries.associateWith { 0 }))
    }

    @Test
    fun offsetsShiftOnlyChosenPrayers() {
        val shifted = day.shifted(mapOf(Prayer.AKSAM to 2, Prayer.YATSI to 1, Prayer.IMSAK to -1))
        assertEquals(LocalTime.of(18, 12), shifted.aksam)
        assertEquals(LocalTime.of(19, 36), shifted.yatsi)
        assertEquals(LocalTime.of(5, 19), shifted.imsak)
        assertEquals(day.ogle, shifted.ogle)
    }
}
