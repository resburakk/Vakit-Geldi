package com.vakit.app

import com.vakit.app.data.remote.AlAdhanMapper
import com.vakit.app.data.remote.CalendarResponse
import com.vakit.app.data.remote.DateDto
import com.vakit.app.data.remote.DayDto
import com.vakit.app.data.remote.GregorianDto
import com.vakit.app.data.remote.MetaDto
import com.vakit.app.data.remote.PrayerDataException
import com.vakit.app.data.remote.TimingsDto
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

class AlAdhanMapperTest {

    private fun day(
        fajr: String = "05:12 (+03)",
        sunrise: String = "06:41 (+03)",
        dhuhr: String = "12:40 (+03)",
        asr: String = "15:58 (+03)",
        maghrib: String = "18:21 (+03)",
        isha: String = "19:43 (+03)",
        date: String = "11-10-2026",
        zone: String? = "Europe/Istanbul"
    ) = DayDto(
        TimingsDto(fajr, sunrise, dhuhr, asr, maghrib, isha),
        DateDto(GregorianDto(date)),
        MetaDto(zone)
    )

    @Test
    fun parseTime_stripsTimezoneSuffix() {
        assertEquals(LocalTime.of(5, 12), AlAdhanMapper.parseTime("05:12 (+03)"))
    }

    @Test
    fun parseTime_rejectsInvalidValues() {
        assertNull(AlAdhanMapper.parseTime("25:00"))
        assertNull(AlAdhanMapper.parseTime("12:75"))
        assertNull(AlAdhanMapper.parseTime("abc"))
        assertNull(AlAdhanMapper.parseTime(null))
    }

    @Test
    fun parseDate_readsDayMonthYear() {
        assertEquals(LocalDate.of(2026, 10, 11), AlAdhanMapper.parseDate("11-10-2026"))
        assertNull(AlAdhanMapper.parseDate("2026-10-11"))
    }

    @Test
    fun map_validResponse() {
        val days = AlAdhanMapper.map(CalendarResponse(200, "OK", listOf(day())), "Europe/Istanbul")
        assertEquals(1, days.size)
        assertEquals(LocalTime.of(18, 21), days[0].aksam)
        assertEquals(LocalTime.of(6, 41), days[0].gunes)
        assertEquals("Europe/Istanbul", days[0].timezoneId)
    }

    @Test
    fun map_skipsBrokenDays_andFallsBackToDefaultZone() {
        val response = CalendarResponse(200, "OK", listOf(day(fajr = "xx"), day(zone = "Bilinmeyen/Yer")))
        val days = AlAdhanMapper.map(response, "Europe/Istanbul")
        assertEquals(1, days.size)
        assertEquals("Europe/Istanbul", days[0].timezoneId)
    }

    @Test
    fun map_skipsDayWhenSunriseIsOutOfOrder() {
        val response = CalendarResponse(200, "OK", listOf(day(), day(sunrise = "13:00 (+03)")))
        assertEquals(1, AlAdhanMapper.map(response, "Europe/Istanbul").size)
    }

    @Test
    fun map_throwsOnBadCodeOrEmptyData() {
        assertThrows(PrayerDataException::class.java) {
            AlAdhanMapper.map(CalendarResponse(500, "ERR", null), "Europe/Istanbul")
        }
        assertThrows(PrayerDataException::class.java) {
            AlAdhanMapper.map(CalendarResponse(200, "OK", emptyList()), "Europe/Istanbul")
        }
        assertThrows(PrayerDataException::class.java) {
            AlAdhanMapper.map(CalendarResponse(200, "OK", listOf(day(fajr = "xx"))), "Europe/Istanbul")
        }
    }
}
