package com.vakit.app

import com.vakit.app.domain.QiblaCalculator
import org.junit.Assert.assertEquals
import org.junit.Test

class QiblaCalculatorTest {

    @Test
    fun istanbul_bearingIsSouthEast() {
        // İstanbul'dan kıble yaklaşık 151.6° (güneydoğu).
        assertEquals(151.6, QiblaCalculator.bearing(41.0082, 28.9784), 0.5)
    }

    @Test
    fun sameLongitudeSouthOfKaaba_pointsNorth() {
        assertEquals(0.0, QiblaCalculator.bearing(0.0, QiblaCalculator.KAABA_LON), 0.01)
    }

    @Test
    fun distanceIsZeroAtKaaba() {
        assertEquals(0.0, QiblaCalculator.distanceKm(QiblaCalculator.KAABA_LAT, QiblaCalculator.KAABA_LON), 0.01)
    }

    @Test
    fun directionNames() {
        assertEquals("Güneydoğu", QiblaCalculator.directionName(151.6))
        assertEquals("Kuzey", QiblaCalculator.directionName(359.0))
        assertEquals("Batı", QiblaCalculator.directionName(270.0))
    }
}
