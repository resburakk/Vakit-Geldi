package com.vakit.app

import com.vakit.app.domain.Prayer
import com.vakit.app.notification.AlarmCodes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class AlarmCodesTest {

    @Test
    fun codes_areUniqueAcrossDaysPrayersAndKinds() {
        val codes = HashSet<Int>()
        var total = 0
        for (offset in 0 until 10L) {
            val date = LocalDate.of(2026, 12, 28).plusDays(offset)
            for (prayer in Prayer.entries) {
                for (reminder in listOf(false, true)) {
                    codes += AlarmCodes.prayerCode(date, prayer, reminder)
                    total++
                }
            }
        }
        assertEquals(total, codes.size)
    }

    @Test
    fun codes_doNotCollideWithTestAlarm_andStayPositive() {
        val code = AlarmCodes.prayerCode(LocalDate.of(2099, 12, 31), Prayer.YATSI, reminder = true)
        assertTrue(code > 0)
        assertFalse(code == AlarmCodes.TEST_REQUEST_CODE)
    }
}
