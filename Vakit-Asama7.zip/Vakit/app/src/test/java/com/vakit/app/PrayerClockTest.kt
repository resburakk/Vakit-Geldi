package com.vakit.app

import com.vakit.app.domain.Prayer
import com.vakit.app.domain.PrayerClock
import com.vakit.app.domain.PrayerDay
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

class PrayerClockTest {
    private val zone = ZoneId.of("Europe/Istanbul")
    private val d1 = LocalDate.of(2026, 10, 11)

    private fun day(date: LocalDate) = PrayerDay(
        date,
        LocalTime.of(5, 12), LocalTime.of(6, 41), LocalTime.of(12, 40), LocalTime.of(15, 58),
        LocalTime.of(18, 21), LocalTime.of(19, 43),
        "Europe/Istanbul"
    )

    private fun at(h: Int, m: Int, s: Int = 0, date: LocalDate = d1) =
        ZonedDateTime.of(date, LocalTime.of(h, m, s), zone)

    @Test
    fun duringDay_currentAndNext() {
        val now = at(13, 0)
        assertEquals(Prayer.OGLE, PrayerClock.currentPrayer(day(d1), now))
        assertEquals(Prayer.IKINDI, PrayerClock.nextPrayer(day(d1), day(d1.plusDays(1)), now)?.prayer)
    }

    @Test
    fun betweenImsakAndOgle_gunesIsNext() {
        val now = at(6, 0)
        assertEquals(Prayer.IMSAK, PrayerClock.currentPrayer(day(d1), now))
        assertEquals(Prayer.GUNES, PrayerClock.nextPrayer(day(d1), null, now)?.prayer)
        val later = at(7, 0)
        assertEquals(Prayer.GUNES, PrayerClock.currentPrayer(day(d1), later))
        assertEquals(Prayer.OGLE, PrayerClock.nextPrayer(day(d1), null, later)?.prayer)
    }

    @Test
    fun afterIsha_nextIsTomorrowImsak() {
        val now = at(21, 0)
        val next = PrayerClock.nextPrayer(day(d1), day(d1.plusDays(1)), now)
        assertNotNull(next)
        assertEquals(Prayer.IMSAK, next?.prayer)
        assertEquals(d1.plusDays(1), next?.at?.toLocalDate())
        assertEquals(Prayer.YATSI, PrayerClock.currentPrayer(day(d1), now))
    }

    @Test
    fun afterIsha_withoutTomorrowData_returnsNull() {
        assertNull(PrayerClock.nextPrayer(day(d1), null, at(21, 0)))
    }

    @Test
    fun beforeImsak_currentIsIsha_nextIsTodayImsak() {
        val now = at(3, 0)
        assertEquals(Prayer.YATSI, PrayerClock.currentPrayer(day(d1), now))
        assertEquals(Prayer.IMSAK, PrayerClock.nextPrayer(day(d1), null, now)?.prayer)
    }

    @Test
    fun exactlyAtPrayerTime_prayerIsCurrent() {
        val now = at(12, 40, 0)
        assertEquals(Prayer.OGLE, PrayerClock.currentPrayer(day(d1), now))
        assertEquals(Prayer.IKINDI, PrayerClock.nextPrayer(day(d1), null, now)?.prayer)
    }
}
