package com.vakit.app.notification

import android.content.Context
import com.vakit.app.vakitApp
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.LocalDate
import java.time.ZoneId

/** Kayıtlı konum, ayar ve Room verisine göre alarmları ve sabit bildirimi yeniden kurar. */
object Rescheduler {
    private val mutex = Mutex()
    const val HORIZON_DAYS = 7

    suspend fun rescheduleAll(context: Context): Int {
        val count = mutex.withLock {
            val app = context.vakitApp
            val scheduler = app.alarmScheduler
            val location = app.settingsRepository.location.first()
            if (location == null) {
                scheduler.cancelPrayerAlarms()
                0
            } else {
                val settings = app.settingsRepository.settings.first()
                val today = LocalDate.now(ZoneId.of(location.timezoneId))
                val days = app.repository.getRange(location, today, today.plusDays(HORIZON_DAYS.toLong()))
                scheduler.schedulePrayerAlarms(location, days, settings)
            }
        }
        StatusNotification.sync(context)
        return count
    }
}
