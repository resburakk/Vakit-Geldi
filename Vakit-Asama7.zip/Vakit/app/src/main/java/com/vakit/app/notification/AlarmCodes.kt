package com.vakit.app.notification

import com.vakit.app.domain.Prayer
import java.time.LocalDate

object AlarmCodes {
    const val TEST_REQUEST_CODE = 1
    const val TEST_NOTIFICATION_ID = 1
    const val STATUS_REQUEST_CODE = 2

    /**
     * Her (gün, vakit, tür) için benzersiz kimlik:
     * yyyyMMdd * 100 + (hatırlatma ? 10 : 0) + vakit sırası (0..5).
     * Test (1) ve sabit bildirim (2) kimlikleriyle çakışmaz; 2147 yılına kadar Int sınırları içinde kalır.
     */
    fun prayerCode(date: LocalDate, prayer: Prayer, reminder: Boolean): Int {
        val ymd = date.year * 10000 + date.monthValue * 100 + date.dayOfMonth
        return ymd * 100 + (if (reminder) 10 else 0) + prayer.ordinal
    }
}
