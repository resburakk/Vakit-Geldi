package com.vakit.app.data.remote

import com.google.gson.annotations.SerializedName
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.http.Url

/** OpenStreetMap Overpass API: il ve ilçe listelerini (idari sınırlar) verir. */
interface OverpassApi {
    @FormUrlEncoded
    @POST
    suspend fun query(@Url url: String, @Field("data") data: String): OverpassResponse
}

data class OverpassResponse(val elements: List<OverpassElement>?)

data class OverpassElement(
    val id: Long?,
    val tags: Map<String, String>?,
    val center: OverpassCenter?
)

data class OverpassCenter(val lat: Double?, val lon: Double?)

/** OpenStreetMap Nominatim: ücretsiz, anahtarsız adres arama (koordinat için yedek kaynak). */
interface NominatimApi {
    @GET("search")
    suspend fun search(
        @Query("q") query: String,
        @Query("format") format: String,
        @Query("limit") limit: Int,
        @Query("countrycodes") countryCodes: String,
        @Query("accept-language") language: String
    ): List<NominatimResult>
}

data class NominatimResult(
    val lat: String?,
    val lon: String?,
    @SerializedName("display_name") val displayName: String?
)
