package com.vakit.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vakit.app.VakitApp
import com.vakit.app.data.location.District
import com.vakit.app.data.location.Province
import com.vakit.app.data.location.ResolvedLocation
import com.vakit.app.data.userMessage
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface Async<out T> {
    data object Loading : Async<Nothing>
    data class Success<T>(val data: T) : Async<T>
    data class Failure(val message: String) : Async<Nothing>
}

enum class PickerStep { PROVINCE, DISTRICT, CONFIRM }

data class PickerUiState(
    val step: PickerStep = PickerStep.PROVINCE,
    val provinces: Async<List<Province>> = Async.Loading,
    val province: Province? = null,
    val districts: Async<List<District>> = Async.Loading,
    val district: District? = null,
    val resolving: Boolean = false,
    val resolved: ResolvedLocation? = null,
    val resolveError: String? = null,
    val saving: Boolean = false,
    val saveError: String? = null
)

class PickerViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as VakitApp
    private val _state = MutableStateFlow(PickerUiState())
    val state: StateFlow<PickerUiState> = _state.asStateFlow()
    private var resolveJob: Job? = null

    private fun <T> Result<T>.toAsync(): Async<T> = fold(
        onSuccess = { value -> Async.Success(value) },
        onFailure = { error -> Async.Failure(error.userMessage()) }
    )

    /** Ekran her açıldığında başa döner ve il listesini yükler. */
    fun start() {
        resolveJob?.cancel()
        _state.value = PickerUiState()
        loadProvinces()
    }

    fun loadProvinces() {
        _state.update { it.copy(provinces = Async.Loading) }
        viewModelScope.launch {
            val result = app.locationRepository.provinces()
            _state.update { current -> current.copy(provinces = result.toAsync()) }
        }
    }

    fun selectProvince(province: Province) {
        _state.update {
            it.copy(step = PickerStep.DISTRICT, province = province, districts = Async.Loading, district = null)
        }
        loadDistricts(province)
    }

    private fun loadDistricts(province: Province) {
        viewModelScope.launch {
            val result = app.locationRepository.districts(province)
            _state.update { current -> current.copy(districts = result.toAsync()) }
        }
    }

    fun retryDistricts() {
        val province = _state.value.province ?: return
        _state.update { it.copy(districts = Async.Loading) }
        loadDistricts(province)
    }

    fun selectDistrict(district: District) {
        _state.update {
            it.copy(
                step = PickerStep.CONFIRM,
                district = district,
                resolved = null,
                resolveError = null,
                saveError = null
            )
        }
        resolve()
    }

    fun resolve() {
        val snapshot = _state.value
        val province = snapshot.province ?: return
        val district = snapshot.district ?: return
        resolveJob?.cancel()
        _state.update { it.copy(resolving = true, resolved = null, resolveError = null) }
        resolveJob = viewModelScope.launch {
            val result = app.locationRepository.resolve(province, district)
            _state.update { current ->
                current.copy(
                    resolving = false,
                    resolved = result.getOrNull(),
                    resolveError = result.exceptionOrNull()?.userMessage()
                )
            }
        }
    }

    /** Bir adım geri gider; zaten ilk adımdaysa false döner. */
    fun back(): Boolean = when (_state.value.step) {
        PickerStep.PROVINCE -> false
        PickerStep.DISTRICT -> {
            _state.update { it.copy(step = PickerStep.PROVINCE) }
            true
        }
        PickerStep.CONFIRM -> {
            resolveJob?.cancel()
            _state.update { it.copy(step = PickerStep.DISTRICT, resolving = false, saveError = null) }
            true
        }
    }

    /** Önce vakitleri indirir; başarılıysa konumu kaydeder ve ana sayfaya geçer. */
    fun confirm(onDone: () -> Unit) {
        val resolved = _state.value.resolved ?: return
        if (_state.value.saving) return
        _state.update { it.copy(saving = true, saveError = null) }
        viewModelScope.launch {
            val result = app.repository.refresh(resolved.location)
            if (result.isSuccess) {
                app.settingsRepository.setLocation(resolved.location)
                _state.update { it.copy(saving = false) }
                onDone()
            } else {
                _state.update {
                    it.copy(saving = false, saveError = result.exceptionOrNull()?.userMessage())
                }
            }
        }
    }
}
