package com.vakit.app

import android.app.Application
import android.content.Context
import com.vakit.app.data.AlAdhanDataSource
import com.vakit.app.data.PrayerTimesRepository
import com.vakit.app.data.SettingsRepository
import com.vakit.app.data.local.VakitDatabase
import com.vakit.app.data.location.GeocoderSource
import com.vakit.app.data.location.LocationRepository
import com.vakit.app.data.remote.NetworkModule
import com.vakit.app.notification.AlarmScheduler

class VakitApp : Application() {
    val database: VakitDatabase by lazy { VakitDatabase.create(this) }
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(this) }
    val repository: PrayerTimesRepository by lazy {
        PrayerTimesRepository(
            dao = database.prayerDao(),
            source = AlAdhanDataSource(NetworkModule.alAdhanApi),
            settings = settingsRepository
        )
    }
    val locationRepository: LocationRepository by lazy {
        LocationRepository(
            context = this,
            overpass = NetworkModule.overpassApi,
            nominatim = NetworkModule.nominatimApi,
            geocoder = GeocoderSource(this)
        )
    }
    val alarmScheduler: AlarmScheduler by lazy { AlarmScheduler(this) }
}

val Context.vakitApp: VakitApp get() = applicationContext as VakitApp
