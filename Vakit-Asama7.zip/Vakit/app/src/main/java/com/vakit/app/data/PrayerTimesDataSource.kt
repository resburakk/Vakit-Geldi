package com.vakit.app.data

import com.vakit.app.data.remote.AlAdhanApi
import com.vakit.app.data.remote.AlAdhanMapper
import com.vakit.app.domain.LocationInfo
import com.vakit.app.domain.PrayerDay

/**
 * Namaz vakti kaynağı sözleşmesi. Gelecekte Diyanet'in resmî API'sine veya başka bir
 * servise geçmek için yalnızca bu arayüzün yeni bir uygulaması yazılır.
 */
interface PrayerTimesDataSource {
    val sourceName: String

    suspend fun fetchMonth(
        latitude: Double,
        longitude: Double,
        year: Int,
        month: Int
    ): List<PrayerDay>
}

class AlAdhanDataSource(private val api: AlAdhanApi) : PrayerTimesDataSource {
    override val sourceName: String =
        "AlAdhan Prayer Times API (Diyanet hesaplama yöntemi, method=13). " +
            "Vakitler Diyanet'in resmî yayınıyla birebir aynı olmayabilir."

    override suspend fun fetchMonth(
        latitude: Double,
        longitude: Double,
        year: Int,
        month: Int
    ): List<PrayerDay> {
        val response = api.calendar(year, month, latitude, longitude, DIYANET_METHOD)
        return AlAdhanMapper.map(response, LocationInfo.DEFAULT_TIMEZONE)
    }

    private companion object {
        const val DIYANET_METHOD = 13
    }
}
