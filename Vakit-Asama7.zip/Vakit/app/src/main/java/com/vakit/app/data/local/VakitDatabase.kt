package com.vakit.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [PrayerDayEntity::class], version = 2, exportSchema = false)
abstract class VakitDatabase : RoomDatabase() {
    abstract fun prayerDao(): PrayerDao

    companion object {
        fun create(context: Context): VakitDatabase =
            Room.databaseBuilder(context.applicationContext, VakitDatabase::class.java, "vakit.db")
                .fallbackToDestructiveMigration()
                .build()
    }
}
