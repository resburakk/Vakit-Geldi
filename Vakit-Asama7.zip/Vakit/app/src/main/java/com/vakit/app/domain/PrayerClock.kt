package com.vakit.app.domain

import java.time.ZonedDateTime

data class NextPrayer(val prayer: Prayer, val at: ZonedDateTime)

object PrayerClock {
    /** Girmiş olan son vakit. İmsaktan önce önceki gecenin yatsı vakti sayılır. */
    fun currentPrayer(today: PrayerDay, now: ZonedDateTime): Prayer =
        Prayer.entries.lastOrNull { !today.zonedTime(it).isAfter(now) } ?: Prayer.YATSI

    /** Sıradaki vakit. Bütün vakitler geçtiyse yarının imsakı (yarının verisi varsa). */
    fun nextPrayer(today: PrayerDay, tomorrow: PrayerDay?, now: ZonedDateTime): NextPrayer? {
        val upcoming = Prayer.entries.firstOrNull { today.zonedTime(it).isAfter(now) }
        if (upcoming != null) return NextPrayer(upcoming, today.zonedTime(upcoming))
        return tomorrow?.let { NextPrayer(Prayer.IMSAK, it.zonedTime(Prayer.IMSAK)) }
    }
}
