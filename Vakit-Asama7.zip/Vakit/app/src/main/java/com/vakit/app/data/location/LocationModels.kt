package com.vakit.app.data.location

import com.vakit.app.domain.LocationInfo

data class Province(val id: Long, val name: String)

data class District(val name: String, val lat: Double? = null, val lon: Double? = null)

data class GeoPoint(val lat: Double, val lon: Double)

data class ResolvedLocation(val location: LocationInfo, val source: String)
