package com.vakit.app.util

import java.text.Normalizer
import java.util.Locale

private val MARKS = Regex("\\p{M}+")

/** Aramada Türkçe karakterleri yok sayar: "İstanbul", "istanbul" ve "ISTANBUL" aynı anahtarı üretir. */
fun String.searchKey(): String {
    val lower = lowercase(Locale("tr", "TR"))
    val decomposed = Normalizer.normalize(lower, Normalizer.Form.NFD)
    return MARKS.replace(decomposed, "").replace('ı', 'i')
}
