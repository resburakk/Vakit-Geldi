package com.vakit.app.data.remote

import com.google.gson.annotations.SerializedName
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface AlAdhanApi {
    @GET("calendar/{year}/{month}")
    suspend fun calendar(
        @Path("year") year: Int,
        @Path("month") month: Int,
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("method") method: Int
    ): CalendarResponse
}

data class CalendarResponse(
    val code: Int?,
    val status: String?,
    val data: List<DayDto>?
)

data class DayDto(
    val timings: TimingsDto?,
    val date: DateDto?,
    val meta: MetaDto?
)

data class TimingsDto(
    @SerializedName("Fajr") val fajr: String?,
    @SerializedName("Sunrise") val sunrise: String?,
    @SerializedName("Dhuhr") val dhuhr: String?,
    @SerializedName("Asr") val asr: String?,
    @SerializedName("Maghrib") val maghrib: String?,
    @SerializedName("Isha") val isha: String?
)

data class DateDto(val gregorian: GregorianDto?)

data class GregorianDto(val date: String?)

data class MetaDto(val timezone: String?)
