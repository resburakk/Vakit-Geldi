package com.vakit.app.ui

import android.graphics.Paint
import android.graphics.Typeface
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.vakit.app.domain.LocationInfo
import com.vakit.app.domain.QiblaCalculator
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/** Dönüş vektörü sensöründen gerçek kuzeye göre yön (derece) üretir; ani titremeyi yumuşatır. */
private class HeadingListener(
    private val declination: Float,
    private val onHeading: (Float) -> Unit,
    private val onAccuracy: (Int) -> Unit
) : SensorEventListener {
    private val rotation = FloatArray(9)
    private val remapped = FloatArray(9)
    private val orientation = FloatArray(3)
    private var sinAvg = 0.0
    private var cosAvg = 0.0
    private var started = false

    override fun onSensorChanged(event: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(rotation, event.values)
        // Telefon dik tutuluyorsa (ekran kullanıcıya dönük) eksenleri yeniden eşle.
        val upright = abs(rotation[8]) < 0.5f
        if (upright) {
            SensorManager.remapCoordinateSystem(rotation, SensorManager.AXIS_X, SensorManager.AXIS_Z, remapped)
        } else {
            System.arraycopy(rotation, 0, remapped, 0, 9)
        }
        SensorManager.getOrientation(remapped, orientation)
        val radians = Math.toRadians(Math.toDegrees(orientation[0].toDouble()) + declination)
        if (!started) {
            sinAvg = sin(radians)
            cosAvg = cos(radians)
            started = true
        } else {
            sinAvg += SMOOTHING * (sin(radians) - sinAvg)
            cosAvg += SMOOTHING * (cos(radians) - cosAvg)
        }
        onHeading(((Math.toDegrees(atan2(sinAvg, cosAvg)) + 360.0) % 360.0).toFloat())
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = onAccuracy(accuracy)

    private companion object {
        const val SMOOTHING = 0.2
    }
}

@Composable
fun QiblaScreen(location: LocationInfo, onBack: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val view = LocalView.current

    val qibla = remember(location) { QiblaCalculator.bearing(location.latitude, location.longitude) }
    val distanceKm = remember(location) { QiblaCalculator.distanceKm(location.latitude, location.longitude) }
    val declination = remember(location) {
        GeomagneticField(location.latitude.toFloat(), location.longitude.toFloat(), 0f, System.currentTimeMillis())
            .declination
    }

    var heading by remember { mutableFloatStateOf(0f) }
    var hasHeading by remember { mutableStateOf(false) }
    var accuracy by remember { mutableIntStateOf(SensorManager.SENSOR_STATUS_ACCURACY_HIGH) }

    val sensorManager = remember { context.getSystemService(SensorManager::class.java) }
    val sensor = remember { sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) }

    // Pusula açıkken ekran kapanmasın.
    DisposableEffect(view) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    // Sensör yalnızca ekran görünürken dinlenir (pil tasarrufu).
    DisposableEffect(lifecycleOwner, sensor) {
        if (sensor == null) return@DisposableEffect onDispose { }
        val listener = HeadingListener(
            declination = declination,
            onHeading = { value ->
                heading = value
                hasHeading = true
            },
            onAccuracy = { value -> accuracy = value }
        )
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME ->
                    sensorManager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
                Lifecycle.Event.ON_PAUSE -> sensorManager.unregisterListener(listener)
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            sensorManager.unregisterListener(listener)
        }
    }

    val diff = (((qibla - heading + 540.0) % 360.0) - 180.0).toFloat()
    val aligned = hasHeading && abs(diff) <= ALIGNED_DEGREES

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Geri") }
            Text("Kıble Pusulası", style = MaterialTheme.typography.titleLarge)
        }
        Text(location.label, style = MaterialTheme.typography.titleMedium)

        CompassDial(
            heading = heading,
            qibla = qibla.toFloat(),
            aligned = aligned,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
        )

        val status = when {
            sensor == null -> "Bu cihazda pusula sensörü bulunamadı."
            !hasHeading -> "Pusula bekleniyor…"
            aligned -> "Kıble yönündesin ✓"
            diff > 0 -> "Telefonu ${abs(diff).roundToInt()}° sağa çevir"
            else -> "Telefonu ${abs(diff).roundToInt()}° sola çevir"
        }
        Text(
            text = status,
            style = MaterialTheme.typography.titleMedium,
            color = if (aligned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )
        Text(
            text = "Kıble yönü: ${qibla.roundToInt()}° (${QiblaCalculator.directionName(qibla)})",
            style = MaterialTheme.typography.bodyLarge
        )
        Text(
            text = String.format(Locale("tr", "TR"), "Kâbe'ye uzaklık: %,.0f km", distanceKm),
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.alpha(0.8f)
        )
        if (sensor != null && accuracy <= SensorManager.SENSOR_STATUS_ACCURACY_LOW) {
            Text(
                "Pusula doğruluğu düşük. Telefonu havada 8 çizerek kalibre et.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
                textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "Telefonu yere paralel veya dik tut. Hoparlör, mıknatıs ve metal eşyalardan uzak dur. " +
                "Ok üstteki işaretle hizalanınca Kâbe yönüne bakıyorsun.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.alpha(0.7f),
            textAlign = TextAlign.Center
        )
    }
}

private const val ALIGNED_DEGREES = 3f

@Composable
private fun CompassDial(heading: Float, qibla: Float, aligned: Boolean, modifier: Modifier = Modifier) {
    val scheme = MaterialTheme.colorScheme
    val dialColor = scheme.surfaceVariant
    val lineColor = scheme.onSurface
    val outline = scheme.outline
    val north = scheme.error
    val accent = if (aligned) scheme.primary else scheme.tertiary
    val pointer = scheme.primary

    Canvas(modifier = modifier) {
        val c = Offset(size.width / 2f, size.height / 2f)
        val radius = size.minDimension / 2f * 0.86f
        val tickColor = lineColor.copy(alpha = 0.55f)

        // Kadran, telefonun dönüşünün tersine döner; K harfi hep gerçek kuzeyi gösterir.
        rotate(degrees = -heading, pivot = c) {
            drawCircle(color = dialColor, radius = radius, center = c)
            drawCircle(color = outline, radius = radius, center = c, style = Stroke(width = 2.dp.toPx()))

            for (i in 0 until 72) {
                val angle = Math.toRadians(i * 5.0)
                val length = when {
                    i % 18 == 0 -> 16.dp.toPx()
                    i % 6 == 0 -> 12.dp.toPx()
                    else -> 7.dp.toPx()
                }
                val dir = Offset(sin(angle).toFloat(), -cos(angle).toFloat())
                drawLine(
                    color = tickColor,
                    start = c + dir * (radius - length),
                    end = c + dir * radius,
                    strokeWidth = if (i % 6 == 0) 2.dp.toPx() else 1.dp.toPx()
                )
            }

            val paint = Paint().apply {
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
                textSize = 20.sp.toPx()
                typeface = Typeface.DEFAULT_BOLD
            }
            listOf("K" to 0.0, "D" to 90.0, "G" to 180.0, "B" to 270.0).forEach { (label, degrees) ->
                val a = Math.toRadians(degrees)
                val pos = c + Offset(sin(a).toFloat(), -cos(a).toFloat()) * (radius - 38.dp.toPx())
                paint.color = (if (degrees == 0.0) north else lineColor).toArgb()
                // Harfler kadranla dönmesin, hep okunur dursun.
                rotate(degrees = heading, pivot = pos) {
                    drawContext.canvas.nativeCanvas.drawText(label, pos.x, pos.y + paint.textSize / 3f, paint)
                }
            }

            // Kıble işareti
            rotate(degrees = qibla, pivot = c) {
                val tip = Offset(c.x, c.y - radius * 0.78f)
                drawLine(
                    color = accent,
                    start = c,
                    end = tip,
                    strokeWidth = 5.dp.toPx(),
                    cap = StrokeCap.Round
                )
                drawCircle(color = accent, radius = 14.dp.toPx(), center = tip)
                drawCircle(color = dialColor, radius = 5.dp.toPx(), center = tip)
            }
        }

        // Sabit işaret: telefonun baktığı yön
        val path = Path().apply {
            moveTo(c.x - 11.dp.toPx(), c.y - radius - 20.dp.toPx())
            lineTo(c.x + 11.dp.toPx(), c.y - radius - 20.dp.toPx())
            lineTo(c.x, c.y - radius - 2.dp.toPx())
            close()
        }
        drawPath(path = path, color = pointer)
        drawCircle(color = lineColor, radius = 6.dp.toPx(), center = c)
    }
}
