package com.vakit.app.notification

import android.content.Context

/** Aynı vakit için ikinci bildirimi engelleyen basit kayıt. */
object FiredLog {
    private const val PREFS = "vakit_fired"
    private const val KEEP_MS = 3L * 24 * 60 * 60 * 1000

    /** Anahtar ilk kez işaretleniyorsa true, daha önce işaretlenmişse false döner. */
    @Synchronized
    fun markOnce(context: Context, key: String, nowMillis: Long): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.contains(key)) return false
        val editor = prefs.edit()
        prefs.all.forEach { (k, v) -> if (v is Long && nowMillis - v > KEEP_MS) editor.remove(k) }
        editor.putLong(key, nowMillis)
        editor.commit()
        return true
    }
}
