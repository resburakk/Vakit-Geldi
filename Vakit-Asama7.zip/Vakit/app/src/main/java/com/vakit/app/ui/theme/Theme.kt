package com.vakit.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.vakit.app.domain.ColorTheme
import com.vakit.app.domain.ThemeMode

private fun light(
    primary: Long, container: Long, onContainer: Long, secondary: Long, tertiary: Long,
    background: Long, surfaceVariant: Long, text: Long, outline: Long
): ColorScheme = lightColorScheme(
    primary = Color(primary),
    onPrimary = Color.White,
    primaryContainer = Color(container),
    onPrimaryContainer = Color(onContainer),
    secondary = Color(secondary),
    tertiary = Color(tertiary),
    background = Color(background),
    surface = Color.White,
    surfaceVariant = Color(surfaceVariant),
    onBackground = Color(text),
    onSurface = Color(text),
    outline = Color(outline)
)

private fun dark(
    primary: Long, onPrimary: Long, container: Long, onContainer: Long, secondary: Long, tertiary: Long,
    background: Long, surface: Long, surfaceVariant: Long, text: Long, outline: Long
): ColorScheme = darkColorScheme(
    primary = Color(primary),
    onPrimary = Color(onPrimary),
    primaryContainer = Color(container),
    onPrimaryContainer = Color(onContainer),
    secondary = Color(secondary),
    tertiary = Color(tertiary),
    background = Color(background),
    surface = Color(surface),
    surfaceVariant = Color(surfaceVariant),
    onBackground = Color(text),
    onSurface = Color(text),
    outline = Color(outline)
)

private fun schemeFor(theme: ColorTheme, darkMode: Boolean): ColorScheme = when (theme) {
    ColorTheme.NANE ->
        if (darkMode) dark(0xFF8FD6BE, 0xFF06382B, 0xFF244A3E, 0xFFCDEBDF, 0xFF9CCDBB, 0xFFE6CC8A,
            0xFF0F1613, 0xFF17201C, 0xFF26332D, 0xFFE0E8E4, 0xFF7C918A)
        else light(0xFF3E8E78, 0xFFCDEBDF, 0xFF14382D, 0xFF7FB8A4, 0xFFD9B66A,
            0xFFF3FAF6, 0xFFE3F0EA, 0xFF1E2925, 0xFF7C918A)

    ColorTheme.LAVANTA ->
        if (darkMode) dark(0xFFC6B9F2, 0xFF2C2358, 0xFF3E356B, 0xFFE3DBF6, 0xFFB8ACE0, 0xFFE8BFD6,
            0xFF14121D, 0xFF1C1928, 0xFF2C2840, 0xFFE6E3EE, 0xFF8D87A3)
        else light(0xFF7360B5, 0xFFE3DBF6, 0xFF2A2152, 0xFFA597D6, 0xFFD9A8C6,
            0xFFF8F6FD, 0xFFECE8F7, 0xFF25222F, 0xFF8D87A3)

    ColorTheme.SEFTALI ->
        if (darkMode) dark(0xFFF4B59C, 0xFF4D2312, 0xFF5C3A2C, 0xFFFBDDD0, 0xFFE8B8A3, 0xFFE2CE8C,
            0xFF1A1411, 0xFF241B17, 0xFF362A24, 0xFFEFE4DE, 0xFFA38A7E)
        else light(0xFFC2704F, 0xFFFBDDD0, 0xFF4A2112, 0xFFE3A58C, 0xFFC9B36A,
            0xFFFFF8F4, 0xFFF8E8E0, 0xFF2D2420, 0xFFA38A7E)

    ColorTheme.GOKYUZU ->
        if (darkMode) dark(0xFFA8CCF2, 0xFF0C3358, 0xFF2C4A6C, 0xFFD3E6F8, 0xFF9DBFE3, 0xFFCBBFEA,
            0xFF0F1620, 0xFF18212C, 0xFF273445, 0xFFE0E6EE, 0xFF7F8EA1)
        else light(0xFF4F83B8, 0xFFD3E6F8, 0xFF11304F, 0xFF8DB6DE, 0xFFB9A8DE,
            0xFFF4F8FC, 0xFFE3EDF7, 0xFF1F2630, 0xFF7F8EA1)
}

/** Ayarlardaki renk örneği için temanın pastel rengi. */
fun colorThemePreview(theme: ColorTheme): Color = schemeFor(theme, darkMode = false).primaryContainer

@Composable
fun VakitTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    colorTheme: ColorTheme = ColorTheme.NANE,
    content: @Composable () -> Unit
) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    MaterialTheme(colorScheme = schemeFor(colorTheme, dark), content = content)
}
