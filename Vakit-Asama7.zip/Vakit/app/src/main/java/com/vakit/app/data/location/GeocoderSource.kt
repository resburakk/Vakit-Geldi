package com.vakit.app.data.location

import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import kotlin.coroutines.resume

/**
 * Cihazın Geocoder servisi (Google Play Hizmetleri varsa Google'ın konum servisini kullanır).
 * API anahtarı ve konum izni gerekmez; internet gerekir.
 */
class GeocoderSource(private val context: Context) {

    @Suppress("DEPRECATION")
    suspend fun find(query: String): GeoPoint? = withTimeoutOrNull(10_000L) {
        if (!Geocoder.isPresent()) return@withTimeoutOrNull null
        val geocoder = Geocoder(context, Locale("tr", "TR"))
        val address: Address? = if (Build.VERSION.SDK_INT >= 33) {
            suspendCancellableCoroutine<Address?> { cont ->
                geocoder.getFromLocationName(query, 1, object : Geocoder.GeocodeListener {
                    override fun onGeocode(addresses: MutableList<Address>) {
                        if (cont.isActive) cont.resume(addresses.firstOrNull())
                    }

                    override fun onError(errorMessage: String?) {
                        if (cont.isActive) cont.resume(null)
                    }
                })
            }
        } else {
            withContext(Dispatchers.IO) {
                try {
                    geocoder.getFromLocationName(query, 1)?.firstOrNull()
                } catch (e: Exception) {
                    null
                }
            }
        }
        if (address != null && address.hasLatitude() && address.hasLongitude()) {
            GeoPoint(address.latitude, address.longitude)
        } else {
            null
        }
    }
}
