package com.vakit.app.data.remote

import com.vakit.app.domain.PrayerDay
import java.time.DateTimeException
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException

class PrayerDataException(message: String) : Exception(message)

object AlAdhanMapper {
    private val TIME_REGEX = Regex("""^\s*(\d{1,2}):(\d{2})""")
    private val DATE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-uuuu")

    /** "05:12 (+03)" gibi değerlerden yalnızca saat:dakika kısmını okur. */
    fun parseTime(raw: String?): LocalTime? {
        val match = TIME_REGEX.find(raw ?: return null) ?: return null
        val hour = match.groupValues[1].toInt()
        val minute = match.groupValues[2].toInt()
        if (hour !in 0..23 || minute !in 0..59) return null
        return LocalTime.of(hour, minute)
    }

    /** AlAdhan miladi tarih biçimi: gg-AA-yyyy */
    fun parseDate(raw: String?): LocalDate? = try {
        if (raw == null) null else LocalDate.parse(raw.trim(), DATE_FORMAT)
    } catch (e: DateTimeParseException) {
        null
    }

    private fun validZone(id: String?): Boolean = try {
        id != null && ZoneId.of(id) != null
    } catch (e: DateTimeException) {
        false
    }

    fun map(response: CalendarResponse, fallbackZoneId: String): List<PrayerDay> {
        if (response.code != 200) {
            throw PrayerDataException("Sunucu yanıtı geçersiz (kod: ${response.code}).")
        }
        val rawDays = response.data
        if (rawDays.isNullOrEmpty()) throw PrayerDataException("Namaz vakti verisi boş geldi.")
        val days = rawDays.mapNotNull { mapDay(it, fallbackZoneId) }
        if (days.isEmpty()) throw PrayerDataException("Namaz vakitleri okunamadı.")
        return days
    }

    private fun mapDay(dto: DayDto, fallbackZoneId: String): PrayerDay? {
        val t = dto.timings ?: return null
        val date = parseDate(dto.date?.gregorian?.date) ?: return null
        val imsak = parseTime(t.fajr) ?: return null
        val gunes = parseTime(t.sunrise) ?: return null
        val ogle = parseTime(t.dhuhr) ?: return null
        val ikindi = parseTime(t.asr) ?: return null
        val aksam = parseTime(t.maghrib) ?: return null
        val yatsi = parseTime(t.isha) ?: return null
        if (!(imsak < gunes && gunes < ogle && ogle < ikindi && ikindi < aksam)) return null
        val zone = dto.meta?.timezone?.takeIf { validZone(it) } ?: fallbackZoneId
        return PrayerDay(date, imsak, gunes, ogle, ikindi, aksam, yatsi, zone)
    }
}
