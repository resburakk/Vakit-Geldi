# Aşama 1: küçültme (R8) kapalı olduğu için özel kural gerekmiyor.
