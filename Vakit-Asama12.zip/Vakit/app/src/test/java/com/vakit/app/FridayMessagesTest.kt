package com.vakit.app

import com.vakit.app.domain.FridayMessages
import java.time.LocalDate
import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FridayMessagesTest {

    @Test
    fun bankHasEnoughVersesAndWishes() {
        assertTrue(FridayMessages.VERSES.size >= 30)
        assertTrue(FridayMessages.WISHES.size >= 10)
        assertTrue(FridayMessages.VERSES.all { it.text.isNotBlank() && it.source.isNotBlank() })
    }

    @Test
    fun sameDateSameMessage() {
        val friday = LocalDate.of(2026, 10, 30)
        assertEquals(FridayMessages.forDate(friday), FridayMessages.forDate(friday))
    }

    @Test
    fun consecutiveFridaysUseDifferentVerses() {
        var date = LocalDate.of(2026, 10, 30)
        val seen = HashSet<Int>()
        repeat(FridayMessages.VERSES.size) {
            assertTrue(seen.add(FridayMessages.forDate(date).verseIndex))
            date = date.plusWeeks(1)
        }
    }

    @Test
    fun newMessageNeverRepeatsVerseUntilAllUsed() {
        var current = FridayMessages.forDate(LocalDate.of(2026, 10, 30))
        var used = emptySet<Int>()
        val random = Random(7)
        val seen = mutableSetOf(current.verseIndex)
        repeat(FridayMessages.VERSES.size - 1) {
            val (next, newUsed) = FridayMessages.next(current, used, random)
            assertTrue("ayet tekrar etti", seen.add(next.verseIndex))
            current = next
            used = newUsed
        }
        // Hepsi kullanıldı: liste sıfırlanır ve bir önceki ayet tekrar gelmez.
        val (after, _) = FridayMessages.next(current, used, random)
        assertNotEquals(current.verseIndex, after.verseIndex)
    }
}
