package com.vakit.app

import com.vakit.app.domain.AppSettings
import com.vakit.app.domain.Prayer
import org.junit.Assert.assertEquals
import org.junit.Test

class DefaultOffsetsTest {
    @Test
    fun aksamAndYatsiDefaultToPlusOne() {
        val settings = AppSettings()
        assertEquals(1, settings.offsetOf(Prayer.AKSAM))
        assertEquals(1, settings.offsetOf(Prayer.YATSI))
        assertEquals(0, settings.offsetOf(Prayer.OGLE))
    }
}
