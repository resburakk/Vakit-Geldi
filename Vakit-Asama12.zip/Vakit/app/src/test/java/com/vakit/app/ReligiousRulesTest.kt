package com.vakit.app

import com.vakit.app.domain.DayKind
import com.vakit.app.domain.HijriDay
import com.vakit.app.domain.ReligiousRules
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ReligiousRulesTest {
    private fun hijri(date: String, day: Int, month: Int, year: Int = 1446) =
        HijriDay(LocalDate.parse(date), day, month, year)

    @Test
    fun beratKandili_is14Saban() {
        val result = ReligiousRules.derive(listOf(hijri("2025-02-13", 14, 8), hijri("2025-02-14", 15, 8)))
        val berat = result.single { it.name == "Berat Kandili" }
        assertEquals(LocalDate.parse("2025-02-13"), berat.date)
        assertEquals(DayKind.KANDIL, berat.kind)
        assertNotNull(berat.notifyText)
    }

    @Test
    fun regaip_isFirstThursdayOfRecep() {
        // 1 Recep 1446 = 1 Ocak 2025 (Çarşamba); ilk Perşembe 2 Ocak, ikinci Perşembe 9 Ocak.
        val result = ReligiousRules.derive(
            listOf(hijri("2025-01-01", 1, 7), hijri("2025-01-02", 2, 7), hijri("2025-01-09", 9, 7))
        )
        val regaip = result.filter { it.name == "Regaip Kandili" }
        assertEquals(1, regaip.size)
        assertEquals(LocalDate.parse("2025-01-02"), regaip.single().date)
    }

    @Test
    fun ramazanBayrami_hasArifeAndNotificationOnlyOnFirstDay() {
        val result = ReligiousRules.derive(
            listOf(hijri("2025-03-30", 1, 10), hijri("2025-03-31", 2, 10), hijri("2025-04-01", 3, 10))
        )
        val arife = result.single { it.name == "Ramazan Bayramı Arifesi" }
        assertEquals(LocalDate.parse("2025-03-29"), arife.date)
        assertNull(arife.notifyTitle)
        val first = result.single { it.name == "Ramazan Bayramı 1. Gün" }
        assertEquals("Ramazan Bayramı", first.notifyTitle)
        assertNull(result.single { it.name == "Ramazan Bayramı 2. Gün" }.notifyTitle)
    }

    @Test
    fun kurbanBayrami_hasFourDays() {
        val days = (9..13).map { HijriDay(LocalDate.of(2025, 6, it - 3), it, 12, 1446) }
        val result = ReligiousRules.derive(days)
        assertEquals(4, result.count { it.kind == DayKind.BAYRAM })
        assertTrue(result.any { it.name == "Kurban Bayramı Arifesi" })
    }

    @Test
    fun ramazanAndKadir() {
        val result = ReligiousRules.derive(listOf(hijri("2025-03-01", 1, 9), hijri("2025-03-26", 26, 9)))
        assertEquals(LocalDate.parse("2025-03-26"), result.single { it.name == "Kadir Gecesi" }.date)
        assertEquals(LocalDate.parse("2025-03-01"), result.single { it.name == "Ramazan Başlangıcı" }.date)
    }
}
