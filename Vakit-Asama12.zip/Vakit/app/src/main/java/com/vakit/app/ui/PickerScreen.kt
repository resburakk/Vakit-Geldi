package com.vakit.app.ui

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vakit.app.data.location.District
import com.vakit.app.data.location.Province
import com.vakit.app.util.searchKey
import java.util.Locale

@Composable
fun LocationPickerScreen(
    vm: PickerViewModel,
    canCancel: Boolean,
    onCancel: () -> Unit,
    onDone: () -> Unit
) {
    val state by vm.state.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.start() }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.any { it }) vm.useDeviceLocation() else vm.locationDenied()
    }

    BackHandler(enabled = state.step != PickerStep.PROVINCE || canCancel) {
        if (!vm.back()) onCancel()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (state.step != PickerStep.PROVINCE || canCancel) {
                TextButton(onClick = { if (!vm.back()) onCancel() }) { Text("← Geri") }
            }
            Text(
                text = when (state.step) {
                    PickerStep.PROVINCE -> "İl seç"
                    PickerStep.DISTRICT -> "İlçe seç · ${state.province?.name.orEmpty()}"
                    PickerStep.CONFIRM -> "Konumu onayla"
                },
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(start = 4.dp)
            )
        }
        Spacer(Modifier.height(8.dp))

        when (state.step) {
            PickerStep.PROVINCE -> when (val provinces = state.provinces) {
                is Async.Loading -> LoadingBox("İller internetten alınıyor…")
                is Async.Failure -> ErrorBox(provinces.message, onRetry = vm::loadProvinces)
                is Async.Success -> {
                    OutlinedButton(
                        onClick = {
                            if (vm.hasLocationPermission()) {
                                vm.useDeviceLocation()
                            } else {
                                permissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_COARSE_LOCATION,
                                        Manifest.permission.ACCESS_FINE_LOCATION
                                    )
                                )
                            }
                        },
                        enabled = !state.locating,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (state.locating) "Konum aranıyor…" else "Konumumu otomatik bul") }
                    state.locateError?.let { message ->
                        Text(
                            message,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    SearchableList(
                        items = provinces.data,
                        nameOf = { province: Province -> province.name },
                        onPick = vm::selectProvince
                    )
                }
            }

            PickerStep.DISTRICT -> when (val districts = state.districts) {
                is Async.Loading -> LoadingBox("İlçeler internetten alınıyor…")
                is Async.Failure -> ErrorBox(districts.message, onRetry = vm::retryDistricts)
                is Async.Success -> SearchableList(
                    items = districts.data,
                    nameOf = { district: District -> district.name },
                    onPick = vm::selectDistrict
                )
            }

            PickerStep.CONFIRM -> ConfirmStep(state = state, vm = vm, onDone = onDone)
        }
    }
}

@Composable
private fun <T> SearchableList(items: List<T>, nameOf: (T) -> String, onPick: (T) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val needle = query.searchKey().trim()
    val filtered = remember(items, needle) {
        if (needle.isEmpty()) items else items.filter { nameOf(it).searchKey().contains(needle) }
    }
    OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        label = { Text("Ara") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
    Spacer(Modifier.height(6.dp))
    if (filtered.isEmpty()) {
        Text(
            "Sonuç bulunamadı.",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(12.dp)
        )
    }
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(filtered) { item ->
            Text(
                text = nameOf(item),
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onPick(item) }
                    .padding(horizontal = 8.dp, vertical = 15.dp)
            )
            HorizontalDivider()
        }
    }
}

@Composable
private fun ConfirmStep(state: PickerUiState, vm: PickerViewModel, onDone: () -> Unit) {
    val resolved = state.resolved
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "${state.province?.name.orEmpty()} / ${state.district?.name.orEmpty()}",
                    style = MaterialTheme.typography.headlineSmall
                )
                when {
                    state.resolving -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                        Text(
                            "  Koordinatlar internetten alınıyor…",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }

                    state.resolveError != null -> {
                        Text(state.resolveError, color = MaterialTheme.colorScheme.error)
                        OutlinedButton(onClick = vm::resolve) { Text("Tekrar dene") }
                    }

                    resolved != null -> {
                        Text(
                            String.format(
                                Locale.US, "Koordinat: %.4f, %.4f",
                                resolved.location.latitude, resolved.location.longitude
                            ),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            "Kaynak: ${resolved.source}",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.alpha(0.7f)
                        )
                    }
                }
            }
        }

        if (state.saveError != null) {
            Text(state.saveError, color = MaterialTheme.colorScheme.error)
        }

        Button(
            onClick = { vm.confirm(onDone) },
            enabled = resolved != null && !state.saving,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                when {
                    state.saving -> "Vakitler indiriliyor…"
                    state.saveError != null -> "Tekrar dene"
                    else -> "Onayla ve devam et"
                }
            )
        }
    }
}

@Composable
private fun LoadingBox(text: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            CircularProgressIndicator()
            Text(text, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun ErrorBox(message: String, onRetry: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(message, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
            Button(onClick = onRetry) { Text("Tekrar dene") }
        }
    }
}
