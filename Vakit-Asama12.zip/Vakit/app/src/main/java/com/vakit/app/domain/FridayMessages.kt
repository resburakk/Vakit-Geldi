package com.vakit.app.domain

import java.time.LocalDate
import kotlin.random.Random

/** Bir ayet: [source] sûre adı ve numarası, [text] kısa ve sade Türkçe anlamı. */
data class Verse(val source: String, val text: String)

/** Bir Cuma mesajı; ayet, dilek cümlesi ve resim teması dizinlerinden oluşur. */
data class FridayMessage(val verseIndex: Int, val wishIndex: Int, val themeIndex: Int) {
    val verse: Verse get() = FridayMessages.VERSES[verseIndex]
    val wish: String get() = FridayMessages.WISHES[wishIndex]
}

object FridayMessages {
    const val THEME_COUNT = 5

    val VERSES: List<Verse> = listOf(
        Verse("Bakara, 2:152", "Beni anın, ben de sizi anayım. Bana şükredin, nankörlük etmeyin."),
        Verse("Bakara, 2:153", "Ey iman edenler! Sabır ve namazla yardım dileyin. Şüphesiz Allah sabredenlerle beraberdir."),
        Verse("Bakara, 2:186", "Kullarım sana beni sorarsa bilsinler ki ben çok yakınım. Bana dua edenin duasına karşılık veririm."),
        Verse("Bakara, 2:195", "İyilik yapın. Şüphesiz Allah iyilik yapanları sever."),
        Verse("Bakara, 2:286", "Allah hiç kimseye gücünün yetmediği yükü yüklemez."),
        Verse("Âl-i İmrân, 3:134", "Allah, öfkesini yenenleri ve insanları affedenleri sever. Allah iyilik yapanları sever."),
        Verse("Âl-i İmrân, 3:139", "Gevşemeyin, hüzne kapılmayın. İman ediyorsanız üstün olan sizsiniz."),
        Verse("Âl-i İmrân, 3:159", "Karar verdiğinde Allah'a güven. Şüphesiz Allah, kendisine güvenenleri sever."),
        Verse("Âl-i İmrân, 3:173", "Allah bize yeter, O ne güzel vekildir."),
        Verse("Mâide, 5:2", "İyilik ve takvada yardımlaşın, günah ve düşmanlıkta yardımlaşmayın."),
        Verse("A'râf, 7:56", "Allah'ın rahmeti iyilik edenlere çok yakındır."),
        Verse("Enfâl, 8:46", "Sabredin. Şüphesiz Allah sabredenlerle beraberdir."),
        Verse("Tevbe, 9:51", "De ki: Bize ancak Allah'ın bizim için yazdığı gelir. O bizim sahibimizdir. Müminler yalnız Allah'a güvensin."),
        Verse("Yûsuf, 12:87", "Allah'ın rahmetinden ümit kesmeyin."),
        Verse("Ra'd, 13:28", "Bilin ki kalpler ancak Allah'ı anmakla huzur bulur."),
        Verse("İbrâhîm, 14:7", "Eğer şükrederseniz size nimetimi artırırım."),
        Verse("Nahl, 16:90", "Allah adaleti, iyiliği ve akrabaya yardım etmeyi emreder; hayasızlığı ve kötülüğü yasaklar."),
        Verse("Nahl, 16:97", "Erkek ya da kadın, iman ederek salih amel işleyene güzel bir hayat yaşatırız."),
        Verse("İsrâ, 17:23", "Rabbin, yalnız O'na kulluk etmenizi ve anne babaya iyilik etmenizi emretti."),
        Verse("Tâhâ, 20:25-26", "Rabbim, göğsümü genişlet ve işimi kolaylaştır."),
        Verse("Mü'minûn, 23:1-2", "Müminler kurtuluşa ermiştir. Onlar namazlarında huşu içindedirler."),
        Verse("Furkân, 25:63", "Rahman'ın kulları, yeryüzünde tevazu ile yürüyenlerdir."),
        Verse("Ankebût, 29:45", "Namaz, insanı hayasızlıktan ve kötülükten alıkoyar. Allah'ı anmak ise en büyük şeydir."),
        Verse("Rûm, 30:21", "Aranıza sevgi ve merhamet koyması O'nun âyetlerindendir."),
        Verse("Lokmân, 31:17", "Namazı dosdoğru kıl, iyiliği emret, kötülükten alıkoy ve başına gelene sabret."),
        Verse("Ahzâb, 33:41", "Ey iman edenler! Allah'ı çokça anın."),
        Verse("Zümer, 39:10", "Sabredenlere mükâfatları hesapsız olarak verilecektir."),
        Verse("Zümer, 39:53", "Allah'ın rahmetinden ümidinizi kesmeyin. Şüphesiz Allah bütün günahları bağışlar."),
        Verse("Fussılet, 41:34", "Kötülüğü en güzel olanla sav. O zaman aranızda düşmanlık bulunan kişi sıcak bir dost gibi olur."),
        Verse("Şûrâ, 42:43", "Kim sabreder ve bağışlarsa, bu elbette azim gerektiren işlerdendir."),
        Verse("Hucurât, 49:10", "Müminler ancak kardeştir. Kardeşlerinizin arasını düzeltin."),
        Verse("Hucurât, 49:13", "Allah katında en değerliniz, takvada en ileri olanınızdır."),
        Verse("Rahmân, 55:60", "İyiliğin karşılığı yalnız iyiliktir."),
        Verse("Cuma, 62:9", "Ey iman edenler! Cuma günü namaz için çağrıldığınızda Allah'ı anmaya koşun, alışverişi bırakın."),
        Verse("Cuma, 62:10", "Namaz kılınınca yeryüzüne dağılın, Allah'ın lütfundan isteyin ve Allah'ı çok anın ki kurtuluşa eresiniz."),
        Verse("Talâk, 65:2-3", "Kim Allah'a karşı gelmekten sakınırsa, Allah ona bir çıkış yolu açar ve onu ummadığı yerden rızıklandırır."),
        Verse("Duhâ, 93:5", "Rabbin sana verecek, sen de hoşnut olacaksın."),
        Verse("İnşirâh, 94:5-6", "Şüphesiz zorlukla beraber bir kolaylık vardır."),
        Verse("Zilzâl, 99:7", "Kim zerre kadar hayır işlerse karşılığını görür.")
    )

    val WISHES: List<String> = listOf(
        "Cumanız mübarek olsun.",
        "Rabbim dualarınızı kabul etsin.",
        "Bereketli, huzurlu bir Cuma dileriz.",
        "Bu mübarek günün hayrı ve bereketi üzerinize olsun.",
        "Gönlünüz huzurla, evleriniz bereketle dolsun.",
        "Allah işlerinizi kolaylaştırsın.",
        "Nice sağlıklı ve huzurlu Cumalara.",
        "Dualarınız kabul, amelleriniz makbul olsun.",
        "Kalbinize huzur, ömrünüze bereket gelsin.",
        "Bu güzel gün size ve sevdiklerinize hayırlar getirsin.",
        "Rabbim sizi sevdikleriyle birlikte güzel günlere ulaştırsın.",
        "Cuma sabahınız ışık, gününüz hayır olsun."
    )

    /** Aynı tarih için hep aynı mesajı verir; her hafta farklı bir ayet çıkar. */
    fun forDate(date: LocalDate): FridayMessage {
        val week = Math.floorDiv(date.toEpochDay(), 7L).toInt()
        return FridayMessage(
            verseIndex = Math.floorMod(week, VERSES.size),
            wishIndex = Math.floorMod(week * 5 + 2, WISHES.size),
            themeIndex = Math.floorMod(week, THEME_COUNT)
        )
    }

    /**
     * "Yeni mesaj": [current] ve [usedVerses] içindeki ayetleri tekrar etmez. Bütün ayetler
     * kullanıldıysa liste sıfırlanır (yalnızca [current] dışarıda kalır). Yeni kullanılan kümeyi de döndürür.
     */
    fun next(current: FridayMessage?, usedVerses: Set<Int>, random: Random = Random.Default): Pair<FridayMessage, Set<Int>> {
        val used = usedVerses.toMutableSet()
        current?.let { used += it.verseIndex }
        var candidates = VERSES.indices.filter { it !in used }
        if (candidates.isEmpty()) {
            used.clear()
            current?.let { used += it.verseIndex }
            candidates = VERSES.indices.filter { it !in used }
        }
        val verse = candidates.random(random)
        var wish = random.nextInt(WISHES.size)
        if (wish == current?.wishIndex) wish = (wish + 1) % WISHES.size
        var theme = random.nextInt(THEME_COUNT)
        if (theme == current?.themeIndex) theme = (theme + 1) % THEME_COUNT
        used += verse
        return FridayMessage(verse, wish, theme) to used
    }

    /** Bildirimde gösterilen metin. */
    fun notificationText(message: FridayMessage): String =
        "${message.wish}\n${message.verse.text} (${message.verse.source})"
}
