package com.vakit.app.notification

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.vakit.app.domain.AppSettings
import com.vakit.app.domain.LocationInfo
import com.vakit.app.domain.Prayer
import com.vakit.app.domain.PrayerDay
import java.time.LocalDate

class AlarmScheduler(private val context: Context) {
    private val alarmManager: AlarmManager = context.getSystemService(AlarmManager::class.java)
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Android 12+ için "Alarmlar ve hatırlatıcılar" özel erişimi verilmiş mi? */
    fun canScheduleExact(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()

    fun scheduledCount(): Int = prefs.getStringSet(KEY_CODES, emptySet())?.size ?: 0

    /**
     * Önce önceki namaz alarmlarını iptal eder, sonra verilen günler için gelecekteki
     * alarmları kurar. Kapalı vakitler ve geçmiş zamanlar atlanır. Kurulan alarm sayısını döndürür.
     */
    @Synchronized
    fun schedulePrayerAlarms(
        location: LocationInfo,
        days: List<PrayerDay>,
        settings: AppSettings,
        nowMillis: Long = System.currentTimeMillis()
    ): Int {
        cancelPrayerAlarms()
        val codes = HashSet<String>()
        val leadMinutes = settings.reminderMinutes
        for (day in days) {
            for (prayer in Prayer.entries) {
                if (!settings.isEnabled(prayer)) continue
                val trigger = day.zonedTime(prayer).toInstant().toEpochMilli()
                if (trigger > nowMillis) {
                    val code = AlarmCodes.prayerCode(day.date, prayer, reminder = false)
                    setAlarm(
                        code, trigger,
                        buildPrayerIntent(KIND_PRAYER, prayer, day.date, trigger, location.label, 0, code)
                    )
                    codes += code.toString()
                }
                if (leadMinutes > 0) {
                    val reminderAt = trigger - leadMinutes * 60_000L
                    if (reminderAt > nowMillis) {
                        val code = AlarmCodes.prayerCode(day.date, prayer, reminder = true)
                        setAlarm(
                            code, reminderAt,
                            buildPrayerIntent(KIND_REMINDER, prayer, day.date, reminderAt, location.label, leadMinutes, code)
                        )
                        codes += code.toString()
                    }
                }
            }
        }
        prefs.edit().putStringSet(KEY_CODES, codes).apply()
        return codes.size
    }

    @Synchronized
    fun cancelPrayerAlarms() {
        val codes = prefs.getStringSet(KEY_CODES, emptySet()).orEmpty().toList()
        for (value in codes) {
            val code = value.toIntOrNull() ?: continue
            val existing = PendingIntent.getBroadcast(
                context, code, baseIntent(ACTION_PRAYER),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE
            )
            if (existing != null) {
                alarmManager.cancel(existing)
                existing.cancel()
            }
        }
        prefs.edit().remove(KEY_CODES).apply()
    }

    /** Test alarmı; gerçek vakit alarmlarından ayrı eylem ve kimlik kullanır. Tetiklenme zamanını döndürür. */
    fun scheduleTestAlarm(delayMillis: Long = TEST_DELAY_MS): Long {
        val triggerAt = System.currentTimeMillis() + delayMillis
        val intent = baseIntent(ACTION_TEST).putExtra(EXTRA_TRIGGER_AT, triggerAt)
        setAlarm(AlarmCodes.TEST_REQUEST_CODE, triggerAt, intent)
        return triggerAt
    }

    fun cancelTestAlarm() {
        val existing = PendingIntent.getBroadcast(
            context, AlarmCodes.TEST_REQUEST_CODE, baseIntent(ACTION_TEST),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE
        )
        if (existing != null) {
            alarmManager.cancel(existing)
            existing.cancel()
        }
    }

    fun isTestScheduled(): Boolean = PendingIntent.getBroadcast(
        context, AlarmCodes.TEST_REQUEST_CODE, baseIntent(ACTION_TEST),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE
    ) != null

    /** Sabit bildirimin içeriğini yenileyen alarm (bir sonraki vakit ya da gece yarısı). */
    fun scheduleStatusAlarm(triggerAt: Long) {
        setAlarm(AlarmCodes.STATUS_REQUEST_CODE, triggerAt, baseIntent(ACTION_STATUS))
    }

    fun cancelStatusAlarm() {
        val existing = PendingIntent.getBroadcast(
            context, AlarmCodes.STATUS_REQUEST_CODE, baseIntent(ACTION_STATUS),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE
        )
        if (existing != null) {
            alarmManager.cancel(existing)
            existing.cancel()
        }
    }

    /** Haftalık Cuma bildirimi için tek alarm; [triggerAt] null ise iptal eder. */
    fun scheduleFridayAlarm(triggerAt: Long?) {
        if (triggerAt == null) {
            cancelBroadcast(AlarmCodes.FRIDAY_REQUEST_CODE, ACTION_FRIDAY)
            return
        }
        setAlarm(
            AlarmCodes.FRIDAY_REQUEST_CODE, triggerAt,
            baseIntent(ACTION_FRIDAY).putExtra(EXTRA_TRIGGER_AT, triggerAt)
        )
    }

    /** Eski kutlama alarmlarını iptal edip verilenleri kurar. */
    @Synchronized
    fun scheduleCelebrations(items: List<CelebrationAlarm>): Int {
        cancelCelebrations()
        val codes = HashSet<String>()
        for (item in items) {
            val code = AlarmCodes.celebrationCode(item.date, item.index)
            setAlarm(
                code, item.triggerAt,
                baseIntent(ACTION_CELEBRATION)
                    .putExtra(EXTRA_TRIGGER_AT, item.triggerAt)
                    .putExtra(EXTRA_TITLE, item.title)
                    .putExtra(EXTRA_TEXT, item.text)
                    .putExtra(EXTRA_KEY, item.key)
                    .putExtra(EXTRA_CODE, code)
            )
            codes += code.toString()
        }
        prefs.edit().putStringSet(KEY_CELEBRATION_CODES, codes).apply()
        return codes.size
    }

    @Synchronized
    fun cancelCelebrations() {
        val codes = prefs.getStringSet(KEY_CELEBRATION_CODES, emptySet()).orEmpty().toList()
        for (value in codes) {
            val code = value.toIntOrNull() ?: continue
            cancelBroadcast(code, ACTION_CELEBRATION)
        }
        prefs.edit().remove(KEY_CELEBRATION_CODES).apply()
    }

    private fun cancelBroadcast(requestCode: Int, action: String) {
        val existing = PendingIntent.getBroadcast(
            context, requestCode, baseIntent(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE
        )
        if (existing != null) {
            alarmManager.cancel(existing)
            existing.cancel()
        }
    }

    private fun baseIntent(action: String): Intent =
        Intent(context, NotificationReceiver::class.java).setAction(action)

    private fun buildPrayerIntent(
        kind: String,
        prayer: Prayer,
        date: LocalDate,
        triggerAt: Long,
        locationLabel: String,
        reminderMinutes: Int,
        code: Int
    ): Intent = baseIntent(ACTION_PRAYER)
        .putExtra(EXTRA_KIND, kind)
        .putExtra(EXTRA_PRAYER, prayer.ordinal)
        .putExtra(EXTRA_DATE, date.toString())
        .putExtra(EXTRA_TRIGGER_AT, triggerAt)
        .putExtra(EXTRA_LOCATION, locationLabel)
        .putExtra(EXTRA_REMINDER_MINUTES, reminderMinutes)
        .putExtra(EXTRA_CODE, code)

    /**
     * Kesin alarm erişimi varsa setExactAndAllowWhileIdle, yoksa setAndAllowWhileIdle kullanılır.
     * İkincisi dakik zamanlama garantisi vermez (Android gecikmeli tetikleyebilir).
     */
    private fun setAlarm(requestCode: Int, triggerAt: Long, intent: Intent) {
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        if (canScheduleExact()) {
            try {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
                return
            } catch (e: SecurityException) {
                // Erişim kaldırılmış olabilir; yaklaşık alarma düş.
            }
        }
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
    }

    companion object {
        const val ACTION_PRAYER = "com.vakit.app.action.PRAYER_ALARM"
        const val ACTION_TEST = "com.vakit.app.action.TEST_ALARM"
        const val ACTION_STATUS = "com.vakit.app.action.STATUS_REFRESH"
        const val ACTION_FRIDAY = "com.vakit.app.action.FRIDAY_ALARM"
        const val ACTION_CELEBRATION = "com.vakit.app.action.CELEBRATION_ALARM"
        const val EXTRA_TITLE = "title"
        const val EXTRA_TEXT = "text"
        const val EXTRA_KEY = "key"
        const val KIND_PRAYER = "prayer"
        const val KIND_REMINDER = "reminder"
        const val EXTRA_KIND = "kind"
        const val EXTRA_PRAYER = "prayer"
        const val EXTRA_DATE = "date"
        const val EXTRA_TRIGGER_AT = "trigger_at"
        const val EXTRA_LOCATION = "location"
        const val EXTRA_REMINDER_MINUTES = "reminder_minutes"
        const val EXTRA_CODE = "code"
        const val TEST_DELAY_MS = 120_000L
        private const val PREFS = "vakit_alarms"
        private const val KEY_CODES = "scheduled_codes"
        private const val KEY_CELEBRATION_CODES = "celebration_codes"
    }
}

/** Planlanacak bir kutlama bildirimi. */
data class CelebrationAlarm(
    val date: LocalDate,
    val index: Int,
    val triggerAt: Long,
    val title: String,
    val text: String,
    val key: String
)
