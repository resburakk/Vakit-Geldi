package com.vakit.app.data.remote

import com.google.gson.annotations.SerializedName
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.http.Url

/** TurkiyeAPI: il ve ilçe adlarını hızlı ve ücretsiz verir (koordinat vermez). */
interface TurkiyeApi {
    @GET("v1/provinces")
    suspend fun provinces(
        @Query("fields") fields: String,
        @Query("limit") limit: Int
    ): TurkiyeListResponse<TurkiyeProvince>

    @GET("v1/districts")
    suspend fun districts(
        @Query("provinceId") provinceId: Long,
        @Query("fields") fields: String,
        @Query("limit") limit: Int
    ): TurkiyeListResponse<TurkiyeDistrict>
}

data class TurkiyeListResponse<T>(val status: String?, val data: List<T>?)

data class TurkiyeProvince(val id: Long?, val name: String?)

data class TurkiyeDistrict(val id: Long?, val name: String?)

/** OpenStreetMap Overpass API: il ve ilçe listelerini (idari sınırlar) verir. */
interface OverpassApi {
    @FormUrlEncoded
    @POST
    suspend fun query(@Url url: String, @Field("data") data: String): OverpassResponse
}

data class OverpassResponse(val elements: List<OverpassElement>?)

data class OverpassElement(
    val id: Long?,
    val tags: Map<String, String>?,
    val center: OverpassCenter?
)

data class OverpassCenter(val lat: Double?, val lon: Double?)

/** OpenStreetMap Nominatim: ücretsiz, anahtarsız adres arama (koordinat için yedek kaynak). */
interface NominatimApi {
    @GET("search")
    suspend fun search(
        @Query("q") query: String,
        @Query("format") format: String,
        @Query("limit") limit: Int,
        @Query("countrycodes") countryCodes: String,
        @Query("accept-language") language: String
    ): List<NominatimResult>
}

data class NominatimResult(
    val lat: String?,
    val lon: String?,
    @SerializedName("display_name") val displayName: String?
)
