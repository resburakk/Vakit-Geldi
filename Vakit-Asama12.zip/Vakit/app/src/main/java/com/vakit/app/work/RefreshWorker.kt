package com.vakit.app.work

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.vakit.app.notification.Rescheduler
import com.vakit.app.vakitApp
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

/**
 * Uygulama açılmasa da günde iki kez çalışır: vakit verisi 20 günün altına düştüyse indirir,
 * dinî gün takvimini gerekirse yeniler ve alarmları yeniden kurar.
 */
class RefreshWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext.vakitApp
        var failed = false
        val location = app.settingsRepository.location.first()
        if (location != null && app.repository.ensureData(location, minDays = MIN_DAYS).isFailure) {
            failed = true
        }
        if (app.religiousRepository.ensureFresh().isFailure) failed = true
        Rescheduler.rescheduleAll(applicationContext)
        return if (failed && runAttemptCount < MAX_ATTEMPTS) Result.retry() else Result.success()
    }

    companion object {
        private const val NAME = "vakit_veri_yenileme"
        private const val MIN_DAYS = 20
        private const val MAX_ATTEMPTS = 3

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<RefreshWorker>(12, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, request)
        }
    }
}
