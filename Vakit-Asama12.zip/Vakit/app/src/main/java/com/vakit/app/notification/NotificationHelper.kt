package com.vakit.app.notification

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.vakit.app.MainActivity
import com.vakit.app.R

object NotificationHelper {

    /**
     * Android'de kanal ses/titreşim ayarı oluşturulduktan sonra uygulamadan değiştirilemez.
     * Bu yüzden her ses/titreşim birleşimi için ayrı kanal kullanılır; yalnızca ihtiyaç
     * duyulan kanal oluşturulur.
     */
    fun channelId(sound: Boolean, vibration: Boolean, soundUri: String? = null): String {
        val base = "vakit_vakitler_s${if (sound) 1 else 0}_v${if (vibration) 1 else 0}"
        // Özel sesli kanal, ses adresine göre ayrı oluşturulur (kanal sesi sonradan değiştirilemez).
        return if (!sound || soundUri.isNullOrEmpty()) base else base + "_u" + Integer.toHexString(soundUri.hashCode())
    }

    private fun channelName(sound: Boolean, vibration: Boolean): String = when {
        sound && vibration -> "Vakit bildirimleri (ses + titreşim)"
        sound -> "Vakit bildirimleri (yalnızca ses)"
        vibration -> "Vakit bildirimleri (yalnızca titreşim)"
        else -> "Vakit bildirimleri (sessiz)"
    }

    fun ensureChannel(context: Context, sound: Boolean, vibration: Boolean, soundUri: String? = null): String {
        val manager = context.getSystemService(NotificationManager::class.java)
        val id = channelId(sound, vibration, soundUri)
        if (manager.getNotificationChannel(id) == null) {
            val channel = NotificationChannel(id, channelName(sound, vibration), NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Namaz vakti girişi ve hatırlatma bildirimleri"
                enableVibration(vibration)
                if (vibration) vibrationPattern = longArrayOf(0, 400, 200, 400)
                if (sound) {
                    setSound(
                        if (soundUri.isNullOrEmpty()) Settings.System.DEFAULT_NOTIFICATION_URI else Uri.parse(soundUri),
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                } else {
                    setSound(null, null)
                }
            }
            manager.createNotificationChannel(channel)
        }
        return id
    }

    /** Uygulama bildirimleri sistem ayarlarında açık mı? (Android 13+ izni dahil.) */
    fun canPost(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return false
        return context.getSystemService(NotificationManager::class.java).areNotificationsEnabled()
    }

    fun show(
        context: Context,
        notificationId: Int,
        title: String,
        text: String,
        sound: Boolean,
        vibration: Boolean,
        soundUri: String? = null
    ): Boolean {
        if (!canPost(context)) return false
        val manager = context.getSystemService(NotificationManager::class.java)
        val channelId = ensureChannel(context, sound, vibration, soundUri)
        if (manager.getNotificationChannel(channelId)?.importance == NotificationManager.IMPORTANCE_NONE) return false

        val openApp = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_stat_vakit)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openApp)
            .build()
        // Aynı kimlikle yeniden gönderim bildirimi çoğaltmaz, yenisiyle değiştirir.
        manager.notify(notificationId, notification)
        return true
    }

    fun showTest(context: Context, sound: Boolean, vibration: Boolean): Boolean = show(
        context,
        AlarmCodes.TEST_NOTIFICATION_ID,
        "Test bildirimi",
        "Vakit uygulaması bildirim gönderebiliyor.",
        sound,
        vibration
    )
}
