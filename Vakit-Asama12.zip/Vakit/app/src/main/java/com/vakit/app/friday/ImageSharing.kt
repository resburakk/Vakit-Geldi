package com.vakit.app.friday

import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File

enum class ShareResult { OK, NOT_INSTALLED, FAILED }

/** Görseli uygulamalarda paylaşma ve galeriye kaydetme işleri. */
object ImageSharing {
    const val WHATSAPP = "com.whatsapp"
    const val WHATSAPP_BUSINESS = "com.whatsapp.w4b"
    const val INSTAGRAM = "com.instagram.android"

    /** Paylaşım için görseli önbelleğe yazar ve FileProvider adresini döndürür. */
    fun shareableUri(context: Context, bitmap: Bitmap): Uri? = try {
        val dir = File(context.cacheDir, "shared").apply { mkdirs() }
        val file = File(dir, "hayirli_cuma.png")
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    } catch (e: Exception) {
        null
    }

    /** [targetPackage] null ise sistemin paylaşım menüsü açılır. */
    fun share(context: Context, uri: Uri, targetPackage: String?, text: String): ShareResult {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, text)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (targetPackage != null) setPackage(targetPackage)
        }
        return try {
            if (targetPackage == null) {
                val chooser = Intent.createChooser(intent, "Paylaş")
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                context.startActivity(chooser)
            } else {
                context.startActivity(intent)
            }
            ShareResult.OK
        } catch (e: ActivityNotFoundException) {
            ShareResult.NOT_INSTALLED
        } catch (e: Exception) {
            ShareResult.FAILED
        }
    }

    /** Galeride Pictures/Vakit klasörüne kaydeder (Android 10 ve üzeri, izin gerekmez). */
    fun saveToGallery(context: Context, bitmap: Bitmap): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "hayirli_cuma_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Vakit")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            val stream = resolver.openOutputStream(uri)
            if (stream == null) {
                resolver.delete(uri, null, null)
                false
            } else {
                val ok = stream.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                ok
            }
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            false
        }
    }
}
