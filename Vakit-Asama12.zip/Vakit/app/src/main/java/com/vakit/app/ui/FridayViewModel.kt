package com.vakit.app.ui

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vakit.app.domain.FridayMessage
import com.vakit.app.domain.FridayMessages
import com.vakit.app.friday.FridayImage
import com.vakit.app.friday.ImageSharing
import com.vakit.app.friday.ShareResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZoneId

data class FridayUiState(
    val message: FridayMessage? = null,
    val image: Bitmap? = null,
    val info: String = ""
)

class FridayViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("vakit_friday", Context.MODE_PRIVATE)
    private val date: LocalDate = LocalDate.now(ZoneId.systemDefault())

    private val _state = MutableStateFlow(FridayUiState())
    val state: StateFlow<FridayUiState> = _state.asStateFlow()

    init {
        show(FridayMessages.forDate(date))
    }

    private fun show(message: FridayMessage) {
        viewModelScope.launch {
            val bitmap = withContext(Dispatchers.Default) { FridayImage.render(message, date) }
            _state.update { it.copy(message = message, image = bitmap) }
        }
    }

    /** Daha önce gösterilmemiş bir ayetle yeni mesaj üretir. */
    fun newMessage() {
        val used = prefs.getStringSet(KEY_USED, emptySet()).orEmpty().mapNotNull { it.toIntOrNull() }.toSet()
        val (message, newUsed) = FridayMessages.next(_state.value.message, used)
        prefs.edit().putStringSet(KEY_USED, newUsed.map { it.toString() }.toSet()).apply()
        _state.update { it.copy(info = "") }
        show(message)
    }

    fun shareTo(context: Context, packageName: String?, fallbackPackage: String? = null, appName: String = "") {
        val bitmap = _state.value.image ?: return
        viewModelScope.launch {
            val uri = withContext(Dispatchers.IO) { ImageSharing.shareableUri(context, bitmap) }
            if (uri == null) {
                setInfo("Görsel hazırlanamadı.")
                return@launch
            }
            var result = ImageSharing.share(context, uri, packageName, "Hayırlı Cumalar")
            if (result == ShareResult.NOT_INSTALLED && fallbackPackage != null) {
                result = ImageSharing.share(context, uri, fallbackPackage, "Hayırlı Cumalar")
            }
            when (result) {
                ShareResult.OK -> setInfo("")
                ShareResult.NOT_INSTALLED -> setInfo("$appName bu telefonda bulunamadı.")
                ShareResult.FAILED -> setInfo("Paylaşım açılamadı.")
            }
        }
    }

    fun download(context: Context) {
        val bitmap = _state.value.image ?: return
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { ImageSharing.saveToGallery(context, bitmap) }
            setInfo(if (ok) "Görsel galeriye kaydedildi (Resimler > Vakit)." else "Görsel kaydedilemedi.")
        }
    }

    private fun setInfo(text: String) {
        _state.update { it.copy(info = text) }
    }

    private companion object {
        const val KEY_USED = "used_verses"
    }
}
