package com.vakit.app.ui

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.vakit.app.VakitApp
import com.vakit.app.data.userMessage
import com.vakit.app.domain.LocationInfo
import com.vakit.app.domain.Prayer
import com.vakit.app.domain.PrayerDay
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class MonthlyViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as VakitApp

    private val _month = MutableStateFlow(YearMonth.now())
    val month: StateFlow<YearMonth> = _month.asStateFlow()

    private val _days = MutableStateFlow<Async<List<PrayerDay>>>(Async.Loading)
    val days: StateFlow<Async<List<PrayerDay>>> = _days.asStateFlow()

    private var job: Job? = null

    fun load(location: LocationInfo) {
        job?.cancel()
        _days.value = Async.Loading
        val target = _month.value
        job = viewModelScope.launch {
            val result = app.repository.monthDays(location, target)
            _days.value = result.fold(
                onSuccess = { list -> Async.Success(list) },
                onFailure = { error -> Async.Failure(error.userMessage()) }
            )
        }
    }

    fun shift(months: Long, location: LocationInfo) {
        _month.value = _month.value.plusMonths(months)
        load(location)
    }

    fun today(location: LocationInfo) {
        _month.value = YearMonth.now(ZoneId.of(location.timezoneId))
        load(location)
    }
}

private val MONTH_TITLE: DateTimeFormatter = DateTimeFormatter.ofPattern("LLLL yyyy", Locale("tr", "TR"))
private val DAY_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("d EEE", Locale("tr", "TR"))
private val TIME_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")

@Composable
fun MonthlyScreen(vm: MonthlyViewModel, location: LocationInfo, onBack: () -> Unit) {
    val month by vm.month.collectAsStateWithLifecycle()
    val days by vm.days.collectAsStateWithLifecycle()
    LaunchedEffect(location) { vm.load(location) }
    val today = LocalDate.now(ZoneId.of(location.timezoneId))

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(horizontal = 8.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Geri") }
            Text("Aylık Vakitler", style = MaterialTheme.typography.titleLarge)
        }
        Text(
            location.label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            OutlinedButton(onClick = { vm.shift(-1, location) }) { Text("‹") }
            TextButton(onClick = { vm.today(location) }) {
                Text(
                    month.format(MONTH_TITLE).replaceFirstChar { it.titlecase(Locale("tr", "TR")) },
                    style = MaterialTheme.typography.titleMedium
                )
            }
            OutlinedButton(onClick = { vm.shift(1, location) }) { Text("›") }
        }

        when (val state = days) {
            is Async.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }

            is Async.Failure -> Column(
                modifier = Modifier.fillMaxSize().padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(state.message, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.error)
                Button(onClick = { vm.load(location) }, modifier = Modifier.padding(top = 12.dp)) {
                    Text("Tekrar dene")
                }
            }

            is Async.Success -> {
                HeaderRow()
                HorizontalDivider()
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(state.data, key = { it.date.toString() }) { day -> DayRow(day, day.date == today) }
                }
            }
        }
    }
}

@Composable
private fun HeaderRow() {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp, horizontal = 4.dp)) {
        Text("Gün", style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1.35f))
        Prayer.entries.forEach { prayer ->
            Text(
                prayer.label,
                style = MaterialTheme.typography.labelSmall,
                textAlign = TextAlign.Center,
                maxLines = 1,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun DayRow(day: PrayerDay, isToday: Boolean) {
    val background = if (isToday) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
    else androidx.compose.ui.graphics.Color.Transparent
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(background)
            .padding(vertical = 9.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            day.date.format(DAY_FORMAT),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.weight(1.35f)
        )
        Prayer.entries.forEach { prayer ->
            Text(
                day.timeOf(prayer).format(TIME_FORMAT),
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp, fontFeatureSettings = "tnum"),
                textAlign = TextAlign.Center,
                maxLines = 1,
                fontWeight = if (isToday) FontWeight.SemiBold else FontWeight.Normal,
                modifier = Modifier.weight(1f)
            )
        }
    }
}
