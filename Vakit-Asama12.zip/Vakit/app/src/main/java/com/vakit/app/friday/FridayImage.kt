package com.vakit.app.friday

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.vakit.app.domain.FridayMessage
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

/** Cuma mesajını pastel renkli bir görsele çizer (1080x1350, paylaşıma uygun 4:5 oran). */
object FridayImage {
    const val WIDTH = 1080
    const val HEIGHT = 1350

    private class Palette(val top: Int, val bottom: Int, val ink: Int, val accent: Int, val soft: Int)

    private val PALETTES = listOf(
        Palette(Color.parseColor("#E8F5EE"), Color.parseColor("#B5DBC7"), Color.parseColor("#1D4B3A"), Color.parseColor("#2F7D63"), Color.parseColor("#66FFFFFF")),
        Palette(Color.parseColor("#F0EAFA"), Color.parseColor("#C9BCEA"), Color.parseColor("#3C2D66"), Color.parseColor("#6B55A8"), Color.parseColor("#66FFFFFF")),
        Palette(Color.parseColor("#FFF0E3"), Color.parseColor("#F6C7A6"), Color.parseColor("#6A3A21"), Color.parseColor("#B8693D"), Color.parseColor("#66FFFFFF")),
        Palette(Color.parseColor("#E5F2FC"), Color.parseColor("#B2D4F0"), Color.parseColor("#1F4569"), Color.parseColor("#3B7BB0"), Color.parseColor("#66FFFFFF")),
        Palette(Color.parseColor("#FDE9EF"), Color.parseColor("#F1B7C8"), Color.parseColor("#6A2A3E"), Color.parseColor("#B04E6C"), Color.parseColor("#66FFFFFF"))
    )

    private val DATE_FORMAT: DateTimeFormatter =
        DateTimeFormatter.ofPattern("d MMMM yyyy, EEEE", Locale("tr", "TR"))

    fun render(message: FridayMessage, date: LocalDate): Bitmap {
        val palette = PALETTES[message.themeIndex % PALETTES.size]
        val bitmap = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val w = WIDTH.toFloat()
        val h = HEIGHT.toFloat()

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = LinearGradient(0f, 0f, 0f, h, palette.top, palette.bottom, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        // Yumuşak daireler
        paint.color = palette.soft
        canvas.drawCircle(w * 0.12f, h * 0.92f, 280f, paint)
        canvas.drawCircle(w * 0.96f, h * 0.60f, 210f, paint)
        canvas.drawCircle(w * 0.90f, h * 0.06f, 150f, paint)

        // Hilal ve yıldızlar
        drawCrescent(canvas, w / 2f, 215f, 95f, palette.accent)
        drawStar(canvas, w / 2f + 150f, 150f, 24f, palette.accent)
        drawStar(canvas, w / 2f + 205f, 250f, 14f, palette.accent)
        drawStar(canvas, w / 2f - 175f, 270f, 16f, palette.accent)

        val sidePadding = 120
        val contentWidth = WIDTH - sidePadding * 2
        var y = 380f

        // Başlık
        val title = textPaint(palette.ink, 120f, Typeface.create("serif", Typeface.BOLD))
        y += drawCentered(canvas, "Hayırlı Cumalar", title, contentWidth, sidePadding.toFloat(), y)
        y += 28f

        // Ayraç
        paint.color = palette.accent
        canvas.drawRoundRect(w / 2f - 60f, y, w / 2f + 60f, y + 6f, 3f, 3f, paint)
        y += 56f

        // Ayet: sığana kadar küçülür
        val verseText = "“${message.verse.text}”"
        var verseLayout: StaticLayout? = null
        for (size in floatArrayOf(60f, 56f, 52f, 48f, 44f, 40f, 36f)) {
            val candidate = layout(
                verseText,
                textPaint(palette.ink, size, Typeface.create("serif", Typeface.NORMAL)),
                contentWidth, 1.22f
            )
            verseLayout = candidate
            if (candidate.height <= 470) break
        }
        verseLayout?.let {
            canvas.save()
            canvas.translate(sidePadding.toFloat(), y)
            it.draw(canvas)
            canvas.restore()
            y += it.height + 34f
        }

        // Kaynak
        val source = textPaint(palette.accent, 40f, Typeface.create("sans-serif-medium", Typeface.NORMAL))
        y += drawCentered(canvas, message.verse.source, source, contentWidth, sidePadding.toFloat(), y)
        y += 60f

        // Dilek
        val wish = textPaint(palette.ink, 46f, Typeface.create("serif", Typeface.ITALIC))
        drawCentered(canvas, message.wish, wish, contentWidth, sidePadding.toFloat(), y)

        // Alt bilgi
        val footer = textPaint(palette.ink, 34f, Typeface.create("sans-serif", Typeface.NORMAL))
        footer.alpha = 190
        drawCentered(canvas, date.format(DATE_FORMAT), footer, contentWidth, sidePadding.toFloat(), h - 120f)
        val brand = textPaint(palette.accent, 30f, Typeface.create("sans-serif-medium", Typeface.NORMAL))
        drawCentered(canvas, "Vakit", brand, contentWidth, sidePadding.toFloat(), h - 72f)

        return bitmap
    }

    private fun textPaint(color: Int, size: Float, typeface: Typeface): TextPaint =
        TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = size
            this.typeface = typeface
        }

    private fun layout(text: String, paint: TextPaint, width: Int, spacing: Float): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(0f, spacing)
            .build()

    /** Metni ortalayarak çizer ve yüksekliğini döndürür. */
    private fun drawCentered(canvas: Canvas, text: String, paint: TextPaint, width: Int, x: Float, y: Float): Float {
        val l = layout(text, paint, width, 1.1f)
        canvas.save()
        canvas.translate(x, y)
        l.draw(canvas)
        canvas.restore()
        return l.height.toFloat()
    }

    private fun drawCrescent(canvas: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        val outer = Path().apply { addCircle(cx, cy, r, Path.Direction.CW) }
        val inner = Path().apply { addCircle(cx + r * 0.45f, cy - r * 0.12f, r * 0.82f, Path.Direction.CW) }
        outer.op(inner, Path.Op.DIFFERENCE)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        canvas.drawPath(outer, paint)
    }

    private fun drawStar(canvas: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        val path = Path()
        for (i in 0 until 10) {
            val radius = if (i % 2 == 0) r else r * 0.45f
            val angle = Math.toRadians(-90.0 + i * 36.0)
            val x = cx + radius * cos(angle).toFloat()
            val y = cy + radius * sin(angle).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        canvas.drawPath(path, paint)
    }
}
