package com.vakit.app.data

import android.content.Context
import com.google.gson.Gson
import com.vakit.app.data.remote.AlAdhanApi
import com.vakit.app.data.remote.HijriDayDto
import com.vakit.app.data.remote.PrayerDataException
import com.vakit.app.domain.DayKind
import com.vakit.app.domain.HijriDay
import com.vakit.app.domain.ReligiousDay
import com.vakit.app.domain.ReligiousRules
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

/**
 * Dinî günler: AlAdhan hicrî takviminden (Diyanet yöntemi) önümüzdeki 13 ayın her günü alınır,
 * kandil/bayram/özel günler kurallarla çıkarılır ve cihazda saklanır. Böylece takvim her yıl
 * kendiliğinden güncellenir; internet yokken kayıtlı veri kullanılır.
 */
class ReligiousDaysRepository(
    private val context: Context,
    private val api: AlAdhanApi
) {
    private data class StoredDay(
        val date: String,
        val name: String,
        val kind: String,
        val title: String?,
        val text: String?
    )

    private data class Cache(val fetchedAt: Long, val coverageEnd: String, val days: List<StoredDay>)

    private val gson = Gson()
    private val mutex = Mutex()
    private var loaded = false
    private var coverageEnd: LocalDate? = null
    private var fetchedAt: Long = 0L

    private val _days = MutableStateFlow<List<ReligiousDay>>(emptyList())
    val days: StateFlow<List<ReligiousDay>> = _days.asStateFlow()

    private val _lastUpdate = MutableStateFlow<Long?>(null)
    val lastUpdate: StateFlow<Long?> = _lastUpdate.asStateFlow()

    private fun file() = File(context.filesDir, FILE_NAME)

    /** Kayıtlı veriyi bir kez belleğe alır. */
    suspend fun load() {
        mutex.withLock {
            if (loaded) return
            withContext(Dispatchers.IO) {
                val f = file()
                if (f.exists()) {
                    try {
                        val cache = gson.fromJson(f.readText(), Cache::class.java)
                        if (cache != null) applyCache(cache)
                    } catch (e: Exception) {
                        // Bozuk kayıt yok sayılır, yeniden indirilir.
                    }
                }
            }
            loaded = true
        }
    }

    private fun applyCache(cache: Cache) {
        fetchedAt = cache.fetchedAt
        coverageEnd = runCatching { LocalDate.parse(cache.coverageEnd) }.getOrNull()
        _lastUpdate.value = cache.fetchedAt.takeIf { it > 0 }
        _days.value = cache.days.mapNotNull { stored ->
            val date = runCatching { LocalDate.parse(stored.date) }.getOrNull() ?: return@mapNotNull null
            val kind = runCatching { DayKind.valueOf(stored.kind) }.getOrNull() ?: return@mapNotNull null
            ReligiousDay(date, stored.name, kind, stored.title, stored.text)
        }
    }

    /** Veri eskiyse ya da kapsadığı süre kısaldıysa indirir. */
    suspend fun ensureFresh(today: LocalDate = LocalDate.now()): Result<Int> {
        load()
        val end = coverageEnd
        val stale = _days.value.isEmpty() ||
            end == null ||
            end.isBefore(today.plusDays(MIN_COVERAGE_DAYS)) ||
            System.currentTimeMillis() - fetchedAt > MAX_AGE_MS
        return if (stale) refresh(today) else Result.success(0)
    }

    suspend fun refresh(today: LocalDate = LocalDate.now()): Result<Int> {
        load()
        return withContext(Dispatchers.IO) {
            try {
                var month = YearMonth.from(today)
                val hijri = ArrayList<HijriDay>()
                repeat(MONTHS) { index ->
                    if (index > 0) delay(150)
                    val response = api.hijriCalendar(month.monthValue, month.year, CALENDAR_METHOD)
                    val items = response.data.orEmpty().mapNotNull(::toHijriDay)
                    if (items.isEmpty()) throw PrayerDataException("Takvim verisi alınamadı.")
                    hijri += items
                    month = month.plusMonths(1)
                }
                val derived = ReligiousRules.derive(hijri)
                if (derived.isEmpty()) throw PrayerDataException("Takvimde dinî gün bulunamadı.")
                val end = month.minusMonths(1).atEndOfMonth()
                val now = System.currentTimeMillis()
                val cache = Cache(
                    fetchedAt = now,
                    coverageEnd = end.toString(),
                    days = derived.map {
                        StoredDay(it.date.toString(), it.name, it.kind.name, it.notifyTitle, it.notifyText)
                    }
                )
                file().writeText(gson.toJson(cache))
                mutex.withLock { applyCache(cache) }
                Result.success(derived.size)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    /** Bildirimi olan, [from] anından sonraki günler. */
    suspend fun notifiableFrom(from: LocalDate): List<ReligiousDay> {
        load()
        return _days.value.filter {
            it.notifyTitle != null && it.notifyText != null && !it.date.isBefore(from)
        }
    }

    private fun toHijriDay(dto: HijriDayDto): HijriDay? {
        val hijri = dto.hijri ?: dto.date?.hijri ?: return null
        val gregorian = dto.gregorian ?: dto.date?.gregorian ?: return null
        val day = hijri.day?.trim()?.toIntOrNull() ?: return null
        val month = hijri.month?.number ?: return null
        val year = hijri.year?.trim()?.toIntOrNull() ?: return null
        val date = runCatching { LocalDate.parse(gregorian.date.orEmpty().trim(), DATE_FORMAT) }.getOrNull()
            ?: return null
        return HijriDay(date, day, month, year)
    }

    private companion object {
        const val FILE_NAME = "religious_days_v1.json"
        const val CALENDAR_METHOD = "DIYANET"
        const val MONTHS = 13
        const val MIN_COVERAGE_DAYS = 120L
        const val MAX_AGE_MS = 30L * 24 * 60 * 60 * 1000
        val DATE_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy")
    }
}
