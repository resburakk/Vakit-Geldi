package com.vakit.app.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.vakit.app.domain.FridayMessages
import com.vakit.app.domain.Prayer
import com.vakit.app.domain.SOUND_SILENT
import com.vakit.app.vakitApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId

class NotificationReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action !in HANDLED_ACTIONS) return
        val appContext = context.applicationContext
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
            try {
                when (action) {
                    AlarmScheduler.ACTION_TEST -> handleTest(appContext)
                    AlarmScheduler.ACTION_STATUS -> StatusNotification.sync(appContext)
                    AlarmScheduler.ACTION_FRIDAY -> handleFriday(appContext, intent)
                    AlarmScheduler.ACTION_CELEBRATION -> handleCelebration(appContext, intent)
                    else -> handlePrayer(appContext, intent)
                }
            } catch (e: Exception) {
                // Bildirim hatası uygulamayı çökertmemeli.
            } finally {
                pending.finish()
            }
        }
    }

    private suspend fun handleTest(context: Context) {
        val settings = context.vakitApp.settingsRepository.settings.first()
        NotificationHelper.show(
            context,
            AlarmCodes.TEST_NOTIFICATION_ID,
            "Test alarmı çalıştı",
            "Planlanan test alarmı arka planda başarıyla tetiklendi.",
            settings.sound,
            settings.vibration
        )
    }

    private suspend fun handleFriday(context: Context, intent: Intent) {
        val triggerAt = intent.getLongExtra(AlarmScheduler.EXTRA_TRIGGER_AT, 0L)
        if (triggerAt > 0L) {
            val settings = context.vakitApp.settingsRepository.settings.first()
            val now = System.currentTimeMillis()
            val date = Instant.ofEpochMilli(triggerAt).atZone(ZoneId.systemDefault()).toLocalDate()
            if (settings.fridayNotification &&
                now - triggerAt <= MAX_LATE_CELEBRATION_MS &&
                FiredLog.markOnce(context, "friday:$date", now)
            ) {
                val message = FridayMessages.forDate(date)
                NotificationHelper.show(
                    context, AlarmCodes.FRIDAY_NOTIFICATION_ID, "Hayırlı Cumalar",
                    FridayMessages.notificationText(message), settings.sound, settings.vibration
                )
            }
        }
        // Sonraki Cuma alarmını kur.
        Rescheduler.rescheduleAll(context)
    }

    private suspend fun handleCelebration(context: Context, intent: Intent) {
        val triggerAt = intent.getLongExtra(AlarmScheduler.EXTRA_TRIGGER_AT, 0L)
        val title = intent.getStringExtra(AlarmScheduler.EXTRA_TITLE)
        val text = intent.getStringExtra(AlarmScheduler.EXTRA_TEXT)
        val key = intent.getStringExtra(AlarmScheduler.EXTRA_KEY)
        val code = intent.getIntExtra(AlarmScheduler.EXTRA_CODE, 0)
        if (triggerAt > 0L && title != null && text != null && key != null) {
            val settings = context.vakitApp.settingsRepository.settings.first()
            val now = System.currentTimeMillis()
            if (settings.celebrationNotifications &&
                now - triggerAt <= MAX_LATE_CELEBRATION_MS &&
                FiredLog.markOnce(context, "celebration:$key", now)
            ) {
                NotificationHelper.show(context, code, title, text, settings.sound, settings.vibration)
            }
        }
        Rescheduler.rescheduleAll(context)
    }

    private suspend fun handlePrayer(context: Context, intent: Intent) {
        val kind = intent.getStringExtra(AlarmScheduler.EXTRA_KIND) ?: return
        val prayer = Prayer.entries.getOrNull(intent.getIntExtra(AlarmScheduler.EXTRA_PRAYER, -1)) ?: return
        val date = intent.getStringExtra(AlarmScheduler.EXTRA_DATE) ?: return
        val triggerAt = intent.getLongExtra(AlarmScheduler.EXTRA_TRIGGER_AT, 0L)
        val code = intent.getIntExtra(AlarmScheduler.EXTRA_CODE, 0)
        val location = intent.getStringExtra(AlarmScheduler.EXTRA_LOCATION).orEmpty()
        val minutes = intent.getIntExtra(AlarmScheduler.EXTRA_REMINDER_MINUTES, 0)

        val settings = context.vakitApp.settingsRepository.settings.first()
        val now = System.currentTimeMillis()
        val wanted = settings.isEnabled(prayer) &&
            (kind == AlarmScheduler.KIND_PRAYER ||
                (kind == AlarmScheduler.KIND_REMINDER && settings.reminderMinutes > 0))
        val onTime = now - triggerAt <= MAX_LATE_MS

        if (wanted && onTime && FiredLog.markOnce(context, "$kind:$date:${prayer.name}", now)) {
            val (title, body) = if (kind == AlarmScheduler.KIND_REMINDER) {
                "Vakit Hatırlatması" to "${prayer.label} vaktine $minutes dakika kaldı."
            } else {
                "${prayer.label} Vakti" to "$location için ${prayer.enteredText}"
            }
            val choice = settings.soundOf(prayer)
            NotificationHelper.show(
                context, code, title, body,
                sound = settings.sound && choice != SOUND_SILENT,
                vibration = settings.vibration,
                soundUri = choice.takeIf { it.isNotEmpty() && it != SOUND_SILENT }
            )
        }
        // Planlama ufkunu ileri taşı ve sabit bildirimi güncelle.
        Rescheduler.rescheduleAll(context)
    }

    private companion object {
        val HANDLED_ACTIONS = setOf(
            AlarmScheduler.ACTION_PRAYER,
            AlarmScheduler.ACTION_TEST,
            AlarmScheduler.ACTION_STATUS,
            AlarmScheduler.ACTION_FRIDAY,
            AlarmScheduler.ACTION_CELEBRATION
        )

        /** Cihaz kapalıyken/gecikmeli tetiklenen eski vakit bildirimleri gösterilmez. */
        const val MAX_LATE_MS = 30L * 60 * 1000

        /** Cuma ve kutlama bildirimleri sabah gelir; telefon kapalıysa 6 saat içinde hâlâ gösterilir. */
        const val MAX_LATE_CELEBRATION_MS = 6L * 60 * 60 * 1000
    }
}
