package com.vakit.app.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.IntentCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vakit.app.BuildConfig
import com.vakit.app.domain.ColorTheme
import com.vakit.app.domain.LocationInfo
import com.vakit.app.domain.FridayMessages
import com.vakit.app.domain.MAX_OFFSET_MINUTES
import com.vakit.app.domain.REMINDER_OPTIONS
import com.vakit.app.domain.SOUND_SILENT
import com.vakit.app.domain.Prayer
import com.vakit.app.domain.ThemeMode
import com.vakit.app.notification.AlarmCodes
import com.vakit.app.notification.NotificationHelper
import com.vakit.app.ui.theme.colorThemePreview
import com.vakit.app.vakitApp
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val UPDATE_FORMAT: DateTimeFormatter =
    DateTimeFormatter.ofPattern("d MMM yyyy HH:mm", Locale("tr", "TR"))

@Composable
fun SettingsScreen(
    vm: HomeViewModel,
    location: LocationInfo,
    onBack: () -> Unit,
    onChangeLocation: () -> Unit,
    onOpenFridayPreview: () -> Unit
) {
    val context = LocalContext.current
    val app = context.vakitApp
    val settings by vm.settings.collectAsStateWithLifecycle()
    val download by vm.download.collectAsStateWithLifecycle()
    val lastUpdate by app.settingsRepository.lastUpdate.collectAsStateWithLifecycle(initialValue = null)

    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val notificationsOk = remember(tick) { NotificationHelper.canPost(context) }
    val exactOk = remember(tick) { app.alarmScheduler.canScheduleExact() }
    val testPlanned = remember(tick) { app.alarmScheduler.isTestScheduled() }
    var message by remember { mutableStateOf("") }

    var pickerPrayer by remember { mutableStateOf<Prayer?>(null) }
    val soundPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val prayer = pickerPrayer
        if (prayer != null && result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val uri: Uri? = if (data == null) null
            else IntentCompat.getParcelableExtra(data, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            val value = when {
                uri == null -> SOUND_SILENT
                uri == Settings.System.DEFAULT_NOTIFICATION_URI -> ""
                else -> uri.toString()
            }
            vm.setPrayerSound(prayer, value)
        }
        pickerPrayer = null
    }

    val lastUpdateText = lastUpdate?.let { millis ->
        Instant.ofEpochMilli(millis).atZone(ZoneId.of(location.timezoneId)).format(UPDATE_FORMAT)
    } ?: "Henüz güncellenmedi"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Geri") }
            Text("Ayarlar", style = MaterialTheme.typography.titleLarge)
        }

        SectionCard("Konum") {
            Text(location.label, style = MaterialTheme.typography.titleMedium)
            OutlinedButton(onClick = onChangeLocation) { Text("Konumu değiştir") }
        }

        SectionCard("Bildirimler") {
            if (!notificationsOk) {
                Text(
                    "Bildirimler kapalı. Vakit bildirimlerini alabilmek için izin vermelisin.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error
                )
                Button(onClick = { openNotificationSettings(context) }) { Text("Bildirim ayarlarını aç") }
            }
            if (!exactOk) {
                Text(
                    "Hassas alarm erişimi kapalı: bildirimler birkaç dakika gecikebilir.",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedButton(onClick = { openExactAlarmSettings(context) }) { Text("Hassas alarmı aç") }
            }

            Text("Vakit bildirimleri", style = MaterialTheme.typography.titleSmall)
            Prayer.entries.forEach { prayer ->
                SwitchRow(
                    title = prayer.label,
                    subtitle = null,
                    checked = settings.isEnabled(prayer),
                    onChange = { vm.setPrayerNotification(prayer, it) }
                )
            }
            HorizontalDivider()
            SwitchRow("Bildirim sesi", null, settings.sound) { vm.setSound(it) }
            SwitchRow("Titreşim", null, settings.vibration) { vm.setVibration(it) }
            Text("Vakitten önce hatırlat", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                REMINDER_OPTIONS.forEach { minutes ->
                    FilterChip(
                        selected = settings.reminderMinutes == minutes,
                        onClick = { vm.setReminderMinutes(minutes) },
                        label = { Text(if (minutes == 0) "Kapalı" else "$minutes dk") }
                    )
                }
            }
            SwitchRow(
                "Sabit vakit bildirimi",
                "Günün vakitlerini yan yana gösterir ve şu anki vakti işaretler.",
                settings.statusNotification
            ) { vm.setStatusNotification(it) }
            SwitchRow(
                "Hayırlı Cuma bildirimi",
                "Her Cuma sabah 09:00'da.",
                settings.fridayNotification
            ) { vm.setFridayNotification(it) }
            SwitchRow(
                "Kandil ve bayram bildirimleri",
                "Kandil, bayram ve önemli dinî günlerin sabahında kutlama mesajı.",
                settings.celebrationNotifications
            ) { vm.setCelebrationNotifications(it) }
            HorizontalDivider()

            Text("Test", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        val ok = NotificationHelper.showTest(context, settings.sound, settings.vibration)
                        message = if (ok) "Test bildirimi gönderildi."
                        else "Bildirim gönderilemedi: izin veya kanal kapalı."
                    }
                ) { Text("Test bildirimi") }
                OutlinedButton(
                    onClick = {
                        app.alarmScheduler.scheduleTestAlarm()
                        message = "Test alarmı 2 dakika sonrasına kuruldu. Uygulamayı kapatıp bekle."
                        tick++
                    }
                ) { Text("2 dk sonra test") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        val today = LocalDate.now()
                        val ok = NotificationHelper.show(
                            context, AlarmCodes.FRIDAY_NOTIFICATION_ID, "Hayırlı Cumalar",
                            FridayMessages.notificationText(FridayMessages.forDate(today)),
                            settings.sound, settings.vibration
                        )
                        message = if (ok) "Cuma bildirimi gönderildi."
                        else "Bildirim gönderilemedi: izin veya kanal kapalı."
                    }
                ) { Text("Cuma bildirimi") }
                OutlinedButton(onClick = onOpenFridayPreview) { Text("Cuma görseli") }
            }
            if (testPlanned) {
                TextButton(
                    onClick = {
                        app.alarmScheduler.cancelTestAlarm()
                        message = "Test alarmı iptal edildi."
                        tick++
                    }
                ) { Text("Test alarmını iptal et") }
            }
            if (message.isNotEmpty()) {
                Text(message, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
            }
        }

        SectionCard("Vakit sesleri") {
            Text(
                "Her vakit için telefondaki bildirim ya da alarm seslerinden birini seçebilirsin. " +
                    "Üstteki \"Bildirim sesi\" kapalıysa hiçbir vakitte ses çalmaz.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.alpha(0.8f)
            )
            Prayer.entries.forEach { prayer ->
                val choice = settings.soundOf(prayer)
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(prayer.label, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            soundTitle(context, choice),
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.alpha(0.7f)
                        )
                    }
                    TextButton(onClick = { playPreview(context, choice) }) { Text("Dinle") }
                    OutlinedButton(
                        onClick = {
                            pickerPrayer = prayer
                            soundPicker.launch(soundPickerIntent(prayer.label, choice))
                        }
                    ) { Text("Seç") }
                }
            }
            if (Prayer.entries.any { settings.soundOf(it).isNotEmpty() }) {
                TextButton(onClick = { vm.resetPrayerSounds() }) { Text("Hepsini varsayılan sese döndür") }
            }
        }

        SectionCard("Vakit düzeltmesi") {
            Text(
                "Vakitler hesaplanarak bulunur ve resmî takvimden 1-2 dakika farklı olabilir. " +
                    "Gerekirse her vakti dakika olarak ileri (+) ya da geri (−) alabilirsin. " +
                    "Alarmlar da buna göre kurulur.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.alpha(0.8f)
            )
            Prayer.entries.forEach { prayer ->
                val value = settings.offsetOf(prayer)
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text(prayer.label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    OutlinedButton(
                        onClick = { vm.setOffset(prayer, value - 1) },
                        enabled = value > -MAX_OFFSET_MINUTES
                    ) { Text("−") }
                    Text(
                        text = if (value > 0) "+$value dk" else if (value < 0) "$value dk" else "0 dk",
                        style = MaterialTheme.typography.titleSmall,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.width(64.dp)
                    )
                    OutlinedButton(
                        onClick = { vm.setOffset(prayer, value + 1) },
                        enabled = value < MAX_OFFSET_MINUTES
                    ) { Text("+") }
                }
            }
        }

        SectionCard("Görünüm") {
            Text("Tema", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    ThemeMode.SYSTEM to "Sistem",
                    ThemeMode.LIGHT to "Açık",
                    ThemeMode.DARK to "Koyu"
                ).forEach { (mode, label) ->
                    FilterChip(
                        selected = settings.themeMode == mode,
                        onClick = { vm.setThemeMode(mode) },
                        label = { Text(label) }
                    )
                }
            }
            Spacer(Modifier.height(2.dp))
            Text("Renk", style = MaterialTheme.typography.titleSmall)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                ColorTheme.entries.forEach { theme ->
                    val selected = settings.colorTheme == theme
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { vm.setColorTheme(theme) }
                            .padding(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(colorThemePreview(theme))
                                .border(
                                    width = if (selected) 3.dp else 1.dp,
                                    color = if (selected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.outline,
                                    shape = CircleShape
                                )
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            theme.label,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        SectionCard("Veri") {
            Text("Son güncelleme: $lastUpdateText", style = MaterialTheme.typography.bodyMedium)
            if (download is DownloadState.Error) {
                Text(
                    (download as DownloadState.Error).message,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Button(
                onClick = vm::retryDownload,
                enabled = download !is DownloadState.Loading
            ) {
                Text(if (download is DownloadState.Loading) "Güncelleniyor…" else "Vakitleri şimdi güncelle")
            }
            Text(
                "Veri kaynağı: ${app.repository.sourceName}",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.alpha(0.7f)
            )
        }

        SectionCard("Uygulama") {
            Text("Vakit · Sürüm ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodyMedium)
            Text(
                "Reklamsız, ücretsiz namaz vakitleri uygulaması. Verilerin cihazından dışarı gönderilmez.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.alpha(0.7f)
            )
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, modifier = Modifier.alpha(0.7f))
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}


private var previewRingtone: Ringtone? = null

private fun soundTitle(context: Context, choice: String): String = when {
    choice.isEmpty() -> "Varsayılan bildirim sesi"
    choice == SOUND_SILENT -> "Sessiz"
    else -> runCatching {
        RingtoneManager.getRingtone(context, Uri.parse(choice))?.getTitle(context)
    }.getOrNull() ?: "Seçili ses"
}

private fun playPreview(context: Context, choice: String) {
    previewRingtone?.stop()
    previewRingtone = null
    if (choice == SOUND_SILENT) return
    val uri = if (choice.isEmpty()) Settings.System.DEFAULT_NOTIFICATION_URI else Uri.parse(choice)
    previewRingtone = runCatching { RingtoneManager.getRingtone(context, uri) }.getOrNull()?.also { it.play() }
}

private fun soundPickerIntent(prayerLabel: String, choice: String): Intent {
    val existing: Uri? = when {
        choice.isEmpty() -> Settings.System.DEFAULT_NOTIFICATION_URI
        choice == SOUND_SILENT -> null
        else -> Uri.parse(choice)
    }
    return Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
        putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION or RingtoneManager.TYPE_ALARM)
        putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "$prayerLabel sesi")
        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
        putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, Settings.System.DEFAULT_NOTIFICATION_URI)
        putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, existing)
    }
}
