package com.vakit.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vakit.app.R
import com.vakit.app.domain.LocationInfo
import com.vakit.app.domain.NextPrayer
import com.vakit.app.domain.Prayer
import com.vakit.app.domain.PrayerClock
import com.vakit.app.notification.NotificationHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.time.DayOfWeek
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val TIME_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val DATE_FORMAT: DateTimeFormatter =
    DateTimeFormatter.ofPattern("d MMMM yyyy, EEEE", Locale("tr", "TR"))

/** Her saniye başında güncel zamanı yayar. Yalnızca ekran görünürken toplanır. */
private fun tickerFlow(zone: ZoneId): Flow<ZonedDateTime> = flow {
    while (true) {
        emit(ZonedDateTime.now(zone))
        delay(1_000L - System.currentTimeMillis() % 1_000L)
    }
}

@Composable
fun HomeScreen(
    vm: HomeViewModel,
    location: LocationInfo,
    onOpenSettings: () -> Unit,
    onOpenQibla: () -> Unit,
    onOpenFriday: () -> Unit,
    onOpenCalendar: () -> Unit,
    onOpenMonthly: () -> Unit
) {
    val context = LocalContext.current
    val days by vm.days.collectAsStateWithLifecycle()
    val download by vm.download.collectAsStateWithLifecycle()

    val zone = remember(location.timezoneId) { ZoneId.of(location.timezoneId) }
    val now by remember(zone) { tickerFlow(zone) }
        .collectAsStateWithLifecycle(initialValue = ZonedDateTime.now(zone))

    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        tick++
        vm.onResume()
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        tick++
        vm.onNotificationPermissionResult()
    }
    var askedOnce by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        if (!askedOnce && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            askedOnce = true
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    val notificationsOk = remember(tick) { NotificationHelper.canPost(context) }

    val date = now.toLocalDate()
    val today = days[date]
    val tomorrow = days[date.plusDays(1)]
    val next = today?.let { PrayerClock.nextPrayer(it, tomorrow, now) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = now.format(DATE_FORMAT),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onOpenCalendar) {
                Icon(painter = painterResource(R.drawable.ic_calendar), contentDescription = "Dinî günler")
            }
            IconButton(onClick = onOpenQibla) {
                Icon(painter = painterResource(R.drawable.ic_compass), contentDescription = "Kıble pusulası")
            }
            IconButton(onClick = onOpenSettings) {
                Icon(painter = painterResource(R.drawable.ic_settings), contentDescription = "Ayarlar")
            }
        }

        if (!notificationsOk) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(start = 16.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Bildirimler kapalı, vakit bildirimi gelmez.",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = onOpenSettings) { Text("Ayarlar") }
                }
            }
        }

        HeroCard(location = location, next = next, now = now, download = download, onRetry = vm::retryDownload)

        FridayCard(isFriday = now.dayOfWeek == DayOfWeek.FRIDAY, onOpen = onOpenFriday)

        if (today != null) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "Bugünün vakitleri",
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.padding(start = 14.dp, top = 6.dp, bottom = 4.dp)
                    )
                    Prayer.entries.forEach { prayer ->
                        PrayerRow(
                            prayer = prayer,
                            time = today.timeOf(prayer).format(TIME_FORMAT),
                            passed = !today.zonedTime(prayer).isAfter(now),
                            isNext = next != null && next.prayer == prayer && next.at.toLocalDate() == date
                        )
                    }
                    TextButton(onClick = onOpenMonthly, modifier = Modifier.align(Alignment.End)) {
                        Text("Aylık vakitler →")
                    }
                }
            }
        }
    }
}

@Composable
private fun FridayCard(isFriday: Boolean, onOpen: () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Hayırlı Cuma", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (isFriday) "Bugün Cuma. Resimli mesajını oluştur."
                    else "Cuma günü saat 00:00'da açılır.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Button(onClick = onOpen, enabled = isFriday) { Text("Mesaj oluştur") }
        }
    }
}

@Composable
private fun HeroCard(
    location: LocationInfo,
    next: NextPrayer?,
    now: ZonedDateTime,
    download: DownloadState,
    onRetry: () -> Unit
) {
    val scheme = MaterialTheme.colorScheme
    Card(
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(
            containerColor = scheme.primaryContainer,
            contentColor = scheme.onPrimaryContainer
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = location.label,
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(14.dp))
            if (next != null) {
                val remainingMs = next.at.toInstant().toEpochMilli() - now.toInstant().toEpochMilli()
                val totalSeconds = maxOf(0L, (remainingMs + 999L) / 1000L)
                Text(
                    text = "${next.prayer.label} vaktine kalan süre",
                    style = MaterialTheme.typography.bodyLarge
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = String.format(
                        Locale.US, "%02d:%02d:%02d",
                        totalSeconds / 3600, totalSeconds % 3600 / 60, totalSeconds % 60
                    ),
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontSize = 52.sp,
                        fontWeight = FontWeight.Bold,
                        fontFeatureSettings = "tnum"
                    ),
                    maxLines = 1
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "${next.prayer.label} · ${next.at.format(TIME_FORMAT)}",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.alpha(0.9f)
                )
            } else if (download is DownloadState.Loading) {
                CircularProgressIndicator(color = scheme.onPrimaryContainer)
                Spacer(Modifier.height(10.dp))
                Text("Vakitler indiriliyor…", style = MaterialTheme.typography.bodyLarge)
            } else {
                Text(
                    text = "Vakitler henüz indirilmedi.",
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center
                )
                if (download is DownloadState.Error) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = download.message,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = scheme.primary,
                        contentColor = scheme.onPrimary
                    )
                ) { Text("Vakitleri indir") }
            }
        }
    }
}

@Composable
private fun PrayerRow(prayer: Prayer, time: String, passed: Boolean, isNext: Boolean) {
    val background = if (isNext) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f) else Color.Transparent
    val contentAlpha = if (passed && !isNext) 0.45f else 1f
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(background)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = prayer.label,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = if (isNext) FontWeight.Bold else FontWeight.Normal
            ),
            modifier = Modifier.alpha(contentAlpha)
        )
        Text(
            text = time,
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.SemiBold,
                fontFeatureSettings = "tnum"
            ),
            modifier = Modifier.alpha(contentAlpha)
        )
    }
}
