package com.vakit.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vakit.app.R
import com.vakit.app.friday.FridayImage
import com.vakit.app.friday.ImageSharing

@Composable
fun FridayScreen(vm: FridayViewModel, onBack: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val ready = state.image != null

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Geri") }
            Text("Hayırlı Cuma", style = MaterialTheme.typography.titleLarge)
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(FridayImage.WIDTH.toFloat() / FridayImage.HEIGHT.toFloat())
                .clip(RoundedCornerShape(20.dp))
                .background(MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.Center
        ) {
            val image = state.image
            if (image != null) {
                Image(
                    bitmap = image.asImageBitmap(),
                    contentDescription = "Hayırlı Cuma mesajı görseli",
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                CircularProgressIndicator()
            }
        }

        OutlinedButton(onClick = vm::newMessage, enabled = ready, modifier = Modifier.fillMaxWidth()) {
            Text("Yeni mesaj üret")
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    vm.shareTo(context, ImageSharing.WHATSAPP, ImageSharing.WHATSAPP_BUSINESS, "WhatsApp")
                },
                enabled = ready,
                modifier = Modifier.weight(1f)
            ) { ShareLabel("WhatsApp", R.drawable.ic_share) }
            Button(
                onClick = { vm.shareTo(context, ImageSharing.INSTAGRAM, null, "Instagram") },
                enabled = ready,
                modifier = Modifier.weight(1f)
            ) { ShareLabel("Instagram", R.drawable.ic_share) }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { vm.shareTo(context, null) },
                enabled = ready,
                modifier = Modifier.weight(1f)
            ) { ShareLabel("Diğer", R.drawable.ic_share) }
            OutlinedButton(
                onClick = { vm.download(context) },
                enabled = ready,
                modifier = Modifier.weight(1f)
            ) { ShareLabel("İndir", R.drawable.ic_download) }
        }

        if (state.info.isNotEmpty()) {
            Text(state.info, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
        }
        Spacer(Modifier.size(8.dp))
    }
}

@Composable
private fun ShareLabel(text: String, icon: Int) {
    Icon(painter = painterResource(icon), contentDescription = null, modifier = Modifier.size(18.dp))
    Spacer(Modifier.width(8.dp))
    Text(text)
}
