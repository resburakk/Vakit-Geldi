package com.vakit.app.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableString
import android.text.style.StyleSpan
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import com.vakit.app.MainActivity
import com.vakit.app.R
import com.vakit.app.domain.Prayer
import com.vakit.app.domain.PrayerClock
import com.vakit.app.domain.PrayerDay
import com.vakit.app.vakitApp
import com.vakit.app.widget.PrayerWidget
import kotlinx.coroutines.flow.first
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

/**
 * Günün vakitlerini yan yana gösteren ve şu an girmiş olan vakti işaretleyen sabit (ongoing) bildirim.
 * Foreground service kullanılmaz; içerik her vakitte ve gece yarısında alarmla, ayrıca
 * uygulama açıldığında yenilenir. Android 14 ve üzerinde kullanıcı bu bildirimi kaydırarak
 * kapatabilir; bir sonraki yenilemede yeniden gösterilir.
 */
object StatusNotification {
    private const val CHANNEL_ID = "vakit_durum"
    const val NOTIFICATION_ID = 2
    private val TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm")

    private val COL_IDS = intArrayOf(
        R.id.status_col_0, R.id.status_col_1, R.id.status_col_2,
        R.id.status_col_3, R.id.status_col_4, R.id.status_col_5
    )
    private val NAME_IDS = intArrayOf(
        R.id.status_name_0, R.id.status_name_1, R.id.status_name_2,
        R.id.status_name_3, R.id.status_name_4, R.id.status_name_5
    )
    private val TIME_IDS = intArrayOf(
        R.id.status_time_0, R.id.status_time_1, R.id.status_time_2,
        R.id.status_time_3, R.id.status_time_4, R.id.status_time_5
    )

    suspend fun sync(context: Context) {
        val app = context.vakitApp
        val manager = context.getSystemService(NotificationManager::class.java)
        val settings = app.settingsRepository.settings.first()
        val location = app.settingsRepository.location.first()
        val hasWidget = PrayerWidget.hasWidgets(context)
        if (location == null) {
            manager.cancel(NOTIFICATION_ID)
            app.alarmScheduler.cancelStatusAlarm()
            PrayerWidget.renderEmpty(context)
            return
        }
        if (!settings.statusNotification && !hasWidget) {
            manager.cancel(NOTIFICATION_ID)
            app.alarmScheduler.cancelStatusAlarm()
            return
        }

        val zone = ZoneId.of(location.timezoneId)
        val now = ZonedDateTime.now(zone)
        val date = now.toLocalDate()
        val days = app.repository.getRange(location, date, date.plusDays(1))
        val today = days.firstOrNull { it.date == date }
        val tomorrow = days.firstOrNull { it.date == date.plusDays(1) }
        if (today == null) {
            manager.cancel(NOTIFICATION_ID)
            app.alarmScheduler.cancelStatusAlarm()
            PrayerWidget.render(context, location, null)
            return
        }

        val current = PrayerClock.currentPrayer(today, now)
        val next = PrayerClock.nextPrayer(today, tomorrow, now)

        // Bir sonraki yenileme: sıradaki vakit ya da gece yarısı, hangisi önceyse.
        val midnight = date.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli() + 1_000L
        val nextAt = next?.at?.toInstant()?.toEpochMilli() ?: midnight
        app.alarmScheduler.scheduleStatusAlarm(minOf(nextAt, midnight))
        PrayerWidget.render(context, location, next)

        if (!settings.statusNotification) {
            manager.cancel(NOTIFICATION_ID)
            return
        }
        if (!NotificationHelper.canPost(context)) return

        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Günlük vakitler (sabit bildirim)", NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Günün namaz vakitlerini yan yana ve şu anki vakti gösterir"
                setShowBadge(false)
            }
            manager.createNotificationChannel(channel)
        }

        val title = "${current.label} vakti"
        val nextText = next?.let { "Sıradaki: ${it.prayer.label} ${it.at.format(TIME_FORMAT)}" }
            ?: "Yarının vakitleri bekleniyor"

        val collapsed = RemoteViews(context.packageName, R.layout.notification_status_collapsed)
        fillRow(collapsed, today, current)
        val expanded = RemoteViews(context.packageName, R.layout.notification_status_expanded)
        fillRow(expanded, today, current)
        expanded.setTextViewText(R.id.status_title, title)
        expanded.setTextViewText(R.id.status_subtitle, "${location.label} · $nextText")

        val openApp = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_vakit)
            .setContentTitle(title)
            .setContentText("${location.label} · $nextText")
            .setSubText("$title · ${location.label}")
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setCustomContentView(collapsed)
            .setCustomBigContentView(expanded)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setShowWhen(false)
            .setContentIntent(openApp)
            .build()
        manager.notify(NOTIFICATION_ID, notification)
    }

    /** Vakitleri yan yana sütunlara yazar; şu anki vakit arka planla ve kalın yazıyla vurgulanır. */
    private fun fillRow(views: RemoteViews, day: PrayerDay, current: Prayer) {
        Prayer.entries.forEachIndexed { index, prayer ->
            val isCurrent = prayer == current
            val name = SpannableString(prayer.label)
            val time = SpannableString(day.timeOf(prayer).format(TIME_FORMAT))
            if (isCurrent) {
                name.setSpan(StyleSpan(Typeface.BOLD), 0, name.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                time.setSpan(StyleSpan(Typeface.BOLD), 0, time.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            views.setTextViewText(NAME_IDS[index], name)
            views.setTextViewText(TIME_IDS[index], time)
            views.setInt(
                COL_IDS[index], "setBackgroundResource",
                if (isCurrent) R.drawable.status_current_bg else 0
            )
        }
    }
}
