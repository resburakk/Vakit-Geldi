package com.vakit.app.ui

import android.app.Application
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.vakit.app.VakitApp
import com.vakit.app.data.userMessage
import com.vakit.app.domain.DayKind
import com.vakit.app.domain.ReligiousDay
import com.vakit.app.notification.Rescheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

class ReligiousViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as VakitApp
    private val repository = app.religiousRepository

    val days: StateFlow<List<ReligiousDay>> = repository.days
    val lastUpdate: StateFlow<Long?> = repository.lastUpdate

    private val _refreshing = MutableStateFlow(false)
    val refreshing: StateFlow<Boolean> = _refreshing.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    init {
        viewModelScope.launch { repository.load() }
    }

    /** Sayfa aşağı çekilince çağrılır: takvimi internetten yeniler, bildirimleri yeniden kurar. */
    fun refresh() {
        if (_refreshing.value) return
        viewModelScope.launch {
            _refreshing.value = true
            _error.value = null
            val result = repository.refresh()
            result.fold(
                onSuccess = { Rescheduler.rescheduleAll(app) },
                onFailure = { _error.value = it.userMessage() }
            )
            _refreshing.value = false
        }
    }
}

private val LONG_DATE: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMMM yyyy", Locale("tr", "TR"))
private val WEEKDAY: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE", Locale("tr", "TR"))
private val MONTH_SHORT: DateTimeFormatter = DateTimeFormatter.ofPattern("MMM", Locale("tr", "TR"))
private val UPDATE_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM yyyy HH:mm", Locale("tr", "TR"))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReligiousCalendarScreen(vm: ReligiousViewModel, onBack: () -> Unit) {
    val days by vm.days.collectAsStateWithLifecycle()
    val refreshing by vm.refreshing.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val lastUpdate by vm.lastUpdate.collectAsStateWithLifecycle()

    val today = remember { LocalDate.now(ZoneId.systemDefault()) }
    val upcoming = remember(days, today) { days.filter { !it.date.isBefore(today) }.sortedBy { it.date } }
    val updateText = lastUpdate?.let {
        java.time.Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).format(UPDATE_FORMAT)
    } ?: "Henüz güncellenmedi"

    Column(modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("← Geri") }
            Text("Dinî Günler", style = MaterialTheme.typography.titleLarge)
        }
        PullToRefreshBox(
            isRefreshing = refreshing,
            onRefresh = vm::refresh,
            modifier = Modifier.weight(1f).fillMaxWidth()
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        "Güncellemek için sayfayı yukarıdan aşağıya çek. Son güncelleme: $updateText",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                error?.let { message ->
                    item { Text(message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }
                }
                if (upcoming.isEmpty()) {
                    item {
                        Text(
                            if (refreshing) "Takvim indiriliyor…"
                            else "Takvim henüz indirilmedi. Sayfayı aşağı çekerek indirebilirsin.",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
                items(upcoming, key = { it.key }) { day -> DayCard(day, today) }
            }
        }
    }
}

@Composable
private fun DayCard(day: ReligiousDay, today: LocalDate) {
    val scheme = MaterialTheme.colorScheme
    val container: Color = when (day.kind) {
        DayKind.KANDIL -> scheme.tertiaryContainer
        DayKind.BAYRAM -> scheme.primaryContainer
        DayKind.ARIFE -> scheme.secondaryContainer
        DayKind.OZEL -> scheme.surface
    }
    val remaining = ChronoUnit.DAYS.between(today, day.date)
    val remainingText = when (remaining) {
        0L -> "Bugün"
        1L -> "Yarın"
        else -> "$remaining gün kaldı"
    }
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = container),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(56.dp)) {
                Text(day.date.dayOfMonth.toString(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(day.date.format(MONTH_SHORT), style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center)
            }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(day.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    "${day.date.format(LONG_DATE)}, ${day.date.format(WEEKDAY)}",
                    style = MaterialTheme.typography.bodySmall
                )
                if (day.kind == DayKind.KANDIL) {
                    Text("Kandil gecesi bu tarihin akşamı başlar", style = MaterialTheme.typography.bodySmall)
                }
            }
            Text(remainingText, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Medium)
        }
    }
}
