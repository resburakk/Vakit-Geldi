package com.vakit.app.data.remote

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object NetworkModule {
    private const val USER_AGENT = "Vakit-Android/0.2 (namaz vakitleri uygulamasi)"

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                chain.proceed(chain.request().newBuilder().header("User-Agent", USER_AGENT).build())
            })
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .callTimeout(40, TimeUnit.SECONDS)
            .build()
    }

    /** Overpass sorguları daha uzun sürebilir. */
    private val longClient: OkHttpClient by lazy {
        client.newBuilder()
            .readTimeout(75, TimeUnit.SECONDS)
            .callTimeout(100, TimeUnit.SECONDS)
            .build()
    }

    private fun retrofit(baseUrl: String, http: OkHttpClient): Retrofit =
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(http)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    val alAdhanApi: AlAdhanApi by lazy {
        retrofit("https://api.aladhan.com/v1/", client).create(AlAdhanApi::class.java)
    }

    val overpassApi: OverpassApi by lazy {
        retrofit("https://overpass-api.de/", longClient).create(OverpassApi::class.java)
    }

    val turkiyeApi: TurkiyeApi by lazy {
        retrofit("https://api.turkiyeapi.dev/", client).create(TurkiyeApi::class.java)
    }

    val nominatimApi: NominatimApi by lazy {
        retrofit("https://nominatim.openstreetmap.org/", client).create(NominatimApi::class.java)
    }
}
