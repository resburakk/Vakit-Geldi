package com.vakit.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import com.vakit.app.MainActivity
import com.vakit.app.R
import com.vakit.app.domain.LocationInfo
import com.vakit.app.domain.NextPrayer
import java.time.format.DateTimeFormatter

/** Ana ekran widget'ının içeriğini çizer. Kalan süre sistem sayacıyla her saniye kendiliğinden akar. */
object PrayerWidget {
    private val TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm")

    private fun ids(context: Context): IntArray =
        AppWidgetManager.getInstance(context)
            .getAppWidgetIds(ComponentName(context, PrayerWidgetProvider::class.java))

    fun hasWidgets(context: Context): Boolean = ids(context).isNotEmpty()

    fun render(context: Context, location: LocationInfo, next: NextPrayer?) {
        val ids = ids(context)
        if (ids.isEmpty()) return
        val views = baseViews(context)
        views.setTextViewText(R.id.widget_location, location.label)
        if (next == null) {
            views.setTextViewText(R.id.widget_label, "Vakitler bekleniyor")
            views.setViewVisibility(R.id.widget_timer, View.GONE)
            views.setTextViewText(R.id.widget_next, "Uygulamayı açıp güncelle")
        } else {
            val remaining = next.at.toInstant().toEpochMilli() - System.currentTimeMillis()
            views.setTextViewText(R.id.widget_label, "${next.prayer.label} vaktine kalan süre")
            views.setViewVisibility(R.id.widget_timer, View.VISIBLE)
            views.setChronometerCountDown(R.id.widget_timer, true)
            views.setChronometer(R.id.widget_timer, SystemClock.elapsedRealtime() + remaining, null, true)
            views.setTextViewText(R.id.widget_next, "${next.prayer.label} · ${next.at.format(TIME_FORMAT)}")
        }
        AppWidgetManager.getInstance(context).updateAppWidget(ids, views)
    }

    fun renderEmpty(context: Context) {
        val ids = ids(context)
        if (ids.isEmpty()) return
        val views = baseViews(context)
        views.setTextViewText(R.id.widget_location, "Vakit")
        views.setTextViewText(R.id.widget_label, "Konum seçilmedi")
        views.setViewVisibility(R.id.widget_timer, View.GONE)
        views.setTextViewText(R.id.widget_next, "Uygulamayı açıp il seç")
        AppWidgetManager.getInstance(context).updateAppWidget(ids, views)
    }

    private fun baseViews(context: Context): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_prayer)
        val openApp = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        views.setOnClickPendingIntent(R.id.widget_root, openApp)
        return views
    }
}
