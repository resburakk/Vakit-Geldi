package com.vakit.app.notification

import com.vakit.app.domain.Prayer
import java.time.LocalDate

object AlarmCodes {
    const val TEST_REQUEST_CODE = 1
    const val TEST_NOTIFICATION_ID = 1
    const val STATUS_REQUEST_CODE = 2
    const val FRIDAY_REQUEST_CODE = 3
    const val FRIDAY_NOTIFICATION_ID = 5_000

    /** Kutlama alarmı kimliği: 1.000.000 + gün sayısı * 10 + aynı güne ait sıra (0..9). Namaz kimlikleriyle çakışmaz. */
    fun celebrationCode(date: LocalDate, index: Int): Int =
        1_000_000 + date.toEpochDay().toInt() * 10 + index.coerceIn(0, 9)

    /**
     * Her (gün, vakit, tür) için benzersiz kimlik:
     * yyyyMMdd * 100 + (hatırlatma ? 10 : 0) + vakit sırası (0..5).
     * Test (1) ve sabit bildirim (2) kimlikleriyle çakışmaz; 2147 yılına kadar Int sınırları içinde kalır.
     */
    fun prayerCode(date: LocalDate, prayer: Prayer, reminder: Boolean): Int {
        val ymd = date.year * 10000 + date.monthValue * 100 + date.dayOfMonth
        return ymd * 100 + (if (reminder) 10 else 0) + prayer.ordinal
    }
}
