package com.vakit.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vakit.app.domain.AppSettings
import com.vakit.app.domain.LocationInfo
import com.vakit.app.ui.FridayScreen
import com.vakit.app.ui.FridayViewModel
import com.vakit.app.ui.HomeScreen
import com.vakit.app.ui.HomeViewModel
import com.vakit.app.ui.LocationPickerScreen
import com.vakit.app.ui.MonthlyScreen
import com.vakit.app.ui.MonthlyViewModel
import com.vakit.app.ui.PickerViewModel
import com.vakit.app.ui.QiblaScreen
import com.vakit.app.ui.ReligiousCalendarScreen
import com.vakit.app.ui.ReligiousViewModel
import com.vakit.app.ui.SettingsScreen
import com.vakit.app.ui.theme.VakitTheme
import kotlinx.coroutines.flow.map

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { VakitRoot() }
    }
}

private data class LocationState(val loaded: Boolean, val location: LocationInfo?)

private enum class Screen { HOME, SETTINGS, QIBLA, PICKER, FRIDAY, CALENDAR, MONTHLY }

@Composable
private fun VakitRoot() {
    val app = LocalContext.current.vakitApp
    val settings by app.settingsRepository.settings.collectAsState(initial = AppSettings())
    val locationState by remember {
        app.settingsRepository.location.map { LocationState(true, it) }
    }.collectAsState(initial = LocationState(false, null))

    // Etkinlik düzeyinde oluşturulur: konum seçilince vakit indirme ve alarm kurma buradan yürür.
    val homeViewModel: HomeViewModel = viewModel()
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }

    VakitTheme(settings.themeMode, settings.colorTheme) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            val location = locationState.location
            when {
                !locationState.loaded -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }

                location == null || screen == Screen.PICKER -> LocationPickerScreen(
                    vm = viewModel<PickerViewModel>(),
                    canCancel = location != null,
                    onCancel = { screen = Screen.SETTINGS },
                    onDone = { screen = Screen.HOME }
                )

                screen == Screen.SETTINGS -> {
                    BackHandler { screen = Screen.HOME }
                    SettingsScreen(
                        vm = homeViewModel,
                        location = location,
                        onBack = { screen = Screen.HOME },
                        onChangeLocation = { screen = Screen.PICKER },
                        onOpenFridayPreview = { screen = Screen.FRIDAY }
                    )
                }

                screen == Screen.QIBLA -> {
                    BackHandler { screen = Screen.HOME }
                    QiblaScreen(location = location, onBack = { screen = Screen.HOME })
                }

                screen == Screen.FRIDAY -> {
                    BackHandler { screen = Screen.HOME }
                    FridayScreen(vm = viewModel<FridayViewModel>(), onBack = { screen = Screen.HOME })
                }

                screen == Screen.MONTHLY -> {
                    BackHandler { screen = Screen.HOME }
                    MonthlyScreen(
                        vm = viewModel<MonthlyViewModel>(),
                        location = location,
                        onBack = { screen = Screen.HOME }
                    )
                }

                screen == Screen.CALENDAR -> {
                    BackHandler { screen = Screen.HOME }
                    ReligiousCalendarScreen(vm = viewModel<ReligiousViewModel>(), onBack = { screen = Screen.HOME })
                }

                else -> HomeScreen(
                    vm = homeViewModel,
                    location = location,
                    onOpenSettings = { screen = Screen.SETTINGS },
                    onOpenQibla = { screen = Screen.QIBLA },
                    onOpenFriday = { screen = Screen.FRIDAY },
                    onOpenCalendar = { screen = Screen.CALENDAR },
                    onOpenMonthly = { screen = Screen.MONTHLY }
                )
            }
        }
    }
}
