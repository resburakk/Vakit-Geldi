package com.vakit.app.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import com.vakit.app.notification.StatusNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class PrayerWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val appContext = context.applicationContext
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
            try {
                // Sabit bildirim ve widget aynı hesaptan beslenir.
                StatusNotification.sync(appContext)
            } catch (e: Exception) {
                // Widget hatası uygulamayı çökertmemeli.
            } finally {
                pending.finish()
            }
        }
    }
}
