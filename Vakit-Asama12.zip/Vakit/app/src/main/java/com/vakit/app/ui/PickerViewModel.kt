package com.vakit.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vakit.app.VakitApp
import com.vakit.app.data.location.District
import com.vakit.app.data.location.Province
import com.vakit.app.data.location.ResolvedLocation
import com.vakit.app.data.userMessage
import com.vakit.app.domain.LocationInfo
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface Async<out T> {
    data object Loading : Async<Nothing>
    data class Success<T>(val data: T) : Async<T>
    data class Failure(val message: String) : Async<Nothing>
}

enum class PickerStep { PROVINCE, DISTRICT, CONFIRM }

data class PickerUiState(
    val step: PickerStep = PickerStep.PROVINCE,
    val provinces: Async<List<Province>> = Async.Loading,
    val province: Province? = null,
    val districts: Async<List<District>> = Async.Loading,
    val district: District? = null,
    val resolving: Boolean = false,
    val resolved: ResolvedLocation? = null,
    val resolveError: String? = null,
    val saving: Boolean = false,
    val saveError: String? = null,
    val locating: Boolean = false,
    val locateError: String? = null,
    val viaDevice: Boolean = false
)

class PickerViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as VakitApp
    private val _state = MutableStateFlow(PickerUiState())
    val state: StateFlow<PickerUiState> = _state.asStateFlow()
    private var resolveJob: Job? = null

    private fun <T> Result<T>.toAsync(): Async<T> = fold(
        onSuccess = { value -> Async.Success(value) },
        onFailure = { error -> Async.Failure(error.userMessage()) }
    )

    /** Ekran her açıldığında başa döner ve il listesini yükler. */
    fun start() {
        resolveJob?.cancel()
        _state.value = PickerUiState()
        loadProvinces()
    }

    fun loadProvinces() {
        _state.update { it.copy(provinces = Async.Loading) }
        viewModelScope.launch {
            val result = app.locationRepository.provinces()
            _state.update { current -> current.copy(provinces = result.toAsync()) }
        }
    }

    fun hasLocationPermission(): Boolean = app.deviceLocation.hasPermission()

    fun locationDenied() {
        _state.update { it.copy(locateError = "Konum izni verilmedi. Listeden seçebilirsin.") }
    }

    /** Cihaz konumundan il ve ilçeyi bulup onay adımına geçer. */
    fun useDeviceLocation() {
        if (_state.value.locating) return
        _state.update { it.copy(locating = true, locateError = null) }
        viewModelScope.launch {
            val point = app.deviceLocation.current()
            if (point == null) {
                locateFailed("Konum alınamadı. Telefonun konum servisini açıp tekrar dene ya da listeden seç.")
                return@launch
            }
            if (point.latitude !in 35.5..42.5 || point.longitude !in 25.5..45.0) {
                locateFailed("Bulunduğun konum Türkiye dışında görünüyor. Listeden seçebilirsin.")
                return@launch
            }
            val place = app.locationRepository.reverse(point.latitude, point.longitude)
            if (place == null) {
                locateFailed("Bulunduğun il ve ilçe belirlenemedi. İnterneti kontrol et ya da listeden seç.")
                return@launch
            }
            val resolved = ResolvedLocation(
                LocationInfo(place.il, place.ilce, point.latitude, point.longitude),
                "Cihaz konumu"
            )
            _state.update {
                it.copy(
                    locating = false,
                    step = PickerStep.CONFIRM,
                    viaDevice = true,
                    province = Province(0L, place.il),
                    district = District(place.ilce),
                    resolving = false,
                    resolved = resolved,
                    resolveError = null,
                    saveError = null
                )
            }
        }
    }

    private fun locateFailed(message: String) {
        _state.update { it.copy(locating = false, locateError = message) }
    }

    fun selectProvince(province: Province) {
        _state.update {
            it.copy(step = PickerStep.DISTRICT, province = province, districts = Async.Loading, district = null)
        }
        loadDistricts(province)
    }

    private fun loadDistricts(province: Province) {
        viewModelScope.launch {
            val result = app.locationRepository.districts(province)
            _state.update { current -> current.copy(districts = result.toAsync()) }
        }
    }

    fun retryDistricts() {
        val province = _state.value.province ?: return
        _state.update { it.copy(districts = Async.Loading) }
        loadDistricts(province)
    }

    fun selectDistrict(district: District) {
        _state.update {
            it.copy(
                step = PickerStep.CONFIRM,
                district = district,
                resolved = null,
                resolveError = null,
                saveError = null
            )
        }
        resolve()
    }

    fun resolve() {
        val snapshot = _state.value
        val province = snapshot.province ?: return
        val district = snapshot.district ?: return
        resolveJob?.cancel()
        _state.update { it.copy(resolving = true, resolved = null, resolveError = null) }
        resolveJob = viewModelScope.launch {
            val result = app.locationRepository.resolve(province, district)
            _state.update { current ->
                current.copy(
                    resolving = false,
                    resolved = result.getOrNull(),
                    resolveError = result.exceptionOrNull()?.userMessage()
                )
            }
        }
    }

    /** Bir adım geri gider; zaten ilk adımdaysa false döner. */
    fun back(): Boolean = when (_state.value.step) {
        PickerStep.PROVINCE -> false
        PickerStep.DISTRICT -> {
            _state.update { it.copy(step = PickerStep.PROVINCE) }
            true
        }
        PickerStep.CONFIRM -> {
            resolveJob?.cancel()
            _state.update {
                if (it.viaDevice) {
                    it.copy(
                        step = PickerStep.PROVINCE, viaDevice = false, resolved = null,
                        province = null, district = null, saveError = null
                    )
                } else {
                    it.copy(step = PickerStep.DISTRICT, resolving = false, saveError = null)
                }
            }
            true
        }
    }

    /** Önce vakitleri indirir; başarılıysa konumu kaydeder ve ana sayfaya geçer. */
    fun confirm(onDone: () -> Unit) {
        val resolved = _state.value.resolved ?: return
        if (_state.value.saving) return
        _state.update { it.copy(saving = true, saveError = null) }
        viewModelScope.launch {
            val result = app.repository.refresh(resolved.location)
            if (result.isSuccess) {
                app.settingsRepository.setLocation(resolved.location)
                _state.update { it.copy(saving = false) }
                onDone()
            } else {
                _state.update {
                    it.copy(saving = false, saveError = result.exceptionOrNull()?.userMessage())
                }
            }
        }
    }
}
