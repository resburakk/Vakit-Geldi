package com.vakit.app.notification

import android.content.Context
import com.vakit.app.vakitApp
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.TemporalAdjusters

/** Kayıtlı konum, ayar ve Room verisine göre alarmları ve sabit bildirimi yeniden kurar. */
object Rescheduler {
    private val mutex = Mutex()
    const val HORIZON_DAYS = 7

    /** Cuma ve kutlama bildirimleri sabah bu saatte gelir. */
    private val MORNING: LocalTime = LocalTime.of(9, 0)
    private const val CELEBRATION_HORIZON_DAYS = 400L

    suspend fun rescheduleAll(context: Context): Int {
        val count = mutex.withLock {
            val app = context.vakitApp
            val scheduler = app.alarmScheduler
            val location = app.settingsRepository.location.first()
            val settings = app.settingsRepository.settings.first()
            val prayerCount = if (location == null) {
                scheduler.cancelPrayerAlarms()
                0
            } else {
                val today = LocalDate.now(ZoneId.of(location.timezoneId))
                val days = app.repository.getRange(location, today, today.plusDays(HORIZON_DAYS.toLong()))
                scheduler.schedulePrayerAlarms(location, days, settings)
            }
            scheduleFriday(scheduler, settings.fridayNotification)
            scheduleCelebrations(context, scheduler, settings.celebrationNotifications)
            prayerCount
        }
        StatusNotification.sync(context)
        return count
    }

    private fun scheduleFriday(scheduler: AlarmScheduler, enabled: Boolean) {
        if (!enabled) {
            scheduler.scheduleFridayAlarm(null)
            return
        }
        val zone = ZoneId.systemDefault()
        val now = ZonedDateTime.now(zone)
        var friday = now.toLocalDate().with(TemporalAdjusters.nextOrSame(DayOfWeek.FRIDAY))
        var trigger = ZonedDateTime.of(friday, MORNING, zone)
        if (!trigger.isAfter(now)) {
            friday = friday.plusWeeks(1)
            trigger = ZonedDateTime.of(friday, MORNING, zone)
        }
        scheduler.scheduleFridayAlarm(trigger.toInstant().toEpochMilli())
    }

    private suspend fun scheduleCelebrations(context: Context, scheduler: AlarmScheduler, enabled: Boolean) {
        if (!enabled) {
            scheduler.cancelCelebrations()
            return
        }
        val zone = ZoneId.systemDefault()
        val nowMillis = System.currentTimeMillis()
        val today = LocalDate.now(zone)
        val perDay = HashMap<LocalDate, Int>()
        val items = context.vakitApp.religiousRepository.notifiableFrom(today)
            .filter { !it.date.isAfter(today.plusDays(CELEBRATION_HORIZON_DAYS)) }
            .mapNotNull { day ->
                val trigger = ZonedDateTime.of(day.date, MORNING, zone).toInstant().toEpochMilli()
                if (trigger <= nowMillis) return@mapNotNull null
                val index = perDay.getOrDefault(day.date, 0)
                perDay[day.date] = index + 1
                CelebrationAlarm(
                    date = day.date,
                    index = index,
                    triggerAt = trigger,
                    title = day.notifyTitle.orEmpty(),
                    text = day.notifyText.orEmpty(),
                    key = day.key
                )
            }
        scheduler.scheduleCelebrations(items)
    }
}
