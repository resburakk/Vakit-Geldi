package com.vakit.app.domain

import java.time.DayOfWeek
import java.time.LocalDate

enum class DayKind(val label: String) {
    KANDIL("Kandil"),
    BAYRAM("Bayram"),
    ARIFE("Arife"),
    OZEL("Özel gün")
}

/**
 * Takvimdeki bir dinî gün. [notifyTitle] ve [notifyText] doluysa o gün sabah kutlama bildirimi gelir.
 * Kandillerde tarih, kandil gecesinin başladığı akşamın tarihidir (Diyanet takvimindeki gibi).
 */
data class ReligiousDay(
    val date: LocalDate,
    val name: String,
    val kind: DayKind,
    val notifyTitle: String? = null,
    val notifyText: String? = null
) {
    val key: String get() = "$date|$name"
}

/** Bir miladî günün hicrî karşılığı. [month] 1 = Muharrem ... 12 = Zilhicce. */
data class HijriDay(val date: LocalDate, val day: Int, val month: Int, val year: Int)

/** Hicrî tarihlerden Diyanet'in kullandığı dinî günleri çıkaran kurallar. */
object ReligiousRules {

    fun derive(days: List<HijriDay>): List<ReligiousDay> {
        val out = LinkedHashMap<String, ReligiousDay>()
        fun add(day: ReligiousDay) {
            out[day.key] = day
        }

        for (h in days) {
            val date = h.date
            when {
                h.month == 1 && h.day == 1 -> add(
                    ReligiousDay(
                        date, "Hicrî Yılbaşı", DayKind.OZEL,
                        "Hicrî Yılbaşı", "Hicrî yılbaşınız kutlu olsun. Yeni yıl hayır ve bereket getirsin."
                    )
                )

                h.month == 1 && h.day == 10 -> add(
                    ReligiousDay(date, "Aşure Günü", DayKind.OZEL, "Aşure Günü", "Aşure Gününüz hayırlı olsun.")
                )

                h.month == 3 && h.day == 11 -> add(
                    ReligiousDay(
                        date, "Mevlid Kandili", DayKind.KANDIL,
                        "Mevlid Kandili", "Bu akşam Mevlid Kandili. Kandiliniz mübarek olsun."
                    )
                )

                h.month == 7 && h.day == 1 -> add(
                    ReligiousDay(
                        date, "Üç Ayların Başlangıcı", DayKind.OZEL,
                        "Üç Aylar Başladı", "Üç aylarınız hayırlı olsun."
                    )
                )

                h.month == 7 && h.day == 26 -> add(
                    ReligiousDay(
                        date, "Miraç Kandili", DayKind.KANDIL,
                        "Miraç Kandili", "Bu akşam Miraç Kandili. Kandiliniz mübarek olsun."
                    )
                )

                h.month == 8 && h.day == 14 -> add(
                    ReligiousDay(
                        date, "Berat Kandili", DayKind.KANDIL,
                        "Berat Kandili", "Bu akşam Berat Kandili. Kandiliniz mübarek olsun."
                    )
                )

                h.month == 9 && h.day == 1 -> add(
                    ReligiousDay(
                        date, "Ramazan Başlangıcı", DayKind.OZEL,
                        "Ramazan-ı Şerif", "Ramazan-ı şerifiniz mübarek olsun."
                    )
                )

                h.month == 9 && h.day == 26 -> add(
                    ReligiousDay(
                        date, "Kadir Gecesi", DayKind.KANDIL,
                        "Kadir Gecesi", "Bu akşam Kadir Gecesi. Geceniz mübarek, dualarınız kabul olsun."
                    )
                )

                h.month == 10 && h.day in 1..3 -> {
                    if (h.day == 1) {
                        add(ReligiousDay(date.minusDays(1), "Ramazan Bayramı Arifesi", DayKind.ARIFE))
                    }
                    add(
                        ReligiousDay(
                            date, "Ramazan Bayramı ${h.day}. Gün", DayKind.BAYRAM,
                            if (h.day == 1) "Ramazan Bayramı" else null,
                            if (h.day == 1) "Bayramınız mübarek olsun. Nice bayramlara." else null
                        )
                    )
                }

                h.month == 12 && h.day == 9 -> add(ReligiousDay(date, "Kurban Bayramı Arifesi", DayKind.ARIFE))

                h.month == 12 && h.day in 10..13 -> add(
                    ReligiousDay(
                        date, "Kurban Bayramı ${h.day - 9}. Gün", DayKind.BAYRAM,
                        if (h.day == 10) "Kurban Bayramı" else null,
                        if (h.day == 10) "Bayramınız mübarek olsun. Nice bayramlara." else null
                    )
                )
            }
            // Regaip: Recep ayının ilk Cuma gecesi, yani ayın ilk Perşembe akşamı.
            if (h.month == 7 && h.day <= 7 && date.dayOfWeek == DayOfWeek.THURSDAY) {
                add(
                    ReligiousDay(
                        date, "Regaip Kandili", DayKind.KANDIL,
                        "Regaip Kandili", "Bu akşam Regaip Kandili. Kandiliniz mübarek olsun."
                    )
                )
            }
        }
        return out.values.sortedWith(compareBy({ it.date }, { it.name }))
    }
}
