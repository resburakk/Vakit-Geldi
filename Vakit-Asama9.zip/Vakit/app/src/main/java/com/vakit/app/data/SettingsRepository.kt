package com.vakit.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.vakit.app.domain.AppSettings
import com.vakit.app.domain.ColorTheme
import com.vakit.app.domain.LocationInfo
import com.vakit.app.domain.MAX_OFFSET_MINUTES
import com.vakit.app.domain.Prayer
import com.vakit.app.domain.REMINDER_OPTIONS
import com.vakit.app.domain.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.vakitDataStore: DataStore<Preferences> by preferencesDataStore(name = "vakit_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val IL = stringPreferencesKey("il")
        val ILCE = stringPreferencesKey("ilce")
        val LAT = doublePreferencesKey("lat")
        val LON = doublePreferencesKey("lon")
        val TZ = stringPreferencesKey("timezone")
        val SOUND = booleanPreferencesKey("sound")
        val VIBRATION = booleanPreferencesKey("vibration")
        val REMINDER = intPreferencesKey("reminder_minutes")
        val THEME = stringPreferencesKey("theme_mode")
        val LAST_UPDATE = longPreferencesKey("last_update")
        val STATUS_NOTIFICATION = booleanPreferencesKey("status_notification")
        val COLOR_THEME = stringPreferencesKey("color_theme")
        val FRIDAY = booleanPreferencesKey("friday_notification")
        val CELEBRATION = booleanPreferencesKey("celebration_notifications")
        fun notify(prayer: Prayer) = booleanPreferencesKey("notify_${prayer.name.lowercase()}")
        fun offset(prayer: Prayer) = intPreferencesKey("offset_${prayer.name.lowercase()}")
    }

    private val prefs: Flow<Preferences> = context.vakitDataStore.data.catch { e ->
        if (e is IOException) emit(emptyPreferences()) else throw e
    }

    val location: Flow<LocationInfo?> = prefs.map { p ->
        val il = p[Keys.IL]
        val ilce = p[Keys.ILCE]
        val lat = p[Keys.LAT]
        val lon = p[Keys.LON]
        if (il == null || ilce == null || lat == null || lon == null) null
        else LocationInfo(il, ilce, lat, lon, p[Keys.TZ] ?: LocationInfo.DEFAULT_TIMEZONE)
    }.distinctUntilChanged()

    val settings: Flow<AppSettings> = prefs.map { p ->
        AppSettings(
            notify = Prayer.entries.associateWith { p[Keys.notify(it)] ?: true },
            sound = p[Keys.SOUND] ?: true,
            vibration = p[Keys.VIBRATION] ?: true,
            reminderMinutes = (p[Keys.REMINDER] ?: 0).takeIf { it in REMINDER_OPTIONS } ?: 0,
            themeMode = p[Keys.THEME]
                ?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() }
                ?: ThemeMode.SYSTEM,
            statusNotification = p[Keys.STATUS_NOTIFICATION] ?: true,
            colorTheme = p[Keys.COLOR_THEME]
                ?.let { runCatching { ColorTheme.valueOf(it) }.getOrNull() }
                ?: ColorTheme.NANE,
            fridayNotification = p[Keys.FRIDAY] ?: true,
            celebrationNotifications = p[Keys.CELEBRATION] ?: true,
            offsets = Prayer.entries.associateWith {
                (p[Keys.offset(it)] ?: 0).coerceIn(-MAX_OFFSET_MINUTES, MAX_OFFSET_MINUTES)
            }
        )
    }.distinctUntilChanged()

    val lastUpdate: Flow<Long?> = prefs.map { it[Keys.LAST_UPDATE] }.distinctUntilChanged()

    suspend fun setLocation(location: LocationInfo) {
        context.vakitDataStore.edit {
            it[Keys.IL] = location.il
            it[Keys.ILCE] = location.ilce
            it[Keys.LAT] = location.latitude
            it[Keys.LON] = location.longitude
            it[Keys.TZ] = location.timezoneId
        }
    }

    suspend fun setPrayerNotification(prayer: Prayer, enabled: Boolean) {
        context.vakitDataStore.edit { it[Keys.notify(prayer)] = enabled }
    }

    suspend fun setSound(enabled: Boolean) {
        context.vakitDataStore.edit { it[Keys.SOUND] = enabled }
    }

    suspend fun setVibration(enabled: Boolean) {
        context.vakitDataStore.edit { it[Keys.VIBRATION] = enabled }
    }

    suspend fun setReminderMinutes(minutes: Int) {
        context.vakitDataStore.edit { it[Keys.REMINDER] = if (minutes in REMINDER_OPTIONS) minutes else 0 }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.vakitDataStore.edit { it[Keys.THEME] = mode.name }
    }

    suspend fun setLastUpdate(millis: Long) {
        context.vakitDataStore.edit { it[Keys.LAST_UPDATE] = millis }
    }

    suspend fun setColorTheme(theme: ColorTheme) {
        context.vakitDataStore.edit { it[Keys.COLOR_THEME] = theme.name }
    }

    suspend fun setFridayNotification(enabled: Boolean) {
        context.vakitDataStore.edit { it[Keys.FRIDAY] = enabled }
    }

    suspend fun setCelebrationNotifications(enabled: Boolean) {
        context.vakitDataStore.edit { it[Keys.CELEBRATION] = enabled }
    }

    suspend fun setOffset(prayer: Prayer, minutes: Int) {
        context.vakitDataStore.edit {
            it[Keys.offset(prayer)] = minutes.coerceIn(-MAX_OFFSET_MINUTES, MAX_OFFSET_MINUTES)
        }
    }

    suspend fun setStatusNotification(enabled: Boolean) {
        context.vakitDataStore.edit { it[Keys.STATUS_NOTIFICATION] = enabled }
    }
}
