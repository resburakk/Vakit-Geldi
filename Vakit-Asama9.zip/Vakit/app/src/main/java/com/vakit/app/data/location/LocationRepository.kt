package com.vakit.app.data.location

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.vakit.app.data.remote.NominatimApi
import com.vakit.app.data.remote.TurkiyeApi
import com.vakit.app.data.remote.PrayerDataException
import com.vakit.app.domain.LocationInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.lang.reflect.Type
import java.text.Collator
import java.util.Locale
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * İl/ilçe listeleri TurkiyeAPI üzerinden internetten alınır ve cihazda saklanır
 * (180 gün geçerli; internet yoksa eski kayıt kullanılır). Seçilen ilçenin koordinatı sırayla
 * Google (cihaz Geocoder), OpenStreetMap Nominatim ve son çare olarak OSM ilçe merkezinden alınır.
 * Hiçbir koordinat tahmin edilmez.
 */
class LocationRepository(
    private val context: Context,
    private val turkiye: TurkiyeApi,
    private val nominatim: NominatimApi,
    private val geocoder: GeocoderSource
) {
    private val gson = Gson()
    private val collator: Collator = Collator.getInstance(Locale("tr", "TR"))

    suspend fun provinces(): Result<List<Province>> =
        cached("provinces_v2", object : TypeToken<List<Province>>() {}.type) { fetchProvinces() }

    suspend fun districts(province: Province): Result<List<District>> =
        cached("districts_v2_${province.id}", object : TypeToken<List<District>>() {}.type) {
            fetchDistricts(province)
        }

    suspend fun resolve(province: Province, district: District): Result<ResolvedLocation> {
        return try {
            val query = "${district.name}, ${province.name}, Türkiye"
            val reference = if (district.lat != null && district.lon != null) {
                GeoPoint(district.lat, district.lon)
            } else {
                null
            }
            val google = geocoder.find(query)
            if (acceptable(google, reference) && google != null) {
                return Result.success(build(province, district, google, "Google (cihaz konum servisi)"))
            }
            val osm = nominatimPoint(query)
            if (acceptable(osm, reference) && osm != null) {
                return Result.success(build(province, district, osm, "OpenStreetMap Nominatim"))
            }
            if (reference != null) {
                return Result.success(build(province, district, reference, "OpenStreetMap (ilçe merkezi)"))
            }
            Result.failure(PrayerDataException("Koordinat alınamadı. İnternet bağlantını kontrol edip tekrar dene."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun build(province: Province, district: District, point: GeoPoint, source: String) =
        ResolvedLocation(
            LocationInfo(province.name, district.name, point.lat, point.lon),
            source
        )

    private fun acceptable(point: GeoPoint?, reference: GeoPoint?): Boolean {
        if (point == null) return false
        if (point.lat !in 35.5..42.5 || point.lon !in 25.5..45.0) return false
        return reference == null || distanceKm(point, reference) <= MAX_REFERENCE_KM
    }

    private fun distanceKm(a: GeoPoint, b: GeoPoint): Double {
        val dLat = Math.toRadians(b.lat - a.lat)
        val dLon = Math.toRadians(b.lon - a.lon)
        val h = sin(dLat / 2).pow(2) +
            cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2).pow(2)
        return 2 * EARTH_RADIUS_KM * asin(sqrt(h))
    }

    private suspend fun nominatimPoint(query: String): GeoPoint? = try {
        nominatim.search(query, "jsonv2", 1, "tr", "tr").firstOrNull()?.let { result ->
            val lat = result.lat?.toDoubleOrNull()
            val lon = result.lon?.toDoubleOrNull()
            if (lat != null && lon != null) GeoPoint(lat, lon) else null
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        null
    }

    private suspend fun fetchProvinces(): List<Province> {
        val items = turkiye.provinces(fields = "id,name", limit = 100).data.orEmpty()
        val list = items.mapNotNull { item ->
            val id = item.id ?: return@mapNotNull null
            val name = item.name?.trim()?.takeIf { it.isNotEmpty() } ?: return@mapNotNull null
            Province(id, name)
        }.distinctBy { it.name }
            .sortedWith(Comparator { a, b -> collator.compare(a.name, b.name) })
        if (list.size < MIN_PROVINCES) {
            throw PrayerDataException("İl listesi eksik geldi (${list.size}/81). Biraz sonra tekrar dene.")
        }
        return list
    }

    private suspend fun fetchDistricts(province: Province): List<District> {
        val items = turkiye.districts(province.id, fields = "id,name", limit = 100).data.orEmpty()
        val list = items.mapNotNull { item ->
            val name = item.name?.trim()?.takeIf { it.isNotEmpty() } ?: return@mapNotNull null
            District(name)
        }.distinctBy { it.name }
            .sortedWith(Comparator { a, b -> collator.compare(a.name, b.name) })
        if (list.isEmpty()) throw PrayerDataException("Bu il için ilçe listesi bulunamadı.")
        return list
    }

    private suspend fun <T> cached(
        name: String,
        type: Type,
        fetch: suspend () -> List<T>
    ): Result<List<T>> = withContext(Dispatchers.IO) {
        val file = File(context.filesDir, "loc_$name.json")
        val stored: List<T>? = if (file.exists()) {
            try {
                gson.fromJson<List<T>>(file.readText(), type)
            } catch (e: Exception) {
                null
            }
        } else {
            null
        }
        val fresh = System.currentTimeMillis() - file.lastModified() < CACHE_TTL_MS
        if (!stored.isNullOrEmpty() && fresh) return@withContext Result.success(stored)
        try {
            val list = fetch()
            file.writeText(gson.toJson(list))
            Result.success(list)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (!stored.isNullOrEmpty()) Result.success(stored) else Result.failure(e)
        }
    }

    private companion object {
        const val MIN_PROVINCES = 70
        const val CACHE_TTL_MS = 180L * 24 * 60 * 60 * 1000
        const val MAX_REFERENCE_KM = 150.0
        const val EARTH_RADIUS_KM = 6371.0
    }
}
