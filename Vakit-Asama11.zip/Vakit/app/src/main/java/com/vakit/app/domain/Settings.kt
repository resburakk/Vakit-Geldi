package com.vakit.app.domain

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Pastel renk temaları. */
enum class ColorTheme(val label: String) {
    NANE("Nane"),
    LAVANTA("Lavanta"),
    SEFTALI("Şeftali"),
    GOKYUZU("Gökyüzü")
}

const val MAX_OFFSET_MINUTES = 15

/** Bir vaktin sesi için özel değerler: "" = varsayılan bildirim sesi, SOUND_SILENT = sessiz, diğeri ses adresi. */
const val SOUND_SILENT = "silent"

val REMINDER_OPTIONS: List<Int> = listOf(0, 5, 10, 15, 30)

data class AppSettings(
    val notify: Map<Prayer, Boolean> = Prayer.entries.associateWith { true },
    val sound: Boolean = true,
    val vibration: Boolean = true,
    val reminderMinutes: Int = 0,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val statusNotification: Boolean = true,
    val colorTheme: ColorTheme = ColorTheme.NANE,
    val prayerSounds: Map<Prayer, String> = Prayer.entries.associateWith { "" },
    val fridayNotification: Boolean = true,
    val celebrationNotifications: Boolean = true,
    /** Vakit başına dakika düzeltmesi (örn. Akşam +2). */
    val offsets: Map<Prayer, Int> = Prayer.entries.associateWith { 0 }
) {
    fun isEnabled(prayer: Prayer): Boolean = notify[prayer] ?: true
    fun offsetOf(prayer: Prayer): Int = offsets[prayer] ?: 0
    fun soundOf(prayer: Prayer): String = prayerSounds[prayer] ?: ""
}
